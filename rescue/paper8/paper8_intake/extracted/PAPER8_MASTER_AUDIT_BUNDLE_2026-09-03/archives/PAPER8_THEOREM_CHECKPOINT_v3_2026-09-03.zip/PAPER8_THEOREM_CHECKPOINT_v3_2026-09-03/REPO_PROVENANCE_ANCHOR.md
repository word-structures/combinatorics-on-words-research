# Paper 8 v3 provenance anchor

This checkpoint is a new work product built from, but does not mutate, the preserved v2 checkpoint:

`PAPER8_THEOREM_CHECKPOINT_v2_2026-09-03.zip`

SHA-256:

`5b8a4881b3aa29534f0208fd1a78daaa316f9cd9d727db2cb23afaeb7988935c`

The quotient inputs `a_tilt_quotient_pid2.npz` and `a_tilt_quotient_pid3.npz` are copied from the v2 raw research state. Binary graph exports in each theorem directory were independently checked byte-for-byte against those NPZ arrays.

H9 was not opened in producing this checkpoint.
