# PAPER 8 CLAIM LEDGER — theorem checkpoint v3

| Claim | Status | Notes |
|---|---|---|
| Canonical H8 profile family is `(3,3,2),(4,2,2),(4,3,1),(5,2,1)` | COMPUTATIONALLY_AUDITED | Preserved from v2. |
| H8 hard-response signs are `+,-,-,-` | COMPUTATIONALLY_AUDITED | Two-method discovery calculation preserved in v2. |
| H2–H8 minimum-B split is 19/19 | FINITE_OBSERVATION | Not universal. |
| Full-shift local response `(4/9)q(h-3B)` | EXACT_DERIVED | Preserved result. |
| Constrained finite-window local term `q(V_2h-4B/3)` | EXACT_DERIVED | Preserved result. |
| `(5,2,1): C(x)>0` on `[0,1]` | COMPUTER_ASSISTED_THEOREM_PASS | v2 certificate; external audit pending. |
| `(4,3,1): C(x)>0` on `[0,1]` | COMPUTER_ASSISTED_THEOREM_PASS_INTERNAL | New v3 certificate; independent exact/modular/Bernstein cross-checks pass; external interval-roundoff and tail-lemma audit pending. |
| `(4,2,2): C(x)>0` on `[0,1]` | COMPUTER_ASSISTED_THEOREM_PASS_INTERNAL | New v3 certificate; independent exact/modular/Bernstein cross-checks pass; external interval-roundoff and tail-lemma audit pending. |
| Negative hard response for `(5,2,1),(4,3,1),(4,2,2)` | CONSEQUENCE_OF_CERTIFICATES | Within the audited transfer-matrix setup. |
| Full continuum theorem for `(3,3,2)` | OPEN | Final H8 profile and hardest sign. |
| Universal minimum-B theorem | NOT_ESTABLISHED | Do not claim. |
| Universal sign(S) theorem | FALSE_AS_COMPLETE_RULE | S=0 cases differ. |
| Paper novelty | NOT_ESTABLISHED | Dedicated literature audit still required. |
| H9 result | NOT_RUN | Holdout remains closed. |
