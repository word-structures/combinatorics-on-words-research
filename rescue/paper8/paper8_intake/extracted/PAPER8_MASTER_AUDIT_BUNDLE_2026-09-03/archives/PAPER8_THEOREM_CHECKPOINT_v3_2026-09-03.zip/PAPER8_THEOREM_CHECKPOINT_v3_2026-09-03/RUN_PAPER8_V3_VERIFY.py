from fractions import Fraction
from pathlib import Path
import json, hashlib, sys
ROOT=Path(__file__).resolve().parent

def verify_profile(tag,profile,L,alpha_s,blocks,finite_name,cand_name):
 d=ROOT/f'theorem_{tag}'/'data'
 cand=json.load(open(d/cand_name)); fin=json.load(open(d/finite_name)); st=json.load(open(d/'STRUCTURAL_CROSSCHECK.json')); mod=json.load(open(d/'MODULAR_CROSSCHECK.json')); dec=json.load(open(d/(f'L{L}_decasteljau_crosscheck.json'))); ld=json.load(open(d/'LONGDOUBLE_SELECTED_INTERVAL_RECHECK.json'))
 assert cand['profile']==profile and cand['PASS']
 assert fin['profile']==profile and fin['L']==L and fin['G_nonzero_count']==0 and fin['all_numerator_bernstein_positive']
 assert st['PASS'] and st['profile']==profile
 assert mod['PASS'] and all(r['PASS'] for r in mod['records'])
 assert dec['PASS'] and dec['recordwise_exact_match']
 assert ld['PASS']
 alpha=Fraction(alpha_s);tau=1-alpha;M=Fraction(43,3);R=Fraction(25);D=R/alpha;K=(M+D)**2/alpha+2*(M+D)*D/alpha+3*D**2;Et=4*K*tau**blocks
 Cfin=Fraction(int(fin['global_record']['C_lower_num']),int(fin['global_record']['C_lower_den']));Cinf=Cfin-Et
 assert str(alpha)==cand['theorem_alpha_used']
 assert abs(float(Et)-cand['tail_upper_float'])<1e-15
 assert abs(float(Cinf)-cand['infinite_C_lower_float'])<1e-15
 assert Cinf>0
 return {'profile':profile,'finite_lower':float(Cfin),'tail_upper':float(Et),'infinite_lower':float(Cinf),'alpha':str(alpha),'PASS':True}

r431=verify_profile('431',[4,3,1],176,'91/100',4,'L176_subdivision10.json','THEOREM_431_CANDIDATE_VERIFICATION.json')
r422=verify_profile('422',[4,2,2],220,'89/100',5,'L220_subdivision10.json','THEOREM_422_CANDIDATE_VERIFICATION.json')
print(json.dumps({'theorem_431':r431,'theorem_422':r422,'PAPER8_V3_VERIFICATION':'PASS'},indent=2))
