# PAPER 8 AI HANDOFF — theorem checkpoint v3

Read in this order:

1. `README.md`
2. `PAPER8_STATE.md`
3. `PAPER8_CLAIM_LEDGER.md`
4. `theorem_431/THEOREM_431_PROOF.md`
5. `theorem_422/THEOREM_422_PROOF.md`
6. `theorem_521_reference/THEOREM_521_PROOF.md`
7. Run `python RUN_PAPER8_V3_VERIFY.py`.

Do not open H9. H8 is discovery data, not a blind holdout.

New in v3: `(4,3,1)` and `(4,2,2)` have internal continuum sign certificates. Treat both as computer-assisted theorem passes pending independent interval-roundoff and tail-lemma audit, not as novelty results.

Next scientific target: `(3,3,2)`. It is the only H8 profile still OPEN at the full continuum level. Its expected sign is opposite: one must certify `C_332(x)<0`, not reuse a positivity assumption.
