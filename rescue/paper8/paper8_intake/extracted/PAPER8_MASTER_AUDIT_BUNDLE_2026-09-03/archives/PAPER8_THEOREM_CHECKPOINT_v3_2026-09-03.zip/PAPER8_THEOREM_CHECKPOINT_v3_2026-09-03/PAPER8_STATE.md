# PAPER 8 STATE — theorem checkpoint v3

PAPER8_STATUS = ACTIVE_RESEARCH_CANDIDATE  
DATE = 2026-09-03  
NOVELTY_STATUS = NOT_ESTABLISHED  
H8_FUTURE_BLIND_HOLDOUT = FORFEITED  
H9_OPENED = NO

## Continuum certificate status

Three of the four H8 profiles now have internally closed continuum sign certificates:

| profile | sign of hard response | continuum status | certified infinite-context margin |
|---|---:|---|---:|
| `(5,2,1)` | negative | v2 computer-assisted theorem pass | `> 5.1781661433` |
| `(4,3,1)` | negative | v3 internal pass | `> 0.2035888328` |
| `(4,2,2)` | negative | v3 internal pass | `> 0.4720167390` |
| `(3,3,2)` | positive | OPEN | — |

The common mechanism is to certify the sign of

`C_v(x) = d_t^2 log q_v(t,x)|_{t=0}`

uniformly for `x in [0,1]`, then use

`da/dx = C_v(x) d log(lambda)/dx`.

For the three negative-response profiles, `C_v(x)>0`, so restoring target edges increases asymptotic variance and hard deletion lowers it.

## New v3 theorem 431

- finite radius `L=176`, path length 353;
- exact target-degree cap 158;
- exact `G == 0` symmetry polynomial;
- exact Bernstein finite-context bound `C_176 > 1.9643001993601346`;
- complete 90-interval / 180-record bidirectional 44-step cover;
- observed minimum `alpha_44 > 0.913352001287192`;
- theorem uses `alpha=0.91`, `tau=0.09`;
- five? No: four full 44-step blocks per side because `L=176`;
- tail `< 1.7607113665520568`;
- infinite margin `> 0.2035888328080777`.

Independent checks: outgoing-edge modular DP at four primes; exact de Casteljau Bernstein reconstruction; graph export/cap/score-envelope/SCC audit; selected float128 interval recheck.

## New v3 theorem 422

- finite radius `L=220`, path length 441;
- exact target-degree cap 111;
- exact `G == 0` symmetry polynomial;
- exact Bernstein finite-context bound `C_220 > 0.9272878857676629`;
- complete 90-interval / 180-record bidirectional 44-step cover;
- observed minimum `alpha_44 > 0.8910440039974096`;
- theorem deliberately uses `alpha=0.89`, `tau=0.11`;
- five full 44-step blocks per side;
- tail `< 0.4552711467305119`;
- infinite margin `> 0.4720167390371510`.

The weakest cover interval `[0,0.004]` forward was independently recomputed in float128 as `0.891044004940431`, still above 0.89.

## Audit boundary

The exact finite-context side is now strongly cross-validated internally. The remaining common audit boundary for all continuum certificates is:

1. independent derivation/review of the finite-to-infinite inequality `4 K tau^B`;
2. a genuinely directed-rounding or independent ball-arithmetic replay of the interval minorization generator;
3. external code review/replay.

These are audit obligations, not silently promoted facts.

## Next scientific target

Attempt `(3,3,2)` without opening H9. If it fails, characterize exactly why the positive profile defeats the certificate architecture rather than forcing a theorem.
