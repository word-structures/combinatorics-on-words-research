# Paper 8 theorem checkpoint v3 — 2026-09-03

This checkpoint preserves two new H8 continuum sign certificates built after v2:

- `(4,3,1)`: internal computer-assisted theorem PASS;
- `(4,2,2)`: internal computer-assisted theorem PASS.

Together with the v2 `(5,2,1)` certificate, three of four H8 profiles are internally closed. `(3,3,2)` remains OPEN.

## Verification boundary

Exact finite-context arithmetic is cross-validated through:

- GMP integer DP;
- independent outgoing-edge modular DP at four primes;
- exact Bernstein subdivision;
- independent global-Bernstein + de Casteljau reconstruction;
- graph export, degree-cap, score-envelope and hard-SCC structural checks.

The interval mixing covers were also spot-replayed in float128 at the weakest intervals. However the full cover generator still relies on floating-point recurrences with conservative padding rather than a separately implemented directed-rounding package. The finite-to-infinite `4 K tau^B` lemma also remains an explicit external proof-audit target.

Therefore do not describe v3 as externally certified or publication-ready.

## Nonclaims

- no H9 computation;
- no universal minimum-B law;
- no universal sign(S) law;
- no novelty certification;
- no claim that all four H8 continuum signs are closed.
