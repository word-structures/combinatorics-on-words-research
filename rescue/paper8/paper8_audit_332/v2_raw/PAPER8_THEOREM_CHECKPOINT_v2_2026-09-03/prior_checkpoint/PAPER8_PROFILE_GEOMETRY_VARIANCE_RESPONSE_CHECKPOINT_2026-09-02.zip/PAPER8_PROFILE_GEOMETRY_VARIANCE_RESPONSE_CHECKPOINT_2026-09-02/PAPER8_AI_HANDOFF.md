# Paper 8 AI handoff

You are resuming **Paper 8**, a separate research line from Paper 7.

Paper 7 studies one-sided versus two-sided infinite extendability in the four-letter Abelian-square-free language. Do not conflate it with this work.

## Your first action

Read:

1. `PAPER8_STATE.md`
2. `PAPER8_CLAIM_LEDGER.md`
3. `PAPER8_MACHINE_SUMMARY.json`
4. `PAPER8_NEXT_RESEARCH_PLAN.md`

Then inspect the exact artifacts in `core/` and the complete scratch state in `latest_research_state/h8cp/`.

## Research target

The current best Paper 8 mechanism is:

\[
\text{Parikh geometry}\to
\text{S3 symmetry}\to
\text{low-rank return kernel}\to
\text{standard-representation susceptibility}\to
\text{variance response}.
\]

The first theorem-grade target is **not** “19/19”. It is a rigorous continuum sign certificate, preferably first for profile (5,2,1):

\[
C_{521}(x)>0\quad\forall x\in[0,1].
\]

The 521 case has trivial/standard target ranks 8/16 and therefore offers the smallest exact return-kernel problem.

## Critical epistemic rules

- Novelty is NOT_ESTABLISHED.
- H8 is exploratory discovery data and is not an untouched holdout.
- H9 has not been opened. Keep it closed unless a new protocol is frozen first.
- Dense scans are evidence, not interval proofs.
- Positive finite-difference C' at sampled x is not a monotonicity theorem.
- Quotient and S3 reductions should be given formal proofs before publication even though they are strongly numerically audited.
- If the continuum theorem dies, report the counterexample; do not tune definitions to preserve the 19/19 pattern.

## Important stored facts

H8 hard deltas:

- 332: +0.017262485154849835
- 422: -0.002991888299664361
- 431: -0.0049442132838203035
- 521: -0.002181423292746676

Hard-endpoint normalized curvatures C(0), approximately:

- 332: -0.65683664
- 422: +1.14445419
- 431: +2.31866244
- 521: +5.97180158

Minimum observed finite-difference C' in current scans:

- 332: +0.03908
- 422: positive (see machine summary/data)
- 431: +0.807 range minimum in stored probe
- 521: +0.04954

Do not quote these as rigorous continuum derivative bounds.
