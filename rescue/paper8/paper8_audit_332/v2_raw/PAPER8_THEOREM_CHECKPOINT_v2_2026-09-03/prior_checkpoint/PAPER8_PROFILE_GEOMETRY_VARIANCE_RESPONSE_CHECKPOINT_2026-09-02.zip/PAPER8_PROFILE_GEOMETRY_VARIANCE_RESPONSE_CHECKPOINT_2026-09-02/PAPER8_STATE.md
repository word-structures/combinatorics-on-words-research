# Paper 8 — current research state

## 1. Paper identity

Paper 8 is **not an H8 result paper**. H8 was the discovery laboratory that exposed a broader mechanism.

Current scientific question:

> How does the Parikh-profile geometry of a forbidden Abelian-square event interact with the background symbolic dynamics to change the asymptotic letter-count variance?

The emerging mechanism chain is

\[
\text{Parikh geometry}
\to \text{S3 representation structure}
\to \text{finite return kernel}
\to \text{Perron/Parry response}
\to \text{variance susceptibility}.
\]

## 2. Finite observation that started the line

Across the canonical h=2,...,8 profile family, the hard-deletion sign split is 19/19:

- 7/7 minimum-B profiles: positive variance response;
- 12/12 other profiles: negative variance response.

This is a finite computational observation only. It is **not** a universal theorem.

H8 was intentionally opened as discovery data. H9 remains unopened.

## 3. Exact local geometry

For the full ternary shift,

\[
\left.\partial_\varepsilon a_v\right|_{\varepsilon=0}
=\frac49 q_v\bigl(h-3B(v)\bigr).
\]

Thus the scalar \(S=h-3B\) is not merely a regression feature: it is the exact quadratic local-composition driver in the full-shift soft model.

For an S3-symmetric constrained baseline,

\[
\boxed{L_v=q_v\left(V_{2h}-\frac43 B(v)\right)}.
\]

This defines the dynamic threshold

\[
\boxed{B_c(h)=\frac34V_{2h}(L_{h-1})}.
\]

For H8, \(B_c\approx1.3967235912\), strictly between the minimum profile value \(2/3\) and the next occurring value \(8/3\).

## 4. Correlation correction

At the L7 baseline,

\[
a'_v(0)=L_v+\Gamma_v.
\]

Numerically for the four H8 profiles, \(|\Gamma_v|<|L_v|\); the correction opposes the local term but does not overturn it.

The resolvent implementation is independently finite-difference checked to about 1e-10 or better.

A uniform inequality such as \(|\Gamma_v(x)|<|L_v(x)|\) or the stronger observed candidate \(|\Gamma/L|<1/2\) over the whole soft path remains **open**.

## 5. Better continuum variable

Set \(x=e^{-\varepsilon}\in[0,1]\). Define

\[
\boxed{C_v(x)=\frac{da/dx}{d\log\lambda/dx}
=\partial_t^2\log q_v(t,x)|_{t=0}}.
\]

This normalized curvature stays finite and well separated from zero at hard deletion.

Direct hard-endpoint values are approximately:

- (3,3,2): -0.65683664
- (4,2,2): +1.14445419
- (4,3,1): +2.31866244
- (5,2,1): +5.97180158

Dense quotient scans show the corresponding signs throughout the tested interval. Moreover, finite-difference scans show \(C'_v(x)>0\) at every tested point, with smallest observed derivative margins about 0.0391, 0.2138, 0.8074 and 0.0495 respectively. **Monotonicity is still numerical, not a theorem.**

## 6. Quotient reduction

The original dominant H8 presentation has 104,520 states. Exact labeled/weighted future-equivalence minimization reduces the representations drastically. The quotient is structurally a strong lumping and was numerically audited against the original presentation over many \((x,t)\) values; Perron-root differences were about 1e-15 and pressure-curvature differences were at finite-difference noise scale.

The a-tilt quotients used by the S3 analysis have sizes:

- (3,3,2): 10,191
- (4,2,2): 4,809
- (4,3,1): 4,614
- (5,2,1): 4,038

## 7. Exact S3 block mechanism

At t=0, both the baseline and profile perturbation are S3-invariant. The quotient splits exactly into trivial and standard representation blocks; measured cross-block sparse entries are exactly zero.

The asymptotic variance can be written as

\[
\boxed{
a(x)=\frac29+\frac{2}{\lambda(x)}
\ell_TD_{TS}(x)
(\lambda I-A_{\rm Std}(x))^{-1}
D_{ST}(x)r_T.
}
\]

This formula numerically reproduces the full-presentation variance at roughly 1e-13 scale in the stored checks.

Interpretation: the symmetric Perron growth branch lives in the trivial representation, whereas letter imbalance is a standard-representation susceptibility.

## 8. Low-rank return kernel

The target perturbation is low rank after the S3 reduction. Observed ranks are:

| profile | trivial target rank | standard target rank |
|---|---:|---:|
| (3,3,2) | 480 | 960 |
| (4,2,2) | 49 | 98 |
| (4,3,1) | 73 | 146 |
| (5,2,1) | 8 | 16 |

With \(A_x=A_0+xUV^T\), determinant/Woodbury reduction gives

\[
\det(\lambda I-A_x)=\det(\lambda I-A_0)\det(I-xK_T(\lambda)),
\]

\[
K_T(\lambda)=V^T(\lambda I-A_0)^{-1}U.
\]

On the Perron branch,

\[
\boxed{x\,\rho(K_T(\lambda(x)))=1}.
\]

Stored numerical validations for profiles (4,2,2), (4,3,1), (5,2,1) at x=.1,.5,1 have residuals around 1e-12 or smaller.

The smallest profile (5,2,1), with ranks 8/16, is the preferred first target for a rigorous continuum certificate.

## 9. Mixing / certification state

Full-column Doeblin minorization on the reduced chains is very strong. 50-step masses are typically about 0.983--0.992 even near x=1e-8. A tested block for the difficult chain gave approximately m=36, alpha_36=0.8588. This is much stronger than the earlier subset-column lower bounds and makes rigorous Poisson/resolvent enclosures practical.

The hard endpoint is also structurally benign: after hard deletion there is one isolated dominant Perron SCC, while residual SCCs are singletons without internal edges; the transient remainder is acyclic with short depth.

## 10. What is still missing

The central missing theorem is a continuum statement such as

\[
C_{332}(x)<0,\qquad
C_{422}(x),C_{431}(x),C_{521}(x)>0
\quad \forall x\in[0,1].
\]

Equivalent/stronger routes include a certified monotonicity result for \(C_v\), or uniform dominance of the local term over the correction.

Until this is closed, Paper 8 is a strong research candidate, not a finished theorem paper.
