from pathlib import Path
import hashlib, sys
root=Path(__file__).resolve().parent
manifest=root/'SHA256SUMS.txt'
bad=[]; n=0
for line in manifest.read_text().splitlines():
    if not line.strip(): continue
    h, rel=line.split('  ',1)
    p=root/rel
    if not p.exists(): bad.append((rel,'MISSING')); continue
    got=hashlib.sha256(p.read_bytes()).hexdigest(); n+=1
    if got!=h: bad.append((rel,got))
print(f'FILES_CHECKED = {n}')
if bad:
    print('CHECKPOINT_VERIFICATION = FAIL')
    [print(x) for x in bad[:20]]
    sys.exit(1)
print('CHECKPOINT_VERIFICATION = PASS')
