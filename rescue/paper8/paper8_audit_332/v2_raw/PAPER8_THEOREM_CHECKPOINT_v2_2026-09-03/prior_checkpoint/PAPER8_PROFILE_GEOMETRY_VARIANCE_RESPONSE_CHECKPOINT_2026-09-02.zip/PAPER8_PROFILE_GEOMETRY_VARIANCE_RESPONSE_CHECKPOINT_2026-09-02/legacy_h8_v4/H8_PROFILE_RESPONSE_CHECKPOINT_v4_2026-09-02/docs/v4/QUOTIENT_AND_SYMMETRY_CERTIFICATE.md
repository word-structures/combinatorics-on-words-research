# Quotient and symmetry certificate — H8 profile response v4

Status: exact structural reduction + numerical implementation audit. This document does **not** by itself certify the final continuum sign theorem.

## 1. Full-symbol future-equivalence quotient

For each target profile, states were partitioned by iterative refinement of the complete deterministic labeled transition signature:

- appended symbol `a,b,c`;
- edge type `normal` or `target`;
- destination partition class;
- missing transitions retained explicitly.

At stabilization, every two states in one class have identical weighted future behavior for arbitrary symbol weights and arbitrary common target-edge weight `x`.

State counts:

| profile | original giant SCC | exact full-symbol quotient |
|---|---:|---:|
| (3,3,2) | 104520 | 20382 |
| (4,2,2) | 104520 | 9618 |
| (4,3,1) | 104520 | 9228 |
| (5,2,1) | 104520 | 8076 |

### Exactness argument

Let `C` be a partition class. For every labeled edge category and every destination class `D`, the number of such edges from a state `i in C` to `D` is class-independent. Therefore the subspace of class-constant vectors is invariant under every weighted transfer matrix in the parameter family.

For `x>0`, the original baseline component is irreducible and the Perron eigenvalue is simple. Power iteration started from the all-ones vector remains class-constant and converges to the unique positive Perron vector. Hence the true Perron right vector is class-constant and the quotient Perron root equals the original Perron root exactly. Aggregating the original left Perron vector over partition classes gives the quotient left Perron vector. Consequently the pressure `log rho` is identical on the original and quotient presentations throughout the analytic branch, and so are its derivatives.

At `x=0`, the hard-deletion endpoint is treated separately on its unique dominant Perron SCC; the remaining SCCs are acyclic singletons with spectral radius zero (see `hard_endpoint_structure.json`).

### Numerical implementation audit

The original 104520-state operator and the quotient were compared at 36 `(x,t)` points:

- `x = 1, 0.5, 0.01`;
- `t = -0.05, 0, +0.05`;
- all four profiles.

Maximum absolute Perron-root discrepancy:

`1.1102230246251565e-15`.

A finite-difference pressure-curvature audit at 12 additional points had maximum discrepancy about

`1.44e-9`,

consistent with finite-difference truncation/roundoff rather than a quotient discrepancy.

## 2. S3 action

The target profile event and the `t=0` baseline are S3-invariant. On every full-symbol quotient, the S3 action is free: **every class orbit has size 6**.

| profile | quotient states | free S3 orbits |
|---|---:|---:|
| (3,3,2) | 20382 | 3397 |
| (4,2,2) | 9618 | 1603 |
| (4,3,1) | 9228 | 1538 |
| (5,2,1) | 8076 | 1346 |

This is useful theoretically because the Perron branch is in the trivial representation while the centered letter observable lies in the standard representation.

## 3. Exact a-tilt quotient

The actual pressure tilt distinguishes `a` from `{b,c}` but treats `b,c` identically. Re-running equitable refinement with weighted categories

- a / not-a;
- normal / target;
- destination class with multiplicity,

produces an exact quotient for the full two-parameter family `A(t,x)` used in the variance-response calculation:

| profile | exact a-tilt quotient states | aggregated edges |
|---|---:|---:|
| (3,3,2) | 10191 | 18858 |
| (4,2,2) | 4809 | 8541 |
| (4,3,1) | 4614 | 8010 |
| (5,2,1) | 4038 | 7065 |

All classes have size at least 2, exactly reflecting the `b<->c` symmetry.

## 4. Consequence for future certification

The final continuum problem need not be certified on the 104520-state lifted graph. It can be carried out on the exact 4k–10k-state a-tilt quotients without changing `lambda(t,x)`, pressure, or the target curvature `C_v(x)`.
