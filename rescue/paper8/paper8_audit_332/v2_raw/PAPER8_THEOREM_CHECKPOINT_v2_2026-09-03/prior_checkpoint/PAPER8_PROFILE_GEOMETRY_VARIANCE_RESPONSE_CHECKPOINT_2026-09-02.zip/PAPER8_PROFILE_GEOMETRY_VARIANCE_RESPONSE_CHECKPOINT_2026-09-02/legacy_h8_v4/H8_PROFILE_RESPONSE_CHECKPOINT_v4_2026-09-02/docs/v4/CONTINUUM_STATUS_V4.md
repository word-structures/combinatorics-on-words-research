# Continuum sign certification — v4 status

Parameter:

`x = exp(-epsilon) in [0,1]`, with `x=1` the L7 baseline and `x=0` hard deletion.

Define

`q_x(t,x) = partial_x log lambda(t,x)`

and

`C_v(x) = partial_t^2 log q_x(t,x)|_{t=0}`.

Because `q_x(0,x)>0`,

`sign(da/dx) = sign C_v(x)`.

Thus the desired soft-to-hard sign theorem is equivalent to

- `C_332(x) < 0`,
- `C_422(x) > 0`,
- `C_431(x) > 0`,
- `C_521(x) > 0`

for every `x in [0,1]`.

## Hard endpoint is directly controlled

The hard graph has one isolated dominant Perron SCC. Every other SCC is a singleton with no internal edge, hence spectral radius exactly zero. The longest transient DAG path is at most 8 edges across the four profiles.

Direct one-sided hard-endpoint curvature values (5-point t-curvature, h=0.001) are approximately:

- (3,3,2): -0.6568366441
- (4,2,2): +1.1444541873
- (4,3,1): +2.3186624404
- (5,2,1): +5.9718015790

These are large sign margins.

## Baseline endpoint

At x=1:

- (3,3,2): about -0.569657
- (4,2,2): about +1.391682
- (4,3,1): about +3.166573
- (5,2,1): about +6.233674

Again all margins are large.

## Dense continuum observation

Exact quotient scans and independent resolvent calculations show the same sign throughout all sampled x values. Away from the extreme `x << 1e-4` finite-difference noise region, `C_v(x)` appears monotone increasing in x for all four profiles.

The near-hard resolvent values converge smoothly to the independently computed hard endpoint. Apparent secant oscillations in the finite-difference-only scans below roughly `1e-6` are numerical differentiation noise, not confirmed extrema.

### Candidate stronger theorem

A particularly useful candidate is:

`C_v'(x) > 0 for all x in (0,1)`

for all four H8 profiles.

If this is certified, the continuum sign theorem follows immediately from the endpoint signs. This monotonicity is **not yet proved**.

## S3-orbit curvature structure

Individual target edges can have both curvature signs, so a pointwise-edge proof is false.

However:

- profile (4,3,1): all 80 S3 target-word orbit averages are positive at every tested x, including near hard deletion;
- profile (5,2,1): all 12 S3 orbit averages are strongly positive at every tested x;
- profiles (3,3,2) and (4,2,2) require genuine Parry-mass-weighted cancellation between positive and negative orbits.

Thus a single edgewise proof architecture should not be forced across all four profiles.

## Remaining proof gap

Still not closed rigorously:

`C_v(x)` has the stated sign for **every real x**, not merely every sampled x.

Next routes, now practical on the 4k–10k exact a-tilt quotients:

1. interval subdivision with a posteriori Perron/Poisson enclosures;
2. certify `C_v'(x)>0` on subintervals;
3. use hard-endpoint perturbation on `[0,delta]` and quotient interval bounds on `[delta,1]`;
4. exploit S3-orbit positivity separately for profiles (4,3,1) and (5,2,1).

No h=9 data have been opened.
