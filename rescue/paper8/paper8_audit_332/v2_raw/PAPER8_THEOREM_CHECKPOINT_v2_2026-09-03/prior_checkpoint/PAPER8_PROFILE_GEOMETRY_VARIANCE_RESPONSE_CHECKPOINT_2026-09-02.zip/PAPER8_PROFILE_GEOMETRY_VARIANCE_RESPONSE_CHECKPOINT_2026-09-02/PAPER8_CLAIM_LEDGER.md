# Paper 8 claim ledger

Use this file as the claim authority for this checkpoint. Do not promote a lower-status item without a new proof/certificate and an explicit ledger update.

| Claim | Status | Boundary |
|---|---|---|
| Canonical H8 profile family is (3,3,2), (4,2,2), (4,3,1), (5,2,1) under the reconstructed graph convention | COMPUTATIONALLY_AUDITED | Reproduced h2..7 family first; H8 graph checkpoint stored |
| H2..H8 minimum-B/hard-response sign split is 19/19 | COMPUTATIONAL_FINITE_OBSERVATION | Not universal, not causal, not a theorem |
| Full-shift infinitesimal local response is (4/9) q_v (h-3B(v)) | EXACT_DERIVATION_CANDIDATE | Mathematical derivation is in reports; literature novelty not established |
| Constrained finite-window local term is q_v[V_2h-(4/3)B(v)] under the stated S3-symmetric setup | EXACT_DERIVATION_CANDIDATE | Formal manuscript proof still to be polished |
| Dynamic threshold B_c=(3/4)V_2h | EXACT_CONSEQUENCE | Does not by itself determine full hard response |
| Baseline decomposition a'_v(0)=L_v+Gamma_v with stored resolvent formula | EXACT_FINITE_STATE_FORMULA + NUMERICALLY_AUDITED | Implementation cross-check ~1e-10 |
| H8 baseline |Gamma|<|L| for all four profiles | ROBUST_COMPUTATIONAL_CERTIFICATE | Baseline a-posteriori margin obtained; not a general-h theorem |
| Uniform |Gamma/L|<1/2 on x in [0,1] | NUMERICAL_CANDIDATE_ONLY | Max observed ~0.476; continuum proof missing |
| Quotient preserves weighted/labeled future behavior and Perron response | STRUCTURAL_STRONG_LUMPING + NUMERICAL_AUDIT | Write formal proposition before publication |
| S3 trivial/standard block split has zero cross blocks at t=0 | EXACT_COMPUTATIONAL_STRUCTURE | Sparse construction gives zero cross blocks; formal group-action proof needed in manuscript |
| S3 block variance formula reproduces full variance | DERIVED + NUMERICALLY_AUDITED | Stored checks ~1e-13 |
| Low-rank determinant/return-kernel identity | EXACT_LINEAR_ALGEBRA_CONSEQUENCE | Requires exact low-rank factorization conventions; stored numerical branch checks |
| Hard-endpoint C values have signs (-,+,+,+) | COMPUTATIONALLY_AUDITED_ENDPOINT | Direct dominant-SCC perturbation, not extrapolation |
| C_v(x) has the hard-response sign for every x in [0,1] | OPEN_THEOREM_TARGET | Dense numerical evidence only |
| C'_v(x)>0 for every x in [0,1] | NUMERICAL_CANDIDATE_ONLY | Positive on all scanned points, no interval proof |
| Minimum-B split holds for all h | NOT_ESTABLISHED | Do not state |
| B or S alone is causal in constrained SFTs | FALSIFIED_AS_SIMPLE_CLAIM | Same profile changes response when background language changes |
| Paper 8 novelty | NOT_ESTABLISHED | Literature kill still required |
| H9 is an untouched future test | PRESERVED | H9 has not been opened in this checkpoint |
