# H8 continuum certification status — checkpoint v3

Status: IN PROGRESS. Do not call the full soft-to-hard sign theorem proved yet.

## What is closed at x=1 (baseline)

Parameter x = exp(-epsilon). x=1 is the L7 baseline; x=0 is hard deletion.

A row-stochastic surrogate chain Q was built from the computed Perron right vector. Collatz-Wielandt row-sum spread plus a 50-step Doeblin minorization gives an a posteriori enclosure linking Q to the true Parry chain P.

At x=1, 50-step minorization mass from the first 3000 common endpoint columns is approximately 0.12698; a conservative alpha=0.12 is usable. The Perron row-sum spread is about 8.6e-14. The resulting conservative propagated error band for a_x'(1) is below roughly 8e-4 for every H8 profile, smaller than the smallest observed sign margin (~3.25e-3).

Therefore the baseline sign and the inequality |Gamma|<|L| are robustly separated from zero for all four H8 profiles.

## Numerical continuum structure found

For all four profiles on the scanned x-grid, write

  da/dx = L_x + Gamma_x.

The correction Gamma_x has the opposite sign to L_x but does not overturn it.
The largest observed ratio |Gamma_x/L_x| is approximately 0.475932, for profile (4,3,1) as x -> 0.

Near-hard scan for (4,3,1):

x=1e-8: ratio ~0.4759317194
x=1e-7: ratio ~0.4759317004
x=1e-6: ratio ~0.4759315109
x=1e-5: ratio ~0.4759296157
x=1e-4: ratio ~0.4759106633

Thus a strong candidate uniform inequality is

  |Gamma_x| < (1/2)|L_x|,  0 <= x <= 1,

for all four H8 profiles.

This is NOT YET a continuum proof: an interval subdivision or rigorous Lipschitz/analytic bound between sample points is still required.

## Endpoint issue

At x=0 the full lifted graph is reducible and some Perron weights vanish. The endpoint must be handled on the target graph's dominant SCC (one-sided x -> 0+ perturbation), not by naively evaluating the x>0 Doob formula on all 104520 baseline states.

## Next proof target

Prove or computer-certify

  sup_{x in [0,1]} |Gamma_x/L_x| < 1

and preferably the stronger observed bound < 1/2.

Suggested route:
1. use x-subintervals away from zero and a posteriori Poisson/resolvent bounds from block-Doeblin minorization;
2. certify local Lipschitz bounds for da/dx, L_x and Gamma_x;
3. cover [delta,1] by intervals;
4. handle [0,delta] using the dominant hard-deletion SCC and one-sided perturbation in x;
5. retain explicit numerical margins in every interval certificate.

No h=9 data were opened.
