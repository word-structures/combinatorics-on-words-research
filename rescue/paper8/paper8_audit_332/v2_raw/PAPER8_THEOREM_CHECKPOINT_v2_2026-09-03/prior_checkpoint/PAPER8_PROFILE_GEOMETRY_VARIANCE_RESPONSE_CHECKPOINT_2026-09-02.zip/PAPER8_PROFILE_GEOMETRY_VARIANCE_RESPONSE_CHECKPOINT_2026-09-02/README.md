# Paper 8 research checkpoint — 2026-09-02

Working topic: **Profile Geometry, Symmetry, Return Kernels, and Variance Response under Abelian-Square Deletion**.

This is a context-loss-resistant master checkpoint for the research line that grew out of the H8 profile-response discovery experiment. It is deliberately separate from **Paper 7**, whose subject is one-sided versus two-sided infinite extendability in the four-letter Abelian-square-free language.

## Epistemic status

- `PAPER8_STATUS = ACTIVE_RESEARCH_CANDIDATE`
- `NOVELTY_STATUS = NOT_ESTABLISHED`
- `H8_STATUS = EXPLORATORY_DISCOVERY`
- `H8_FUTURE_BLIND_HOLDOUT = FORFEITED`
- `H9_OPENED = NO`
- The full continuum soft-to-hard sign theorem is **not proved yet**.

## Start here

1. `PAPER8_STATE.md`
2. `PAPER8_CLAIM_LEDGER.md`
3. `PAPER8_NEXT_RESEARCH_PLAN.md`
4. `PAPER8_AI_HANDOFF.md`
5. `PAPER8_MACHINE_SUMMARY.json`
6. `core/docs/H8_PROFILE_RESPONSE_MECHANISM_REPORT_v2_2026-09-02.md`
7. `core/docs/GAMMA_RESOLVENT_RETURN_KERNEL_DERIVATION.md`

## Directory layout

- `core/` — curated reports, key data, graph checkpoint, key calculators.
- `latest_research_state/h8cp/` — the complete latest H8/Paper8 scratch state, including quotient, S3, Doeblin, orbit and return-kernel experiments.
- `legacy_h8_v4/` — complete v4 H8 checkpoint retained for provenance and replay.
- `SHA256SUMS.txt` — hashes for every file in this package except the manifest itself.

## Fast integrity check

```bash
./RUN_FAST.sh
```

No internet is needed to inspect or replay the stored calculations (Python 3.11+, NumPy, SciPy are expected for numerical replays).
