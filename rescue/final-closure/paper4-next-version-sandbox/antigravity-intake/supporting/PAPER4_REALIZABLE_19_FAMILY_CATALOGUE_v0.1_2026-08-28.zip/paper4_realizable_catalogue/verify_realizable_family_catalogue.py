#!/usr/bin/env python3
from itertools import product
from collections import defaultdict
import json

def reduce_sig(terms):
    d={}
    for depth,c in terms:
        if depth:
            d[depth]=d.get(depth,0)+c
    return tuple(sorted((i,c) for i,c in d.items() if c))

def family(L,g,delta,chi,kmin=2):
    if g+delta<0: return None
    out=set()
    for a in range(L):
        for h in range(-(L-1),L):
            i1=a+h
            i2=a+2*h-delta*L
            if 0<=i1<L and 0<=i2<L and g*L+h>=kmin:
                terms=[]
                if chi[0]: terms.append((a,1))
                if chi[1]: terms.append((i1,-2))
                if chi[2]: terms.append((i2,1))
                out.add(reduce_sig(terms))
    return frozenset(out)

def consistent(t):
    g,d,chi=t
    if g+d<0: return False
    if g==0 and chi[0]!=chi[1]: return False
    if g+d==0 and chi[1]!=chi[2]: return False
    return True

def slots(L,realizable):
    out={}
    for g in (0,1,2):
        for d in (-1,0,1):
            if g+d<0: continue
            for chi in product((0,1),repeat=3):
                t=(g,d,chi)
                if realizable and not consistent(t): continue
                out[t]=family(L,*t)
    return out

def domain(L,g,d):
    if g+d<0: return None
    out=set()
    for a in range(L):
        for h in range(-(L-1),L):
            i1=a+h; i2=a+2*h-d*L
            if 0<=i1<L and 0<=i2<L and g*L+h>=2:
                out.add((a,h))
    return frozenset(out)

def shape(sig):
    return tuple(sorted(c for _,c in sig))

def size_formula(fid,L):
    n=L//2
    return [
      1, ((L-3)*(L-3))//4, L-1, (L*L)//4-1, n*(n+1)//2,
      (L*L)//4-1, L-1, n*(n+1)//2, L, L, (L*L+1)//2,
      ((L+1)*(L+1))//4, ((L-1)*(L-1))//4+1, n, (L*L)//4,
      n*(n+1)//2, n, (L*L)//4, n*(n+1)//2
    ][fid]

def classes():
    V=slots(10,True)
    G=defaultdict(list)
    for t,f in V.items(): G[f].append(t)
    return sorted(G.items(),key=lambda kv:min(kv[1]))

def main():
    C=classes()
    assert len(C)==19
    reps=[min(ts) for _,ts in C]
    tests=list(range(5,61))+[80,100,120]
    failures=[]
    for L in tests:
        V=slots(L,True)
        if len(V)!=50 or len(set(V.values()))!=19:
            failures.append(("count",L,len(V),len(set(V.values()))))
        for fid,(_,aliases) in enumerate(C):
            rep=min(aliases); F=family(L,*rep)
            if len(F)!=size_formula(fid,L):
                failures.append(("formula",L,fid,len(F),size_formula(fid,L)))
            for t in aliases:
                if family(L,*t)!=F:
                    failures.append(("alias",L,fid,t))
        if len({family(L,*r) for r in reps})!=19:
            failures.append(("distinct",L))
        if domain(L,1,0)!=domain(L,2,0):
            failures.append(("Z-domain",L))
        if domain(L,1,1)!=domain(L,2,1):
            failures.append(("P-domain",L))
        if domain(L,1,1)-domain(L,0,1)!={(L-2,1)}:
            failures.append(("P-boundary",L))
        if domain(L,2,-1)-domain(L,1,-1)!={(L-1,1-L)}:
            failures.append(("M-boundary",L))

    carry_fail=[]
    cases=0
    for L in range(2,31):
      for K in range(2,4*L+1):
        q,r=divmod(K,L)
        for i0 in range(L):
            i1=(i0+r)%L; c0=(i0+r)//L
            i2=(i1+r)%L; c1=(i1+r)//L
            g1=q+c0; g2=q+c1
            h=i1-i0; delta=g2-g1
            cases+=1
            if h!=r-c0*L or delta!=c1-c0:
                carry_fail.append((L,K,i0))

    print(json.dumps({
      "abstract_L40":{"slots":len(slots(40,False)),
                      "families":len(set(slots(40,False).values()))},
      "realizable_L40":{"slots":len(slots(40,True)),
                        "families":len(set(slots(40,True).values()))},
      "tested_L":tests,
      "family_failures":failures,
      "carry_cases":cases,
      "carry_failures":carry_fail
    },indent=2))

if __name__=="__main__":
    main()
