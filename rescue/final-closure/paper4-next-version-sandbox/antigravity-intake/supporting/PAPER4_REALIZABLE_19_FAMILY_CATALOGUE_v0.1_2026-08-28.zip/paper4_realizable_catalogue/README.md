# Paper 4 Realizable Family Catalogue v0.1

Tightens the Report-9 abstract 29-family catalogue by enforcing that chi(b)
is a function of macro-block position.

Main result:
64 abstract tau slots -> 50 realizable slots -> 19 distinct realizable
depth-aware family sets for L >= 5 (theorem candidate).

Also derives the six carry-based offset domains.
