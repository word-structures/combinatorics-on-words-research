# Paper 4 — Realizable Family Catalogue

**Version:** v0.1  
**Date:** 2026-08-28  
**Status:** sandbox theorem/proof-attempt package; no canonical promotion.  
**Novelty:** `NOVELTY_UNRESOLVED`.

## Executive result

Report 9's repaired compiler uses the abstract index

\[
\tau=(g_1,\delta,\chi(b_0),\chi(b_1),\chi(b_2)),
\]

with \(g_1\in\{0,1,\ge2\}\), giving 64 formal slots and 29 computed support-family sets.

There is an additional exact occurrence-mask constraint:

> **\(\chi\) is a function of macro-block position.**

Whenever two cutpoints lie in the same macro block, their membership bits must be equal. Enforcing this gives

\[
\boxed{64\text{ abstract slots}\to50\text{ realizable slots}}
\]

and these 50 slots collapse, for every tested \(L\ge5\), to

\[
\boxed{19\text{ distinct realizable support families}.}
\]

This is a tightening of the 29-family result, not a rejection of the closed-compiler idea.

## 1. Exact tau normal form

Write the three equally spaced cutpoints as

\[
t_q=b_qL+i_q.
\]

Let

\[
g_1=b_1-b_0,\qquad g_2=b_2-b_1,\qquad \delta=g_2-g_1,
\]

and put

\[
a=i_0,\qquad h=i_1-i_0.
\]

Then exactly

\[
i_0=a,\quad i_1=a+h,\quad i_2=a+2h-\delta L,
\]

while

\[
K=g_1L+h.
\]

For role-membership bits \(\chi_q=\chi(b_q)\), the reduced free-prefix support is

\[
\Phi_\chi(a,h)=
\operatorname{red}\!\left(
\chi_0x_a-2\chi_1x_{a+h}+\chi_2x_{a+2h-\delta L}
\right),
\]

with depth zero absorbed into the target.

Thus each family is the exact image of

\[
D_{g_1,\delta}(L)=
\{(a,h):0\le a,a+h,a+2h-\delta L<L,\;g_1L+h\ge2\}.
\]

## 2. Six geometric domains

Only six different local domains survive:

- \(Z_s=(g_1,\delta)=(0,0)\)
- \(P_t=(0,+1)\)
- \(M_t=(1,-1)\)
- \(Z=(g_1\ge1,0)\)
- \(P=(g_1\ge1,+1)\)
- \(M=(g_1\ge2,-1)\)

because for \(g_1\ge2\) the threshold \(K\ge2\) is automatic.

Moreover

\[
D_P\setminus D_{P_t}=\{(L-2,1)\},
\]

with depth triple \((L-2,L-1,0)\), and

\[
D_M\setminus D_{M_t}=\{(L-1,1-L)\},
\]

with depth triple \((L-1,0,1)\).

So the truncated/full discrepancy is literally **one boundary lattice point on each side**.

## 3. Carry factorization

For

\[
K=qL+r
\]

and carry bits \(c_0,c_1\),

\[
\boxed{
h=r-c_0L,\qquad
g_1=q+c_0,\qquad
g_2=q+c_1,\qquad
\delta=c_1-c_0.
}
\]

Hence the six-domain tau compiler is a quotient of the carry/mechanical-word compiler. The special truncated layer is exactly the \(q=0\), \(K\ge2\) boundary effect.

## 4. Why 64 becomes 50 before any family equality

Three formal slot sectors violate block-membership consistency if all eight bit triples are allowed.

- \(g_1=0,\delta=0\): \(b_0=b_1=b_2\), so only `000` and `111` are possible: 2 rather than 8.
- \(g_1=0,\delta=+1\): \(b_0=b_1\), so \(\chi_0=\chi_1\): 4 rather than 8.
- \(g_1=1,\delta=-1\): \(b_1=b_2\), so \(\chi_1=\chi_2\): 4 rather than 8.

Thus exactly 14 formal slots are impossible:

\[
64-6-4-4=\boxed{50}.
\]

## 5. Why the realizable quotient is 19

Three simplifications finish the reduction.

1. **Outer symmetry.** In every full curvature domain the local equation is symmetric in \(i_0,i_2\), and both outer coefficients are \(+1\). Therefore reversing the outer role bits gives the same family.

2. **Short zero-curvature consistency.** When \(g_1=0,\delta=0\), all cutpoints lie in one block, so only the assigned-only and all-X patterns exist.

3. **One-point truncation.** Positive full vs truncated differs only at \((L-2,L-1,0)\); negative full vs truncated differs only at \((L-1,0,1)\). For the realizable `outer-only` and `111` masks, the added signature is already present in the truncated family. The asymmetric mixed truncated family remains distinct.

Therefore the exact realizable quotient has

\[
1+1+5+6+6=\boxed{19}
\]

families:

- 1 assigned-only/empty-support family,
- 1 short zero-curvature family,
- 5 full zero-curvature families,
- 6 positive-curvature families,
- 6 negative-curvature families.

## 6. Catalogue at L=40

| id | name | representative tau | equivalent realizable tau slots | exact size | size at L=40 |
|---:|---|---|---|---:|---:|
| 0 | EMPTY / assigned-only | `(0,0,000)` | `(0,0,000); (0,1,000); (1,-1,000); (1,0,000); (1,1,000); (2,-1,000); (2,0,000); (2,1,000)` | 1 | 1 |
| 1 | Z-short all-active | `(0,0,111)` | `(0,0,111)` | floor((L-3)^2/4) | 342 |
| 2 | P outer | `(0,1,001)` | `(0,1,001); (1,1,001); (1,1,100); (2,1,001); (2,1,100)` | L-1 | 39 |
| 3 | P-truncated mixed | `(0,1,110)` | `(0,1,110)` | floor(L^2/4)-1 | 399 |
| 4 | P all-active | `(0,1,111)` | `(0,1,111); (1,1,111); (2,1,111)` | C(floor(L/2)+1,2) | 210 |
| 5 | M-truncated mixed | `(1,-1,011)` | `(1,-1,011)` | floor(L^2/4)-1 | 399 |
| 6 | M outer | `(1,-1,100)` | `(1,-1,100); (2,-1,001); (2,-1,100)` | L-1 | 39 |
| 7 | M all-active | `(1,-1,111)` | `(1,-1,111); (2,-1,111)` | C(floor(L/2)+1,2) | 210 |
| 8 | Z outer | `(1,0,001)` | `(1,0,001); (1,0,100); (2,0,001); (2,0,100)` | L | 40 |
| 9 | Z middle | `(1,0,010)` | `(1,0,010); (2,0,010)` | L | 40 |
| 10 | Z mixed | `(1,0,011)` | `(1,0,011); (1,0,110); (2,0,011); (2,0,110)` | ceil(L^2/2) | 800 |
| 11 | Z outer-pair | `(1,0,101)` | `(1,0,101); (2,0,101)` | floor((L+1)^2/4) | 420 |
| 12 | Z all-active | `(1,0,111)` | `(1,0,111); (2,0,111)` | floor((L-1)^2/4)+1 | 381 |
| 13 | P middle | `(1,1,010)` | `(1,1,010); (2,1,010)` | floor(L/2) | 20 |
| 14 | P mixed | `(1,1,011)` | `(1,1,011); (1,1,110); (2,1,011); (2,1,110)` | floor(L^2/4) | 400 |
| 15 | P outer-pair | `(1,1,101)` | `(1,1,101); (2,1,101)` | C(floor(L/2)+1,2) | 210 |
| 16 | M middle | `(2,-1,010)` | `(2,-1,010)` | floor(L/2) | 20 |
| 17 | M mixed | `(2,-1,011)` | `(2,-1,011); (2,-1,110)` | floor(L^2/4) | 400 |
| 18 | M outer-pair | `(2,-1,101)` | `(2,-1,101)` | C(floor(L/2)+1,2) | 210 |

The exact cardinality formulas are lattice-point counts in the six domains after coefficient reduction. They were checked on every \(L=5,\ldots,60\) plus \(80,100,120\), with zero failures.

The exact equality partition of the 50 realizable slots was checked on the same range with zero failures, and all 19 representatives remain pairwise distinct.

## 7. Minimality — carefully scoped

The defensible statement is:

> **Minimal under exact support-family equality.**  
> For \(L\ge5\), the realizable tau slots occupy 19 distinct support-family sets. Every family has a realizable representative. Therefore a catalogue obtained only by identifying equal family sets cannot contain fewer than 19 entries.

This does **not** claim that 19 is the minimum number of automaton states, formulas, theorem lemmas, or implementation branches.

In fact, the six-domain formula may be the conceptually cleaner compiler.

## 8. Relation to the 13 coefficient shapes and Report 9's 29

These count different things:

\[
13\text{ coefficient shapes}
<
19\text{ realizable depth-aware families}
<
50\text{ realizable tau slots}.
\]

Before enforcing membership consistency,

\[
64\text{ abstract tau slots}
\to
29\text{ abstract depth-aware families}.
\]

So the hierarchy is now explicit rather than contradictory.

## 9. What should be audited next

1. Clean-room verify the 64→50→19 correction.
2. Check whether Carpi's C3 already contains an equivalent **six-domain** classification, not merely the scalar second-difference equation.
3. Search the 2026 sieve paper specifically for a finite occurrence-mask family catalogue.
4. Decide whether the paper should headline the **19-family theorem** or the more conceptual **six-domain carry compiler theorem**.

## Epistemic ledger

| claim | status |
|---|---|
| tau lattice normal form | **PROVED FROM DEFINITIONS** |
| six local offset domains | **PROVED FROM DEFINITIONS** |
| 64 formal slots | **PROVED / agrees with Report 9** |
| only 50 are realizable occurrence slots | **PROVED FROM MEMBERSHIP CONSISTENCY** |
| carry-to-tau factorization | **PROVED FROM DEFINITIONS** |
| one-point truncation lemmas | **PROVED FROM DOMAIN EQUATIONS** |
| 19 realizable classes for \(L\ge5\) | **THEOREM CANDIDATE; proof structure + exact checks** |
| 19 minimal under family-set equality | **conditional on clean-room audit of 19-class theorem** |
| 29 as realizable minimum | **FALSE: it counts membership-inconsistent formal slots** |
| novelty | **NOVELTY_UNRESOLVED** |

## Bottom line

\[
\boxed{
\textbf{six carry-derived domains}
\longrightarrow
\textbf{50 realizable tau slots}
\longrightarrow
\textbf{19 realizable depth-aware families}.
}
\]

This is a sharper exact-compiler formulation than the abstract 29-family catalogue.
