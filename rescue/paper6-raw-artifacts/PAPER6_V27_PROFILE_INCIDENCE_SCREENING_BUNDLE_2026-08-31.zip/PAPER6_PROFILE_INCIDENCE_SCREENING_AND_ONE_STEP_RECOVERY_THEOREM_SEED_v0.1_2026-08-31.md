# PAPER 6 — PROFILE-INCIDENCE SCREENING AND ONE-STEP RECOVERY THEOREM SEED v0.1
**Date:** 2026-08-31  
**Status:** new post-v2.6 theorem seed; exact incidence theorem + exact Q2 saturated dimension closure + two-instance dynamic replication. Universal Abelian theorem not yet claimed.

## 0. Why this replaces the v2.6 story

The v2.6 row-count-optimality narrative does not survive the saturated control.
The saturated FULL-L4/Q2 system has more realized four-profile families than
future dimensions,

\[
1228>1176,
\]

but static true-grid profile rank only

\[
850.
\]

Matched random partitions with the same family-size distribution are full rank.
The persistent and INTERIOR-L5 controls show the same qualitative phenomenon.
The correct object to explain is therefore not row-count optimality but

\[
\boxed{\text{structured static aliasing + one-block dynamic recovery}.}
\]

The new observation in this note is that most of the static loss exists **before
continuation-count dynamics are even consulted**.

---

## 1. Profile-to-state incidence operator

Let \(H\) be the saturated raw-history set, let

\[
q:H\to C
\]

be the exact weighted/equitable state map, and let

\[
\lambda_m:H\to\mathcal P^m
\]

be the recency-gauged true-grid profile-history map.

For every realized profile family \(f\) and quotient state \(c\), define

\[
\boxed{
G_{f,c}=\#\{h\in H:\lambda_m(h)=f,\ q(h)=c\}.
}
\]

Thus \(G\) is a nonnegative integer incidence matrix. It is defined before any
future-count Krylov space is chosen.

If

\[
K=[\mathbf 1,Q\mathbf1,Q^2\mathbf1,\ldots]
\]

is a basis matrix for the exact continuation-count future, then the static
profile measurement on that future is exactly

\[
\boxed{GK.}
\]

This factorization separates two possible causes of static information loss:

1. **incidence capacity loss:** \(G\) itself has low row rank;
2. **semantic alignment loss:** independent rows of \(G\) become dependent after
   restriction to the future space.

For \(d=\operatorname{rank}K\), \(r_G=\operatorname{rank}G\), and
\(r=\operatorname{rank}(GK)\), whenever \(r_G\le d\),

\[
\boxed{
d-r=(d-r_G)+(r_G-r).
}
\]

This is elementary linear algebra. The Paper-6 content is the exact Abelian
profile incidence matrices and the highly structured way their rank collapses.

---

## 2. General screening lemma

### Lemma PS1 — proportional incidence implies all-horizon profile aliasing

For two realized profile families \(f,g\), suppose there are nonzero integers
\(a,b\) such that

\[
\boxed{aG_f=bG_g.}
\]

Then for every horizon \(n\ge0\),

\[
\boxed{
a\,G_fQ^n\mathbf1=b\,G_gQ^n\mathbf1.
}
\]

In particular, normalized conditional equality

\[
\frac{G_f}{|f|}=\frac{G_g}{|g|}
\]

forces identical normalized continuation-count sequences for all horizons.

#### Proof
Multiply the exact incidence identity on the right by \(Q^n\mathbf1\). ∎

This gives a purely combinatorial sufficient condition for profile-family
future aliasing. No rank calculation on the future space is required once the
incidence identity is known.

### Corollary PS1a — single-state fibers

If two profile families are each supported on the same single quotient state,
then their incidence rows are proportional and therefore they are all-horizon
future-proportional.

This mechanism occurs repeatedly in the saturated Q2 data.

---

## 3. Suffix-local relation filtration

Write an \(m\)-profile label as

\[
f=(P_1,\ldots,P_m),
\]

with \(P_m\) the most recent profile.

For \(0\le k\le m\), partition the profile-family rows by their common suffix

\[
(P_{m-k+1},\ldots,P_m).
\]

Inside each suffix fiber \(\sigma\), let \(G_\sigma\) be the corresponding
submatrix of \(G\). Define

\[
\boxed{
R_k=\bigoplus_\sigma \ker(G_\sigma^\top).
}
\]

Thus \(R_k\) consists of exact incidence identities that never mix distinct
last-\(k\)-profile suffixes. The spaces form the filtration

\[
R_m\subseteq R_{m-1}\subseteq\cdots\subseteq R_0=\ker(G^\top).
\]

Large \(\dim R_k\) means that older profile coordinates split raw histories in
ways that carry little or no additional exact state information once the recent
profile suffix is fixed.

This is the quantitative form of **profile suffix screening**.

---

## 4. Exact saturated FULL-L4/Q2 incidence theorem

The saturated raw set is

\[
|H|=98868,
\]

and maps to

\[
|C|=1986
\]

weighted/equitable states.

The true-grid four-profile map realizes

\[
1228
\]

families. Its incidence matrix has only

\[
3387
\]

nonzero entries.

### Theorem Q2-I1

\[
\boxed{\operatorname{rank}_{\mathbb Q}G=920.}
\]

Hence

\[
\boxed{\dim\ker(G^\top)=1228-920=308.}
\]

This was computed by exact rational sparse elimination. An exact primitive
integer nullspace basis has support distribution

| support size | number of relations |
|---:|---:|
| 2 | 206 |
| 3 | 62 |
| 4 | 28 |
| 5 | 7 |
| 6 | 2 |
| 8 | 3 |

The mean support is approximately \(2.536\); the maximum is \(8\).

Therefore the profile-incidence deficiency is not a diffuse high-dimensional
numerical accident. It has a basis of very local exact identities.

### Theorem Q2-I2 — exact suffix-screening hierarchy

For the exact relation filtration,

\[
\boxed{
\dim R_4=0,
\quad
\dim R_3=181,
\quad
\dim R_2=260,
\quad
\dim R_1=298,
\quad
\dim R_0=308.
}
\]

Consequences:

- \(181/308\) incidence relations can be generated while keeping the last
  **three** profiles fixed;
- \(260/308\) while keeping the last **two** fixed;
- \(298/308\) while keeping even the **most recent** profile fixed;
- only \(10\) relation dimensions require mixing distinct most-recent profiles.

Thus the overwhelming majority of exact static profile-incidence aliasing is
localized in **older profile coordinates**.

---

## 5. Exact saturated Q2 future dimension

The full Q2 exact recurrence has degree \(1179\) and zero-root multiplicity
\(12\).

On the saturated 1986-state subsystem, the full recurrence polynomial divided
by \(x^3\) annihilates the complete statewise vector sequence exactly:

\[
\boxed{p_{\rm sat}(Q)\mathbf1=0,\qquad \deg p_{\rm sat}=1176.}
\]

The exact residual has zero nonzero coordinates.

A modular Krylov rank of \(1176\) gives the reverse inequality, hence

\[
\boxed{d_{\rm sat}=1176.}
\]

The remaining zero-root multiplicity is \(9\). After the nilpotent transient is
removed, modular rank \(1167\) together with the divided persistent polynomial
gives

\[
\boxed{d_{\rm pers}=1167.}
\]

---

## 6. Static hidden-sector decomposition

The independently exact saturated four-profile static ranks are

\[
\operatorname{rank}(GK)=850,
\qquad
\operatorname{rank}(GK_{\rm pers})=845.
\]

Therefore the full hidden sector is

\[
1176-850=326.
\]

Using the exact incidence rank \(920\), this splits as

\[
\boxed{326=256+70,}
\]

where

\[
256=1176-920
\]

is **forced purely by profile-incidence capacity**, and

\[
70=920-850
\]

is the additional **future-semantic alignment loss**.

Persistent:

\[
1167-845=322
\]

splits as

\[
\boxed{322=247+75,}
\]

with

\[
247=1167-920,
\qquad
75=920-845.
\]

Thus roughly three quarters of the large persistent hidden sector is already
forced before continuation dynamics are considered.

This is a much more specific mechanism than the earlier statement that the
profile measurement is merely non-generic.

---

## 7. Dynamic recovery

Although \(G\) has exact row rank only \(920\), one block shift expands the
state-space row span dramatically:

\[
\operatorname{rank}_{65521}
\begin{bmatrix}
G\\GQ
\end{bmatrix}
=1550.
\]

Restricted to the exact future space,

\[
\boxed{
\operatorname{rank}
\begin{bmatrix}
GK\\GQK
\end{bmatrix}
=1176.
}
\]

On the persistent future,

\[
\boxed{
\operatorname{rank}
\begin{bmatrix}
GK_{\rm pers}\\GQK_{\rm pers}
\end{bmatrix}
=1167.
}
\]

Hence

\[
\boxed{\nu_4=2}
\]

in the saturated system.

The new interpretation is:

> the true-grid Parikh partition spends many static measurement families on
> older-profile refinements that are already linearly redundant at the
> profile-to-state incidence level; the block transition transports the hidden
> information into new row directions, and one shift is enough to make those
> directions transverse to the complete counting future.

The final clause is still a finite-system theorem. A universal transport proof
is the next gate.

---

## 8. Matched random control at the incidence level

A deterministic random partition was generated with:

- the same 98,868 saturated raw histories;
- exactly 1,228 families;
- exactly the same multiset of family sizes as the true profile partition.

For seed 0,

\[
\boxed{\operatorname{rank}_{65521}G_{\rm rand}=1228.}
\]

Because 1228 is the maximum possible row rank, this proves

\[
\boxed{\operatorname{rank}_{\mathbb Q}G_{\rm rand}=1228.}
\]

The same partition gives exact full ranks on both future spaces:

\[
\boxed{1176/1176,\qquad1167/1167.}
\]

Therefore the exact incidence deficiency

\[
1228\to920
\]

is not forced by the family count or family-size distribution.

It is a property of the structured Parikh partition.

---

## 9. Independent INTERIOR-L5/Q1 replication

For the saturated INTERIOR-L5/Q1 system:

\[
2820\text{ raw histories}\to94\text{ weighted states}.
\]

Three true-grid profiles realize

\[
68
\]

families. The exact incidence matrix has

\[
179
\]

nonzero entries and

\[
\boxed{\operatorname{rank}_{\mathbb Q}G=56.}
\]

Hence the exact incidence nullity is

\[
\boxed{12.}
\]

The exact suffix-local incidence filtration is

\[
\boxed{
\dim R_3=0,
\quad
\dim R_2=7,
\quad
\dim R_1=10,
\quad
\dim R_0=12.
}
\]

The saturated full future has dimension \(70\). Its static profile rank is
\(56\), so

\[
\boxed{14=70-56}
\]

hidden dimensions are explained entirely by incidence capacity: there is no
additional full-future alignment loss in this instance.

On the exact 64-dimensional persistent future, the static rank is \(54\), so

\[
\boxed{10=(64-56)+(56-54)=8+2.}
\]

One block step gives full ranks

\[
\boxed{70,\qquad64.}
\]

The state-space row span itself grows from

\[
56\to91
\]

modulo 65521 after adjoining \(GQ\).

Thus the same mechanism occurs at a different block length and in a different
selected library:

\[
\boxed{
\text{low-rank profile incidence}
\;\longrightarrow\;
\text{static hidden future}
\;\longrightarrow\;
\text{one-step recovery}.
}
\]

---

## 10. Persistent locality signal

For the persistent Q2 response matrix, the family-row nullity is \(383\).
Over both primes 65521 and 65519, suffix-confined nullities are

\[
\boxed{310,\ 370,\ 382,\ 383}
\]

for fixed last 3, 2, 1, and 0 profiles respectively.

There are 159 zero persistent family rows. After removing them, 1,069 nonzero
family rows remain, with nullity \(224\). The two-prime suffix-local dimensions
are

\[
\boxed{151,\ 211,\ 223,\ 224.}
\]

So among nonzero persistent families, all but one relation dimension can be
realized without mixing distinct most-recent profiles.

INTERIOR-L5 shows the same pattern. Its 63 nonzero persistent family rows have
nullity 9, of which 8 dimensions are confined within fixed last-two-profile
suffixes; only one dimension requires global mixing.

This is currently modular locality evidence, not yet an exact rational locality
certificate for the persistent relation filtration.

---

## 11. Candidate combinatorial main theorem

The data now point to the following target.

### Conjectural profile-screening/transport theorem

For selected Abelian-square-free block systems with saturated memory and
true-grid Parikh-history measurement:

1. the profile-to-state incidence operator admits a suffix-local low-rank
   factorization, because sufficiently old whole-block profile information is
   screened by the finite boundary/cutpoint state carried toward the active
   obstruction interface;
2. consequently static profile families can greatly outnumber the exact future
   dimension while still having low incidence rank;
3. under one block transition, the screened boundary information is transported
   into the active cutpoint/continuation interface;
4. when the associated local cut-profile response map is nondegenerate, the
   two-slice operator \([G;GQ]\) is injective on the counting future.

The linear statement in item 4 is classical. The intended new theorem is a
combinatorial sufficient condition, expressed in the bounded-defect /
cut-profile language, that forces items 1 and 3 and certifies the required
nondegeneracy.

---

## 12. Immediate next proof gate

Do **not** return to generic observability-index sweeps.

The next work should be:

1. For each fixed recent-profile suffix \(\sigma\), express the incidence block
   \(G_\sigma\) through the old-side cut-profile/fragment state.
2. Prove an upper bound on \(\operatorname{rank}G_\sigma\) from the number of
   realized fragment signatures, rather than from matrix elimination.
3. Test whether the exact Q2 values
   \(181,260,298,308\) and L5 values \(7,10,12\) are generated by this fragment
   factorization.
4. Show how one block shift moves the relevant fragment signature into a
   successor obstruction channel using the existing fragment-transport and
   bounded-defect formulas.
5. State a local nondegeneracy condition under which
   \(V_{\rm cnt}\cap\ker G\cap\ker GQ=\{0\}\).

If steps 2 and 4 close, Paper 6 has a genuine Abelian-specific theorem rather
than a catalogue of ranks.
