import json,numpy as np,subprocess,tempfile,os
from scipy.sparse import coo_matrix
P=65521
ROOT='.'
states=[x.decode('ascii').rstrip('\x00') for x in np.load('P6_Q2_RAW_STATES_S21.npy')];cl=np.load('P6_Q2_RAW_TO_EQUITABLE_CLASS_U16.npy').astype(int)
idx=np.array([i for i,s in enumerate(states) if len(s)==21],dtype=int);sat=sorted(set(cl[idx]));o2n={c:i for i,c in enumerate(sat)}
def canon(s):
 o=[]
 for c in reversed(s):
  if c not in o:o.append(c)
  if len(o)==3:break
 for c in 'abc':
  if c not in o:o.append(c)
 mp={o[i]:'abc'[i] for i in range(3)};return ''.join(mp[c] for c in s)
def pk(w):return tuple(w.count(c) for c in 'abc')
def lab(s):
 t=canon(s);return tuple(pk(t[i:i+4]) for i in [5,9,13,17])
mp={};gids=[]
for i in idx:gids.append(mp.setdefault(lab(states[i]),len(mp)))
sizes=np.bincount(gids,minlength=len(mp)); assert len(sizes)==1228
qf=json.load(open('P6_Q2_EQUITABLE_QUOTIENT_SPARSE_v0.1_2026-08-30.json'))['rows'];rr=[];cc=[];dd=[]
for oi in sat:
 for oj,w in qf[oi]:rr.append(o2n[oi]);cc.append(o2n[int(oj)]);dd.append(int(w))
Q=coo_matrix((dd,(rr,cc)),shape=(1986,1986)).tocsr()
K=np.empty((1986,1176),dtype=np.int64);v=np.ones(1986,dtype=np.int64)
for h in range(1176):
 K[:,h]=v
 if h<1175:v=np.asarray(Q.dot(v)).ravel()%P
exe='/mnt/data/p6_work/rankmod'
def rank(A,tag):
 A=(np.asarray(A,dtype=np.int64)%P).astype(np.uint16);fn=f'/mnt/data/p6_work/{tag}.u16';A.tofile(fn)
 pr=subprocess.run([exe,fn,str(A.shape[0]),str(A.shape[1]),str(P)],capture_output=True,text=True,check=True)
 os.remove(fn);return int(pr.stdout.strip().splitlines()[-1])
out=[]
classnew=np.array([o2n[int(cl[i])] for i in idx],dtype=np.int32)
for seed in range(5):
 rng=np.random.default_rng(seed);perm=rng.permutation(len(idx));gr=np.empty(len(idx),dtype=np.int32);pos=0
 for g,sz in enumerate(sizes):gr[perm[pos:pos+sz]]=g;pos+=int(sz)
 G=coo_matrix((np.ones(len(idx),dtype=np.int64),(gr,classnew)),shape=(1228,1986)).tocsr();G.sum_duplicates()
 rg=rank(G.toarray(),f'randG_{seed}')
 A=G.dot(K)%P
 rf=rank(A,f'randF_{seed}');rp=rank(A[:,9:],f'randP_{seed}')
 out.append({'seed':seed,'incidence_rank_mod65521':rg,'full_future_rank_mod65521':rf,'persistent_rank_mod65521':rp})
 print(out[-1],flush=True)
open('/mnt/data/p6_work/random_incidence_control.json','w').write(json.dumps(out,indent=2))
