from pathlib import Path
import json, numpy as np, subprocess, hashlib, time
from scipy.sparse import coo_matrix
ROOT=Path('.')
OUT=Path('/mnt/data/p6_work')
states=[x.decode('ascii').rstrip('\x00') for x in np.load('P6_Q2_RAW_STATES_S21.npy')]
classes=np.load('P6_Q2_RAW_TO_EQUITABLE_CLASS_U16.npy').astype(int)
sat_raw=[i for i,s in enumerate(states) if len(s)==21]
sat_old=sorted(set(int(classes[i]) for i in sat_raw)); old2new={c:i for i,c in enumerate(sat_old)}
qfull=json.load(open('P6_Q2_EQUITABLE_QUOTIENT_SPARSE_v0.1_2026-08-30.json'))['rows']
Q=[]; rr=[];cc=[];dd=[]
for oi in sat_old:
    row=[]
    for oj,w in qfull[oi]:
        nj=old2new[int(oj)]; row.append((nj,int(w)));rr.append(old2new[oi]);cc.append(nj);dd.append(int(w))
    Q.append(row)
N=len(Q)
rec=json.load(open('P6_BLOCKRANGE_Q2_EXACT_RECURRENCE_CERT_v0.1_2026-08-30.json'))
C=[int(x) for x in rec['connection_polynomial_coefficients_C0_to_C1179']]
assert len(C)==1180 and all(x==0 for x in C[-12:])
D=1176
# exact p_sat(Q)1 residual: sum_{h=0}^D C[D-h] Q^h 1
v=[1]*N
res=[0]*N
maxdigits=1
t=time.time()
for h in range(D+1):
    coef=C[D-h]
    if coef:
        for i,x in enumerate(v):res[i]+=coef*x
    if h in (0,100,500,1000,1176):
        md=max(len(str(abs(x))) for x in v if x)
        maxdigits=max(maxdigits,md)
        print('exact h',h,'digits',md,flush=True)
    if h<D:
        v=[sum(w*v[j] for j,w in row) for row in Q]
nonzero=sum(1 for x in res if x);maxabs=max((abs(x) for x in res),default=0)
# modular Krylov K
P=65521
Qs=coo_matrix((np.array(dd,dtype=np.int64),(rr,cc)),shape=(N,N)).tocsr()
K=np.empty((N,D),dtype=np.uint16); vm=np.ones(N,dtype=np.int64)
for h in range(D):
    K[:,h]=(vm%P).astype(np.uint16)
    if h<D-1:vm=np.asarray(Qs.dot(vm)).ravel()%P
fn=OUT/'sat_K_65521.u16';K.tofile(fn)
exe=OUT/'rankmod'
def rankfile(path,m,n):
    pr=subprocess.run([str(exe),str(path),str(m),str(n),str(P)],capture_output=True,text=True,check=True)
    return int(pr.stdout.strip().splitlines()[-1])
rfull=rankfile(fn,N,D)
# persistent columns h=9..1175, 1167 columns
Kp=K[:,9:];fnp=OUT/'sat_Kpers_65521.u16';Kp.tofile(fnp);rpers=rankfile(fnp,N,Kp.shape[1])
fn.unlink();fnp.unlink()
out={
 'date':'2026-08-31',
 'system':'FULL_L4_Q2_SATURATED',
 'saturated_raw_histories':len(sat_raw),
 'saturated_weighted_states':N,
 'closure_check':'All quotient successors of saturated classes remain in the saturated class set.',
 'source_recurrence_degree':1179,
 'source_zero_root_multiplicity':12,
 'saturated_annihilator':'full Q2 exact recurrence polynomial divided by x^3',
 'saturated_annihilator_degree':1176,
 'saturated_zero_root_multiplicity':9,
 'exact_vector_annihilation_nonzero_coordinates':nonzero,
 'exact_vector_annihilation_max_abs_residual':str(maxabs),
 'mod65521_krylov_rank_h0_to_h1175':rfull,
 'exact_full_future_dimension':1176 if nonzero==0 and rfull==1176 else None,
 'persistent_shift':9,
 'mod65521_persistent_krylov_rank_h9_to_h1175':rpers,
 'exact_persistent_future_dimension':1167 if nonzero==0 and rpers==1167 else None,
 'max_exact_future_value_decimal_digits_sampled':maxdigits,
 'exact_elapsed_seconds':time.time()-t,
 'proof_full':'p_sat(Q)1=0 gives dimension <=1176; a 1176-column modular Krylov minor has rank1176, hence dimension over Q >=1176.',
 'proof_persistent':'p_sat=x^9 p_pers with deg p_pers=1167, so p_pers(Q)Q^9 1=0 gives <=1167; modular rank of Q^9 1,...,Q^1175 1 is1167, hence equality over Q.'
}
(OUT/'P6_SATURATED_Q2_EXACT_VECTOR_DIMENSION_CERT_v0.1_2026-08-31.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
