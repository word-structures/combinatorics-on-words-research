# PAPER 6 — RESEARCH CHECKPOINT v2.7
**Date:** 2026-08-31

## Headline

The v2.6 row-count-optimality story is retired.

The strongest current mechanism is now:

\[
\boxed{\text{Parikh profile-incidence screening + one-step dynamic recovery}.}
\]

## New exact Q2 saturated closure

- saturated raw histories: 98,868;
- saturated weighted states: 1,986;
- exact full future dimension: 1,176;
- exact persistent dimension: 1,167;
- true-grid four-profile families: 1,228;
- exact profile-incidence rank: 920;
- exact incidence nullity: 308;
- exact static future rank: 850;
- exact persistent static rank: 845;
- one-step ranks: 1,176 and 1,167.

The 326-dimensional full hidden sector decomposes as

\[
326=(1176-920)+(920-850)=256+70.
\]

The 322-dimensional persistent hidden sector decomposes as

\[
322=(1167-920)+(920-845)=247+75.
\]

So most static loss is forced by the low rank of the raw profile-to-state
incidence matrix itself.

## Exact suffix-local incidence hierarchy

FULL-L4/Q2:

\[
0,181,260,298,308
\]

for relation spaces confined to fixed last 4, 3, 2, 1, 0 profile suffixes.

INTERIOR-L5/Q1:

\[
0,7,10,12
\]

for fixed last 3, 2, 1, 0 suffixes.

This is the first cross-instance evidence that the aliasing is concentrated in
older profile coordinates rather than being arbitrary linear dependence.

## Random control

A matched random seed-0 partition with the identical Q2 family-size
multiset has exact incidence rank 1,228 and exact full ranks 1,176 / 1,167 on
full/persistent futures.

Thus the 1,228 -> 920 collapse is structural to the Parikh partition.

## Current theorem target

Prove the low ranks of the fixed-suffix incidence blocks from bounded-defect /
cut-profile fragment data, then use fragment transport to prove one-step
recovery under a local nondegeneracy condition.

The immediate object is no longer the 378 future relations one by one. Their
locality led to a stronger factorization target: explain the incidence operator
\(G\) itself.

## Epistemic boundary

Exact now:

- Q2 saturated full/persistent future dimensions;
- Q2 incidence rank 920 and 308-dimensional exact incidence nullspace;
- Q2 exact suffix-local incidence dimensions;
- L5 incidence rank 56 and exact suffix-local incidence dimensions;
- matched random seed-0 full incidence rank.

Still to close combinatorially:

- a fragment/cutpoint formula that predicts the incidence ranks without matrix
  elimination;
- an Abelian-specific proof that one shift makes the hidden sector observable;
- exact rational persistent-locality certificates for the suffix filtration.
