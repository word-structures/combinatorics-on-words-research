from pathlib import Path
from collections import defaultdict,Counter
import json,importlib.util
H=Path('/mnt/data')
D=json.load(open(H/'P6_Q2_EQUITABLE_QUOTIENT_SPARSE_v0.1_2026-08-30.json'));Q=D['rows'];n=len(Q)
O=json.load(open(H/'P6_Q2_TWISTED_RESPONSE_ORBITS_FULL_v0.1_2026-08-30.json'));reps=O['representatives']
spec=importlib.util.spec_from_file_location('fb',H/'p6_affine_fast_builder.py');fb=importlib.util.module_from_spec(spec);spec.loader.exec_module(fb);p6=fb.p6
B=p6.library(4);masks,fm=fb.compile_masks(B,4,11);allmask=(1<<len(B))-1
def lm(s):
 m=fm[s[-3:]]
 for k,j in fb.geometries(4,11):
  r=fb.requirement(s,k,j)
  if r is not None:m|=masks[(k,j)].get(r,0)
 return allmask & ~m
G=defaultdict(list)
for i,s in enumerate(reps):G[lm(s)].append(i)
groups=list(G.values()); gens=[]; meta=[]
for gid,g in enumerate(groups):
 r=g[0]
 for i in g[1:]:gens.append((1<<i)^(1<<r));meta.append((r,i,gid))
print('types',len(groups),'gens',len(gens),flush=True)
QB=[]
for row in Q:
 x=0
 for j,w in row:
  if w&1:x^=1<<j
 QB.append(x)
def mul(x):
 o=0
 while x:
  l=x&-x;i=l.bit_length()-1;x-=l;o^=QB[i]
 return o
def rank(vs):
 piv={}
 for x in vs:
  while x:
   p=x.bit_length()-1
   if p in piv:x^=piv[p]
   else:piv[p]=x;break
 return len(piv)
A=gens[:]; vanish=[None]*len(A); out=[]
for h in range(0,21):
 for i,x in enumerate(A):
  if x==0 and vanish[i] is None:vanish[i]=h
 out.append({'h':h,'rank_GF2':rank(A),'nonzero_generators':sum(x!=0 for x in A),'newly_zero_generators':sum(v==h for v in vanish)})
 print(out[-1],flush=True)
 A=[mul(x) for x in A]
# first count divergence for basis pairs exactly using Q integer counts 0..12
v=[1]*n; sig=[[] for _ in range(n)]
for h in range(13):
 for i,x in enumerate(v):sig[i].append(x)
 v=[sum(w*v[j] for j,w in row) for row in Q]
divs=Counter(); same_all_prefix=0
examples={}
for r,i,gid in meta:
 h=next((h for h in range(13) if sig[r][h]!=sig[i][h]),None)
 divs[str(h) if h is not None else 'none_0_12']+=1
 if h is not None and str(h) not in examples:examples[str(h)]={'classes':[r,i],'states':[reps[r],reps[i]],'counts_r':sig[r][:h+2],'counts_i':sig[i][:h+2]}
 if h is None:same_all_prefix+=1
res={'date':'2026-08-30','field':'GF2 for distribution fates; exact integers for scalar divergence','exact_response_types':len(groups),'basis_pair_differences':len(gens),'rank_progression':out,'vanish_depth_histogram':dict(Counter(str(v) if v is not None else 'not_by_20' for v in vanish)),'first_scalar_count_divergence_histogram':dict(divs),'examples_by_first_divergence':examples}
(H/'P6_Q2_EXACT_RESPONSE_DEFECT_FATE_GF2_v0.1_2026-08-30.json').write_text(json.dumps(res,indent=2),encoding='utf-8')
print('vanish',res['vanish_depth_histogram']);print('divs',res['first_scalar_count_divergence_histogram'])
