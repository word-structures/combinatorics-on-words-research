#!/usr/bin/env python3
"""Replay the Q2 persistent latent-fringe counterexample."""
from pathlib import Path
import json, importlib.util
H=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("fb",H/"p6_affine_fast_builder.py")
fb=importlib.util.module_from_spec(spec);spec.loader.exec_module(fb);p6=fb.p6
B=p6.library(4); masks,fm=fb.compile_masks(B,4,11); allmask=(1<<len(B))-1; mem=21
A="aaabaaacaaabbbcabccca"
C="aaabaaacaaabbbcbaccca"

def legalmask(s):
    m=fm[s[-3:]]
    for k,j in fb.geometries(4,11):
        r=fb.requirement(s,k,j)
        if r is not None:m |= masks[(k,j)].get(r,0)
    return allmask & ~m

assert legalmask(A)==legalmask(C)
assert [B[i] for i in range(len(B)) if (legalmask(A)>>i)&1] == ["aaba","aabb","aabc","aacb","aacc"]

expected={
 "aaba":["cccb"],
 "aabb":[],
 "aabc":["accc"],
 "aacb":["accc","cacb","cacc"],
 "aacc":[],
}
for x,extra in expected.items():
    LA=legalmask((A+x)[-mem:])
    LC=legalmask((C+x)[-mem:])
    got=[B[i] for i in range(len(B)) if ((LC&~LA)>>i)&1]
    assert got==extra

print("PASS")
print("Same exact current response, but latent internal-order difference activates after one matched block.")
