# PAPER 6 — TRANSIENT ALGEBRA ACROSS Q1 AND Q2 v0.1
**Date:** 2026-08-30  
**Status:** exact structural audit; not a manuscript novelty claim

## Executive result

The Q2 count/equitable split is the first visible **balancing event** in a
nilpotent structure that is already present at Q1.

At Q1, many weighted state distributions already coalesce after two steps, but
their short transient count impulses do not balance.

At Q2, exactly two such balances become perfect, producing the first natural
count-equivalent/non-equitable Abelian-avoidance states.

This separates two concepts:

\[
\boxed{
\text{eventual weighted-distribution equivalence}
}
\]

from

\[
\boxed{
\text{all-horizon total-count equivalence}.
}
\]

---

# 1. Distributional tail equivalence

For a finite weighted quotient \(Q\), define

\[
i\equiv_h^{\rm dist}j
\quad\Longleftrightarrow\quad
e_i^\top Q^h=e_j^\top Q^h.
\]

Then the complete weighted successor distributions agree after \(h\) steps and
forever thereafter:

\[
e_i^\top Q^n=e_j^\top Q^n
\qquad(n\ge h).
\]

This is stronger than eventual scalar-count equality.

To obtain all-horizon count equivalence, the finite transient prefix must also
agree:

\[
e_i^\top Q^k\mathbf1
=
e_j^\top Q^k\mathbf1
\qquad
0\le k<h.
\]

---

# 2. Q1 already contains two-step coalescence

For full L4 aa2fr at

\[
Q=1,\qquad K_{\max}=7,
\]

the exact stable weighted quotient has 252 classes.

All 252 one-step weighted rows are distinct.

But the exact two-step distributions have only

\[
\boxed{240}
\]

distinct rows.

There are 12 duplicate \(Q^2\)-row groups containing 24 classes.

So nilpotent/distributional redundancy already exists at Q1.

However, adding the one-step total count gives

\[
\boxed{
252
}
\]

distinct keys

\[
\big(c_1(i),e_i^\top Q^2\big).
\]

Therefore none of the Q1 tail-coalescent pairs is all-horizon count equivalent.

This explains why the earlier Q1 result still had

\[
\text{count classes}
=
\text{equitable classes}
=
252.
\]

---

# 3. Q2 is the first balancing threshold

At

\[
Q=2,\qquad K_{\max}=11,
\]

the 2691-state equitable quotient has only

\[
\boxed{2446}
\]

distinct \(Q^2\) rows.

There are:

- 217 duplicate \(Q^2\)-row groups;
- 462 classes participating in such groups.

But when the one-step count is included, the key

\[
\boxed{
\big(c_1(i),e_i^\top Q^2\big)
}
\]

has exactly

\[
\boxed{2689}
\]

distinct values.

Its only non-singletons are

\[
\boxed{
\{224,1021\}
}
\]

and

\[
\boxed{
\{1645,2244\}.
}
\]

These are exactly the two independently certified all-horizon count merges.

Thus:

> **every Q2 count merge is completely explained by two-step weighted
> distribution coalescence plus equality of the finite one-step transient
> count.**

No deeper scalar cancellation is needed for these state merges.

---

# 4. Exact row-coalescence progression at Q2

The number of distinct exact weighted rows of \(Q^h\) is:

| h | distinct rows |
|---:|---:|
| 1 | 2691 |
| 2 | 2446 |
| 3 | 2335 |
| 4 | 2328 |
| 5 | 2328 |

The set-valued coalescence therefore stabilizes very quickly.

This does **not** mean the whole scalar future space has dimension 2328.
Linear combinations can compress much further, and the exact scalar Hankel
dimension is only 1179.

The hierarchy is:

\[
\text{state identity}
\to
\text{finite-step distribution identity}
\to
\text{scalar count identity}
\to
\text{linear future relations}.
\]

---

# 5. Scalar transient factor has an operational meaning

The exact Q2 scalar recurrence polynomial factors as

\[
m(x)=x^{12}g(x),
\qquad
\deg g=1167,
\quad g(0)\ne0.
\]

If the \(x^{12}\) factor is removed and the degree-1167 recurrence defined by
\(g\) is applied directly to the original count sequence, it fails at exactly
12 consecutive positions:

\[
n=1167,\ldots,1178.
\]

It holds exactly from

\[
\boxed{n=1179}
\]

onward.

The 12 nonzero residuals are therefore a finite-support transient impulse.

Over the independent prime \(1\,000\,000\,009\), Berlekamp--Massey on shifted
tails gives:

| sequence shift | degree | zero-root multiplicity |
|---:|---:|---:|
| 0 | 1179 | 12 |
| 1 | 1178 | 11 |
| 2 | 1177 | 10 |
| \(\vdots\) | \(\vdots\) | \(\vdots\) |
| 11 | 1168 | 1 |
| 12 | **1167** | **0** |
| 13+ | **1167** | **0** |

Thus each discarded initial term removes one level of the scalar nilpotent
chain until the persistent system is reached.

This is a clean time-domain interpretation of

\[
1179=12+1167.
\]

---

# 6. State-level and scalar-level transients are the same kind of algebra

The Q2 source-pair certificate has

\[
(e_s-e_t)Q^2=0.
\]

That difference produces only a finite transient impulse.

The global scalar recurrence has an \(x^{12}\) factor, which likewise produces
a finite-support transient residual before the degree-1167 persistent
recurrence takes over.

These are two manifestations of the same general decomposition:

\[
\boxed{
\text{nilpotent finite-depth future}
\oplus
\text{persistent nonzero-spectrum future}.
}
\]

The exact dimensions and chains depend on the chosen initial/terminal
observables.

---

# 7. Consequence for the next Paper-6 analysis

The 1179-dimensional Q2 scalar future should no longer be treated as one
object.

For asymptotic survival, the scientifically relevant piece is

\[
\boxed{1167}
\]

persistent dimensions.

The 12 nilpotent dimensions should be recorded and certified, but then stripped
away before searching for the long-term obstruction structure.

Likewise, state-level structural analyses should quotient or mark finite-depth
branch impulses separately from persistent distinctions.

This avoids spending theory effort explaining initialization/dead-end
phenomena as if they were asymptotic dynamics.

---

## Current verdict

The block-range hierarchy now exhibits a coherent transient progression:

- Q1: distributional coalescence exists, but no balanced count merge;
- Q2: the first exact nilpotent balances produce two count merges;
- the global scalar process simultaneously develops a 12-level transient chain
  before entering a 1167-dimensional persistent recurrence.

The next gate should analyze the persistent Q2 dynamics **after this transient
algebra has been removed**.
