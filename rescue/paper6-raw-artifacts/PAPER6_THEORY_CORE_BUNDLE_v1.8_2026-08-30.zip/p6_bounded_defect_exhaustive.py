#!/usr/bin/env python3
"""Independent exhaustive validator for Paper-6 bounded-defect theorem."""
from itertools import product
import json
from pathlib import Path
import importlib.util

def parikh(w, alphabet):
    return tuple(w.count(a) for a in alphabet)

def add(a,b): return tuple(x+y for x,y in zip(a,b))
def sub(a,b): return tuple(x-y for x,y in zip(a,b))
def scale(c,a): return tuple(c*x for x in a)

def theorem_parts(blocks,L,s,K,alphabet):
    q,r=divmod(K,L)
    assert q >= 1
    m0,i0=divmod(s,L)
    m1,i1=divmod(s+K,L)
    m2,i2=divmod(s+2*K,L)
    c0=(m1-m0)-q
    c1=(m2-m1)-q
    assert c0 in (0,1) and c1 in (0,1)

    P=[parikh(b,alphabet) for b in blocks]
    z=(0,)*len(alphabet)

    left=z
    for t in range(m1-q,m1):
        left=add(left,P[t])

    right=z
    for t in range(m1,m1+q):
        right=add(right,P[t])

    D=sub(right,left)

    E=z
    if c1:
        E=add(E,P[m1+q])
    if c0:
        E=sub(E,P[m0])

    E=add(E,parikh(blocks[m0][:i0],alphabet))
    E=add(E,scale(-2,parikh(blocks[m1][:i1],alphabet)))
    if i2:
        E=add(E,parikh(blocks[m2][:i2],alphabet))

    return D,E

def direct_difference(blocks,s,K,alphabet):
    w=''.join(blocks)
    return sub(
        parikh(w[s+K:s+2*K],alphabet),
        parikh(w[s:s+K],alphabet)
    )

def exhaustive_all(alphabet,L,nblocks):
    B=[''.join(x) for x in product(alphabet,repeat=L)]
    R=2*L-2
    tests=0
    defects=set()
    max_linf=0
    for blocks in product(B,repeat=nblocks):
        N=L*nblocks
        for K in range(L,N//2+1):
            for s in range(N-2*K+1):
                D,E=theorem_parts(blocks,L,s,K,alphabet)
                direct=direct_difference(blocks,s,K,alphabet)
                assert add(D,E)==direct
                assert sum(E)==0
                linf=max(abs(x) for x in E)
                assert linf<=R
                tests+=1
                max_linf=max(max_linf,linf)
                defects.add(E)
    return {
        "scope":f"ALL_{len(alphabet)}LETTER_L{L}_{nblocks}BLOCKS",
        "alphabet":alphabet,
        "block_length":L,
        "block_count":len(B),
        "assemblies":len(B)**nblocks,
        "tests":tests,
        "mismatches":0,
        "zero_sum_failures":0,
        "bound_failures":0,
        "observed_defects":len(defects),
        "observed_max_Linf":max_linf,
        "theorem_bound":R,
    }

def full_l4_aa2fr():
    spec=importlib.util.spec_from_file_location(
        "p6", Path(__file__).with_name("p6_semantics_audit.py")
    )
    p6=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(p6)
    B=p6.library(4)
    L=4
    R=6
    tests=0
    defects=set()
    max_linf=0
    squares=0

    for blocks in product(B,repeat=3):
        N=12
        for K in range(L,N//2+1):
            for s in range(N-2*K+1):
                D,E=theorem_parts(blocks,L,s,K,"abc")
                direct=direct_difference(blocks,s,K,"abc")
                assert add(D,E)==direct
                assert sum(E)==0
                assert max(abs(x) for x in E)<=R
                if direct==(0,0,0):
                    squares+=1
                tests+=1
                defects.add(E)
                max_linf=max(max_linf,max(abs(x) for x in E))

    return {
        "scope":"ALL_L4_AA2FR_3BLOCK",
        "alphabet":"abc",
        "block_length":4,
        "block_count":len(B),
        "assemblies":len(B)**3,
        "tests":tests,
        "direct_abelian_squares":squares,
        "mismatches":0,
        "zero_sum_failures":0,
        "bound_failures":0,
        "observed_defects":len(defects),
        "observed_max_Linf":max_linf,
        "theorem_bound":R,
    }

def main():
    out=[
        exhaustive_all("ab",3,4),
        exhaustive_all("abc",2,4),
        exhaustive_all("abc",3,3),
        full_l4_aa2fr(),
    ]
    print(json.dumps(out,indent=2))

if __name__=="__main__":
    main()
