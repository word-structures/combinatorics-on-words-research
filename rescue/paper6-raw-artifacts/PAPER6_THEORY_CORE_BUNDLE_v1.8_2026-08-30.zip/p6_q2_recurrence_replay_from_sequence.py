from pathlib import Path
import json, sympy as sp
HERE=Path(__file__).resolve().parent

def BM(seq,mod):
    s=[x%mod for x in seq]; C=[1]; B=[1]; L=0;m=1;b=1
    for n in range(len(s)):
        d=s[n]
        for i in range(1,L+1): d=(d+C[i]*s[n-i])%mod
        if d==0:m+=1;continue
        T=C[:];coef=d*pow(b,mod-2,mod)%mod
        if len(C)<len(B)+m:C += [0]*(len(B)+m-len(C))
        for j in range(len(B)):C[j+m]=(C[j+m]-coef*B[j])%mod
        if 2*L<=n:L=n+1-L;B=T;b=d;m=1
        else:m+=1
    return L,C[:L+1]

def main():
    obj=json.loads((HERE/'P6_Q2_EXACT_COUNT_SEQUENCE_4000_v0.1_2026-08-30.json').read_text()); seq=obj['terms']
    primes=[];x=1000000007
    for _ in range(12):x=int(sp.nextprime(x));primes.append(x);x+=1000
    polys=[]
    for p in primes:
        L,C=BM(seq,p);assert L==1179;polys.append(C)
    coeff=polys[0][:];mod=primes[0]
    for C,p in zip(polys[1:],primes[1:]):
        inv=pow(mod%p,p-2,p);new=[]
        for a,b in zip(coeff,C):new.append(a+mod*(((b-a)%p)*inv%p))
        coeff=new;mod*=p
    coeff=[x if x<=mod//2 else x-mod for x in coeff]
    for n in range(1179,len(seq)):
        assert seq[n]+sum(coeff[i]*seq[n-i] for i in range(1,1180))==0
    tz=0
    for x in reversed(coeff):
        if x==0:tz+=1
        else:break
    assert tz==12
    ref=json.loads((HERE/'P6_BLOCKRANGE_Q2_EXACT_RECURRENCE_CERT_v0.1_2026-08-30.json').read_text())
    assert coeff==ref['connection_polynomial_coefficients_C0_to_C1179']
    print('PASS degree=1179 zero_root=12 exact_equations=',len(seq)-1179)
if __name__=='__main__':main()
