# PAPER 6 — THEORY CORE STATUS v1.4
**Date:** 2026-08-30  
**Status:** active theory checkpoint

## New kill/control result

Twisted-response / latent-fringe differences are strongly non-random under the
future operator, but they do not form a universally small persistent state
space.

### Q1

\[
117\to109\to105\to104
\]

for the response-difference span, while the full stable image has dimension

\[
146.
\]

So response structure captures a proper persistent subspace.

### Q2

\[
2269\to1840\to1553\to\cdots\to1167.
\]

The full stable image is also 1167-dimensional over GF(2).

However, same-sized random partition-difference spaces also fill the 1167
stable image by horizons 11--12.

The structural signal is instead the much faster early rank collapse of the
actual response space.

## Revised interpretation

\[
\boxed{
\text{P4/P5 response/fringe machinery}
=
\text{transient organizer / preconditioner}.
}
\]

It explains finite-depth response redundancy and the Q2 nilpotent count merges.

It does not yet explain the full persistent future dynamics.

## Important symmetry control

The equitable quotients already identify global ternary alphabet
permutations.

Therefore the twisted-response effect is not ordinary global S3 symmetry.

## Next gate — persistent decorated-additive observables

Strip the nilpotent/transient part first.

Then study only the persistent block-profile process:

\[
P_{m+q}-2P_m+P_{m-q}=-E_g.
\]

The target is to find observables whose invariant closure gives:

\[
146 \quad(Q1)
\]

and

\[
1167 \quad(Q2)
\]

without materializing the literal suffix automata.

This is now the central unresolved Paper-6 theorem problem.
