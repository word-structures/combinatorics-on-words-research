# PAPER 6 — THEORY CORE STATUS v0.5
**Date:** 2026-08-30  
**Status:** active research checkpoint

## C7b — completed local interface

For long periods, boundary character information is exactly represented by
finite cut-profile families.

Ternary universal cut-profile type bound:

\[
N_{\rm cut}(L)\le\binom{L+5}{5}.
\]

At L=40:

\[
N_{\rm cut}\le1\,221\,759.
\]

Segmented coefficient-DP reproduced the exact selected-library operators with
zero mismatches in the L4 and L5 clean-room audits.

## C7c — completed first block-range layer

Define Q-template safety by checking all long half-periods

\[
K=qL+r,\qquad1\le q\le Q,\quad0\le r<L,
\]

using the bounded-defect formula, together with the finite short-period layer.

Then

\[
\boxed{
Q\text{-template safety}
\iff
K_{\max}=(Q+1)L-1\text{ character safety}.
}
\]

Independent exhaustive replay:

\[
856\,730\text{ assemblies},\quad0\text{ mismatches}.
\]

## Full L4 Q=1 exact checkpoint

\[
10782\to1507\to252\to153
\]

for:

- raw states;
- exact future-language classes;
- stable weighted count classes;
- exact scalar Hankel dimension.

The exact recurrence has an \(x^7\) factor:

\[
153=7+146.
\]

Thus the first complete long-period block range retains very substantial
future-dynamics compression.

## Current strongest conceptual separation

\[
\boxed{
\text{finite local character layer}
}
+
\boxed{
\text{finite cut-profile defect interface}
}
+
\boxed{
\text{unbounded decorated additive profile dynamics}.
}
\]

Only the third term grows with the long-range cutoff.

## Next gate P6-C7d

Do not increase character-level geometry complexity.

Instead work directly with the decorated profile-prefix-sum process

\[
P_{m+q}-2P_m+P_{m-q}=-E_g.
\]

Primary target:

> construct or approximate the Q-range weighted transfer action directly from
> profile/cut-profile family data and measure its minimal future dimension as Q
> grows.

This is now the central theory problem.
