# PAPER 6 — THEORY CORE STATUS v1.6
**Date:** 2026-08-30  
**Status:** active theory checkpoint

## Signed response semantics established

For a twisted-response pair,

\[
L(t)=\pi L(s),
\]

define

\[
\Delta_{s,t,\pi}
=
\sum_{b\in L(s)}
\left(
e_{\tau(s,b)}-e_{\tau(t,\pi b)}
\right).
\]

Then

\[
c_{n+1}(s)-c_{n+1}(t)
=
\Delta Q^{n-1}\mathbf1.
\]

Thus exact count equivalence is the annihilator condition

\[
\Delta\in V_{\rm cnt}^{\perp}.
\]

## Q2 exact candidate filter

\[
28670
\to2457
\to102
\to3
\to2
\]

using equality of \(c_2,c_3,c_4,c_5\).

The final two are exactly the all-horizon count merges.

## Q1 replication

\[
257\to22\to1\to0.
\]

## Response-tree kill

Q2 exact labelled response-tree types:

\[
1094,\ 2432,\ 2676,\ 2691
\]

at depths 0,1,2,3.

Depth <=2 is unsound for counts.

Depth >=3 reconstructs the full equitable quotient and is too fine.

No response-tree depth equals the 2689 count classes.

## Synchronous-bisimulation kill

Twisted-response pairs surviving same-permutation recursive response matching:

\[
28670\to970\to39\to0.
\]

The true count merges arise from signed cancellation, not bisimulation.

## Persistent-compression kill

Over GF(2), scalar behavior ranks across 1300 horizons are:

\[
1179
\]

for all Q2 state futures,

\[
1177
\]

for twisted-response differences, and

\[
1176
\]

for exact-response differences.

Therefore response defects are not a small persistent future representation.

## Current role of response structure

\[
\boxed{
\text{candidate sieve + exact signed certificate generator}.
}
\]

Not:

\[
\boxed{
\text{persistent state space}.
}
\]

## Next gate

Attack the persistent decorated-additive block-profile dynamics directly.

Response/fringe machinery should remain as a front-end that:

1. compiles current physical candidates;
2. generates signed defect vectors;
3. removes/identifies exact semantic coincidences.

The unresolved compression theorem is now entirely on the persistent
long-range side.
