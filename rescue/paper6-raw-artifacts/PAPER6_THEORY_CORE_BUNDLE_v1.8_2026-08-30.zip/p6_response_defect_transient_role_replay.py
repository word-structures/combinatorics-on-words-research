#!/usr/bin/env python3
"""Replay Q1 twisted-response vs random GF(2) control."""
from pathlib import Path
import subprocess, sys
H=Path(__file__).resolve().parent
subprocess.check_call([sys.executable, str(H/"p6_q1_response_random_audit.py")])
