from pathlib import Path
from collections import defaultdict
import json
HERE=Path(__file__).resolve().parent
obj=json.loads((HERE/'P6_Q2_EQUITABLE_QUOTIENT_SPARSE_v0.1_2026-08-30.json').read_text())
rows=[[(int(j),int(w)) for j,w in row] for row in obj['rows']]
q=len(rows); pairs=[tuple(x) for x in obj['candidate_pairs']]
assert q==2691
v=[1]*q
for _ in range(q):
    for a,b in pairs: assert v[a]==v[b]
    v=[sum(w*v[j] for j,w in row) for row in rows]
cm=list(range(q)); cm[1021]=224; cm[2244]=1645
canon={};cid=[]
for x in cm:
    if x not in canon: canon[x]=len(canon)
    cid.append(canon[x])
assert len(set(cid))==2689
def agg(i):
    d=defaultdict(int)
    for j,w in rows[i]: d[cid[j]]+=w
    return d
for a,b in pairs: assert agg(a)!=agg(b)
print('PASS equitable=2691 exact_count=2689 pairs=',pairs,'horizons=',q)
