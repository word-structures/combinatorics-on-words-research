from pathlib import Path
from collections import defaultdict
from itertools import permutations
import importlib.util,json,random,statistics,time
H=Path('/mnt/data')
spec=importlib.util.spec_from_file_location('fb',H/'p6_affine_fast_builder.py'); fb=importlib.util.module_from_spec(spec); spec.loader.exec_module(fb); p6=fb.p6
B=p6.library(4); K=7
states,edges,labels,init=fb.build_fast(B,K)
print('build',len(states),flush=True)
eq=p6.equitable(states,edges)
Q,groups,rem=p6.quotient(states,edges,eq)
# canonical quotient ids rem[old color]
q=len(Q); print('eq',q,flush=True)
# reps in quotient-index order
reps=[None]*q
for c,ss in groups.items(): reps[rem[c]]=min(ss)
PERMS=[dict(zip('abc',x)) for x in permutations('abc')]
def tw(w,mp):return ''.join(mp[c] for c in w)
def canon(W):return min(tuple(sorted(tw(w,mp) for w in W)) for mp in PERMS)
rg=defaultdict(list)
for i,s in enumerate(reps): rg[canon(labels[s].keys())].append(i)
G=sorted(rg.values(),key=lambda x:x[0]); sizes=[len(g) for g in G]
print('response groups',len(G),'basis',sum(z-1 for z in sizes),flush=True)
# GF2 Q rows
QB=[]
for row in Q:
 x=0
 for j,w in enumerate(row):
  if w&1:x ^= 1<<j
 QB.append(x)
def rank(vs):
 piv={}
 for x in vs:
  while x:
   p=x.bit_length()-1
   if p in piv:x ^= piv[p]
   else:piv[p]=x;break
 return len(piv)
def mulQ(x):
 o=0
 while x:
  l=x&-x;i=l.bit_length()-1;x-=l;o ^= QB[i]
 return o
def makeD(groups):
 A=[]
 for g in groups:
  r=g[0]
  for i in g[1:]:A.append((1<<i)^(1<<r))
 return A
sel=(0,1,2,3,4,5,6,7)
def evalg(groups):
 A=makeD(groups); out={0:rank(A)}
 for h in range(1,8):
  A=[mulQ(x) for x in A]; out[h]=rank(A)
 return out
actual=evalg(G); print('actual',actual,flush=True)
tr=[]
for seed in range(100):
 rng=random.Random(99991+seed); v=list(range(q)); rng.shuffle(v); gg=[];off=0
 for z in sizes:gg.append(v[off:off+z]);off+=z
 tr.append(evalg(gg))
summary={}
for h in sel:
 vals=[x[h] for x in tr];mu=statistics.mean(vals);sd=statistics.pstdev(vals)
 summary[str(h)]={'actual':actual[h],'random_mean':mu,'random_sd':sd,'min':min(vals),'max':max(vals),'z':(actual[h]-mu)/sd if sd else None,'fraction_random_le_actual':sum(v<=actual[h] for v in vals)/len(vals)}
out={'date':'2026-08-30','Q':1,'Kmax':7,'equitable_classes':q,'response_orbits':len(G),'basis_differences':sum(z-1 for z in sizes),'actual':actual,'random_trials':100,'summary':summary,'group_sizes':sizes}
path=H/'P6_Q1_RESPONSE_VS_RANDOM_GF2_v0.1_2026-08-30.json';path.write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2),flush=True)
print(path)
