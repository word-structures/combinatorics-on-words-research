# PAPER 6 — THEORY CORE STATUS v1.0
**Date:** 2026-08-30  
**Status:** major research milestone; not a manuscript

## Current exact theory stack

### Layer 1 — selected-library survival entropy
Growth exists and finite cutoff/window hierarchies converge.

### Layer 2 — profile projection
Aligned block-profile additive squares are universal Abelian obstructions.

### Layer 3 — affine boundary geometry
All crossing cutoff squares are compiled by finite Parikh-difference equations.

### Layer 4 — long-period bounded defect
For \(K=qL+r\),

\[
F(s)-2F(s+K)+F(s+2K)=D_q+E,
\qquad
\|E\|_\infty\le2L-2.
\]

### Layer 5 — cut-profile family compiler
The local long-period boundary information is represented exactly by finite
segment Parikh descriptors and coefficient operators.

Ternary descriptor bound:

\[
N_{\rm cut}(L)\le\binom{L+5}{5}.
\]

### Layer 6 — exact block-range hierarchy

\[
Q
\iff
K_{\max}=(Q+1)L-1.
\]

Increasing Q adds only longer additive-profile comparisons; the local boundary
catalogue does not grow.

### Layer 7 — future semantics
The hierarchy is genuinely strict in the real avoidance system:

\[
\text{equitable}
\supsetneq
\text{count}
\supsetneq
\text{scalar linear}.
\]

At Q2:

\[
2691
\to
2689
\to
1179.
\]

## Exact full-L4 checkpoints

\[
Q=1:
\quad
10782\to1507\to252\to153=7+146.
\]

\[
Q=2:
\quad
218298\to2691\to2689\to1179=12+1167.
\]

## Important killed hypotheses

Do not claim:

- profile alone is a counting state;
- one-step response is a counting state;
- active obstructions alone are sufficient;
- complete obstruction coordinates compress the suffix;
- pairwise obstruction features explain the future space;
- count equivalence always equals equitable equivalence;
- large count-state merging is universal across selected libraries.

## Current scientific core

The Paper-6 question is now:

> **What is the minimal weighted future dynamics of a selected
> Abelian-avoidance block language after local character geometry has been
> compiled into finite decorated additive templates?**

## Next gate P6-C7e

1. Analyze the two natural Q2 count-equivalent/non-equitable pairs.
2. Decompose the 1,167 persistent scalar space by symmetry and structural
   observables.
3. Build matrix-free Q-range application directly from cut-profile families.
4. Attempt Q3 only through that structural Apply path, not by naive suffix
   expansion.
5. Deepen the literature audit specifically on weighted/counting variants of
   additive-template systems.

## Current research grade

The theory core is now materially stronger than at the v0.7 checkpoint.

The major remaining risk is novelty positioning, not mathematical coherence.
