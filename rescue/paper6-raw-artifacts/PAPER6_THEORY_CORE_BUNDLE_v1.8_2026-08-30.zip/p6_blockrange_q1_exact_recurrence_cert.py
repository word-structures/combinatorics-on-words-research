from pathlib import Path
import importlib.util, json
import sympy as sp

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('p6',HERE/'p6_semantics_audit.py')
p6=importlib.util.module_from_spec(spec); spec.loader.exec_module(p6)

def BM(seq,mod):
    s=[x%mod for x in seq]; C=[1]; B=[1]; L=0; m=1; b=1
    for n in range(len(s)):
        d=s[n]
        for i in range(1,L+1): d=(d+C[i]*s[n-i])%mod
        if d==0: m+=1; continue
        T=C[:]; coef=d*pow(b,mod-2,mod)%mod
        if len(C)<len(B)+m: C += [0]*(len(B)+m-len(C))
        for j in range(len(B)): C[j+m]=(C[j+m]-coef*B[j])%mod
        if 2*L<=n: L=n+1-L; B=T; b=d; m=1
        else: m+=1
    return L,C[:L+1]

def crt_pair(a,m,b,p):
    t=((b-a)%p)*pow(m%p,p-2,p)%p
    return a+m*t,m*p

def main():
    B=p6.library(4); K=7
    states,edges,labels,init=p6.build(B,K); eq=p6.equitable(states,edges); Q,groups,rem=p6.quotient(states,edges,eq)
    alpha=p6.initial_alpha(B,2*K-1,eq,rem)
    qrows=[[(j,w) for j,w in enumerate(row) if w] for row in Q]
    v=[1]*len(Q); seq=[]
    for _ in range(700):
        seq.append(sum(alpha[i]*v[i] for i in range(len(Q))))
        v=[sum(w*v[j] for j,w in row) for row in qrows]

    primes=[]; x=1000000007
    for _ in range(10):
        x=int(sp.nextprime(x)); primes.append(x); x+=1000
    polys=[]
    for p in primes:
        L,C=BM(seq,p)
        assert L==153
        polys.append(C)

    coeff=polys[0][:]; modulus=primes[0]
    for C,p in zip(polys[1:],primes[1:]):
        new=[]
        for a,b in zip(coeff,C):
            z,_=crt_pair(a,modulus,b,p); new.append(z)
        coeff=new; modulus*=p
    signed=[x if x<=modulus//2 else x-modulus for x in coeff]
    for n in range(153,len(seq)):
        assert seq[n]+sum(signed[i]*seq[n-i] for i in range(1,154))==0

    H=[[seq[i+j] for j in range(153)] for i in range(153)]
    rank,_,_=p6.mod_rank_and_pivots(H,1000000009)
    assert rank==153
    tz=0
    for x in reversed(signed):
        if x==0: tz+=1
        else: break
    assert tz==7

    out={
      'date':'2026-08-30','library':'ALL_L4_AA2FR','block_length':4,'block_range_Q':1,
      'equivalent_character_Kmax':7,'raw_states':len(states),'stable_weighted_count_classes':len(Q),
      'scalar_hankel_rank_exact':153,'zero_root_multiplicity_exact':7,'persistent_scalar_dimension_exact':146,
      'hankel_153x153_rank_mod_1000000009':rank,'crt_primes':primes,
      'crt_modulus_decimal_digits':len(str(modulus)),'max_abs_recurrence_coefficient':max(abs(x) for x in signed),
      'connection_polynomial_coefficients_C0_to_C153':signed,
      'convention':'s[n] + sum_{i=1}^{153} C[i]*s[n-i] = 0',
      'exact_terms_generated':len(seq),'exact_terms_verified_after_order':len(seq)-153,'exact_count_prefix':seq[:12]
    }
    path=HERE/'P6_BLOCKRANGE_Q1_EXACT_RECURRENCE_CERT_v0.1_2026-08-30.json'
    path.write_text(json.dumps(out,indent=2),encoding='utf-8')
    print('PASS',path)

if __name__=='__main__': main()
