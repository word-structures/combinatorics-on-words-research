from pathlib import Path
from collections import defaultdict
import json,importlib.util,random,statistics
H=Path('/mnt/data')
D=json.load(open(H/'P6_Q2_EQUITABLE_QUOTIENT_SPARSE_v0.1_2026-08-30.json'));Q=D['rows'];n=len(Q)
O=json.load(open(H/'P6_Q2_TWISTED_RESPONSE_ORBITS_FULL_v0.1_2026-08-30.json'));reps=O['representatives']
spec=importlib.util.spec_from_file_location('fb',H/'p6_affine_fast_builder.py');fb=importlib.util.module_from_spec(spec);spec.loader.exec_module(fb);p6=fb.p6
B=p6.library(4);masks,fm=fb.compile_masks(B,4,11);allmask=(1<<len(B))-1
def lm(s):
 m=fm[s[-3:]]
 for k,j in fb.geometries(4,11):
  r=fb.requirement(s,k,j)
  if r is not None:m|=masks[(k,j)].get(r,0)
 return allmask & ~m
G=defaultdict(list)
for i,s in enumerate(reps):G[lm(s)].append(i)
groups=list(G.values());sizes=[len(g) for g in groups]
QB=[]
for row in Q:
 x=0
 for j,w in row:
  if w&1:x^=1<<j
 QB.append(x)
def mul(x):
 o=0
 while x:
  l=x&-x;i=l.bit_length()-1;x-=l;o^=QB[i]
 return o
def rank(vs):
 piv={}
 for x in vs:
  while x:
   p=x.bit_length()-1
   if p in piv:x^=piv[p]
   else:piv[p]=x;break
 return len(piv)
sel=(0,1,2,4,8,11,12,13)
powers={0:[1<<i for i in range(n)]};cur=powers[0]
for h in range(1,14):
 cur=[mul(x) for x in cur]
 if h in sel:powers[h]=cur[:]
def rankgroups(groups,h):
 ph=powers[h];A=[]
 for g in groups:
  r=g[0];rr=ph[r]
  for i in g[1:]:A.append(ph[i]^rr)
 return rank(A)
def eval(groups):return {h:rankgroups(groups,h) for h in sel}
actual=eval(groups);print('actual',actual,flush=True)
tr=[];N=50
for seed in range(N):
 rng=random.Random(777000+seed);v=list(range(n));rng.shuffle(v);gg=[];off=0
 for z in sizes:gg.append(v[off:off+z]);off+=z
 tr.append(eval(gg))
 if (seed+1)%10==0:print('done',seed+1,flush=True)
summary={}
for h in sel:
 vals=[x[h] for x in tr];mu=statistics.mean(vals);sd=statistics.pstdev(vals)
 summary[str(h)]={'actual':actual[h],'random_mean':mu,'random_sd':sd,'random_min':min(vals),'random_max':max(vals),'z':(actual[h]-mu)/sd if sd else None,'fraction_random_le_actual':sum(v<=actual[h] for v in vals)/N}
out={'date':'2026-08-30','field':'GF2 exact','exact_response_groups':len(groups),'basis_differences':sum(z-1 for z in sizes),'actual':actual,'trials':N,'summary':summary}
(H/'P6_Q2_EXACT_RESPONSE_VS_RANDOM_GF2_v0.1_2026-08-30.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
