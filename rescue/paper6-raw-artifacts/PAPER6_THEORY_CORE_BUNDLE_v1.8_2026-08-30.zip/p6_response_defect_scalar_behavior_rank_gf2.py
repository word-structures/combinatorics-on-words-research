from pathlib import Path
from collections import defaultdict
import json,importlib.util
H=Path('/mnt/data')
D=json.load(open(H/'P6_Q2_EQUITABLE_QUOTIENT_SPARSE_v0.1_2026-08-30.json'));Q=D['rows'];n=len(Q)
O=json.load(open(H/'P6_Q2_TWISTED_RESPONSE_ORBITS_FULL_v0.1_2026-08-30.json')); reps=O['representatives']; twisted=O['groups']
spec=importlib.util.spec_from_file_location('fb',H/'p6_affine_fast_builder.py');fb=importlib.util.module_from_spec(spec);spec.loader.exec_module(fb);p6=fb.p6
B=p6.library(4);masks,fm=fb.compile_masks(B,4,11);allmask=(1<<len(B))-1
def lm(s):
 m=fm[s[-3:]]
 for k,j in fb.geometries(4,11):
  r=fb.requirement(s,k,j)
  if r is not None:m|=masks[(k,j)].get(r,0)
 return allmask&~m
G=defaultdict(list)
for i,s in enumerate(reps):G[lm(s)].append(i)
exact=list(G.values())
# generate scalar state sequences mod2: for each state bit at horizon n, pack horizon bits per state
HORIZ=1300
seqbits=[0]*n
v=[1]*n
for h in range(HORIZ):
 for i,x in enumerate(v):
  if x&1:seqbits[i]|=1<<h
 v=[sum(w*v[j] for j,w in row)&1 for row in Q]
def rank(vs):
 piv={}
 for x in vs:
  while x:
   p=x.bit_length()-1
   if p in piv:x^=piv[p]
   else:piv[p]=x;break
 return len(piv)
def behavior(groups):
 A=[]
 for g in groups:
  r=g[0]
  for i in g[1:]:A.append(seqbits[i]^seqbits[r])
 return {'generators':len(A),'scalar_behavior_rank_GF2_1300':rank(A),'nonzero_behavior_generators':sum(x!=0 for x in A)}
out={'date':'2026-08-30','horizons':HORIZ,'full_state_scalar_behavior_rank_GF2':rank(seqbits),'twisted_response_differences':behavior(twisted),'exact_response_differences':behavior(exact)}
(H/'P6_RESPONSE_DEFECT_SCALAR_BEHAVIOR_RANK_GF2_v0.1_2026-08-30.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out,indent=2))
