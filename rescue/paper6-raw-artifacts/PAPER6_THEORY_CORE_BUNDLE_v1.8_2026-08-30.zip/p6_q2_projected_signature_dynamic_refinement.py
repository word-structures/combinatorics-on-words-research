#!/usr/bin/env python3
from pathlib import Path
from collections import defaultdict, Counter
import json, importlib.util

H=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('fb',H/'p6_affine_fast_builder.py')
fb=importlib.util.module_from_spec(spec);spec.loader.exec_module(fb);p6=fb.p6
B=p6.library(4); masks,fm=fb.compile_masks(B,4,11)
D=json.loads((H/'P6_Q2_TWISTED_RESPONSE_ORBITS_FULL_v0.1_2026-08-30.json').read_text())
reps=D['representatives']
Q=[dict(r) for r in json.loads((H/'P6_Q2_EQUITABLE_QUOTIENT_SPARSE_v0.1_2026-08-30.json').read_text())['rows']]
N=len(Q)
assert N==2691

def prof(w): return tuple(w.count(c) for c in 'abc')
def last5profiles(s):
    r=len(s)%4
    return tuple(prof(s[i:i+4]) for i in range(r,len(s),4))[-5:]
def psig(s):
    z=[]
    for idx,(k,j) in enumerate(fb.geometries(4,11)):
        r=fb.requirement(s,k,j)
        if r is None: z.append(('ABSENT',idx))
        else: z.append(masks[(k,j)].get(r,0))
    return (tuple(z),last5profiles(s))

def partition_from_keys(keys):
    mp={}; out=[]
    for k in keys:
        if k not in mp: mp[k]=len(mp)
        out.append(mp[k])
    return out

def groups(part):
    g=defaultdict(list)
    for i,c in enumerate(part):g[c].append(i)
    return g

def count_id(i):
    if i in (224,1021): return ('M1',)
    if i in (1645,2244): return ('M2',)
    return ('S',i)

def soundness(part):
    g=groups(part); uns=[]
    for c,vs in g.items():
        ids={count_id(i) for i in vs}
        if len(ids)>1:uns.append(vs)
    return {'types':len(g),'multi_groups':sum(len(v)>1 for v in g.values()),
            'classes_in_multi':sum(len(v) for v in g.values() if len(v)>1),
            'unsound_groups':len(uns),'classes_in_unsound':sum(len(v) for v in uns),
            'max_unsound_size':max([len(v) for v in uns],default=0),
            'witness':uns[0][:10] if uns else None}

def weighted_refine(part):
    keys=[]
    for i,row in enumerate(Q):
        c=Counter()
        for j,w in row.items(): c[part[j]]+=w
        keys.append((part[i],tuple(sorted(c.items()))))
    return partition_from_keys(keys)

def vec_step(v):
    # Q^h 1: row action on column v
    return [sum(w*v[j] for j,w in row.items()) for row in Q]

p0=partition_from_keys([psig(s) for s in reps])
res={'date':'2026-08-30','descriptor':'per-geometry library-projected obstruction masks with geometry-specific ABSENT markers + ordered profiles of all available recent complete blocks (max 5)','P0':soundness(p0)}

p=p0
ref=[]
for h in range(1,6):
    p2=weighted_refine(p)
    ref.append({'round':h,**soundness(p2),'changed':p2!=p})
    p=p2
    if not ref[-1]['changed']:break
res['weighted_equitable_refinement']=ref

# Moment augmentation. c0=1, c1 row sums. P0 already fixes c1 empirically but keep sequence.
v=[1]*N
moments=[v]
for h in range(1,8):
    v=vec_step(v); moments.append(v)

moment=[]
for Hh in range(1,8):
    # add c1..cHh to P0 key
    keys=[(p0[i],tuple(moments[h][i] for h in range(1,Hh+1))) for i in range(N)]
    pp=partition_from_keys(keys)
    moment.append({'through_count_horizon':Hh,**soundness(pp)})
res['scalar_moment_augmentation']=moment

# More exact witness data for first P0 unsound group.
g=groups(p0)
uns=[vs for vs in g.values() if len({count_id(i) for i in vs})>1]
w=uns[0]
res['first_unsound_group_details']=[{'class':i,'state':reps[i],'counts':[moments[h][i] for h in range(0,6)]} for i in w]

out=H/'P6_Q2_PROJECTED_SIGNATURE_DYNAMIC_REFINEMENT_v0.1_2026-08-30.json'
out.write_text(json.dumps(res,indent=2),encoding='utf-8')
print(json.dumps(res,indent=2))
