from pathlib import Path
from collections import defaultdict
import importlib.util,json,time
H=Path('/mnt/data')
spec=importlib.util.spec_from_file_location('fb',H/'p6_affine_fast_builder.py');fb=importlib.util.module_from_spec(spec);spec.loader.exec_module(fb);p6=fb.p6
B=p6.library(4);bi={b:i for i,b in enumerate(B)}
t=time.time();S,E,L,I=fb.build_fast(B,11);print('build',len(S),time.time()-t,flush=True)
O=json.load(open(H/'P6_Q2_TWISTED_RESPONSE_ORBITS_FULL_v0.1_2026-08-30.json'));reps=O['representatives']
# exact count class id: only two known merges
merge={1021:224,2244:1645}
def cc(i):return merge.get(i,i)
# depth 0 = exact legal block set
ids={}; keyid={};nxt=0
for s in S:
 key=tuple(sorted(bi[b] for b in L.get(s,{})))
 if key not in keyid:keyid[key]=nxt;nxt+=1
 ids[s]=keyid[key]
out=[]
for d in range(0,8):
 vals=[ids[s] for s in reps]; groups=defaultdict(list)
 for i,x in enumerate(vals):groups[x].append(i)
 unsound=[]
 for g in groups.values():
  if len({cc(i) for i in g})>1:unsound.append(g)
 out.append({'depth':d,'types_on_2691_equitable_reps':len(groups),'multi_groups':sum(len(g)>1 for g in groups.values()),'classes_in_multi_groups':sum(len(g) for g in groups.values() if len(g)>1),'groups_merging_distinct_exact_count_classes':len(unsound),'classes_in_unsound_groups':sum(len(g) for g in unsound),'max_unsound_group':max([len(g) for g in unsound],default=0)})
 print(out[-1],flush=True)
 if d==7:break
 # refine exact labelled response tree one more level
 new={};kid={};nxt=0
 for s in S:
  key=tuple(sorted((bi[b],ids[t]) for b,t in L.get(s,{}).items()))
  if key not in kid:kid[key]=nxt;nxt+=1
  new[s]=kid[key]
 ids=new
path=H/'P6_Q2_RESPONSE_TREE_DEPTH_AUDIT_v0.1_2026-08-30.json';path.write_text(json.dumps(out,indent=2),encoding='utf-8');print(path)
