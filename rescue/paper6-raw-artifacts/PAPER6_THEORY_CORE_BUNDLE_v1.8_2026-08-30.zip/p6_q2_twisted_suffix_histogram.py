from pathlib import Path
from collections import defaultdict,Counter
from itertools import permutations
import importlib.util,json,time
H=Path('/mnt/data')
spec=importlib.util.spec_from_file_location('fb',H/'p6_affine_fast_builder.py'); fb=importlib.util.module_from_spec(spec); spec.loader.exec_module(fb); p6=fb.p6
D=json.load(open(H/'P6_Q2_EQUITABLE_QUOTIENT_SPARSE_v0.1_2026-08-30.json')); Q=D['rows']; q=len(Q)
perms=[(''.join(x),dict(zip('abc',x))) for x in permutations('abc')]
def tw(w,mp):return ''.join(mp[c] for c in w)
def lcsuf(a,b):
 m=min(len(a),len(b)); k=0
 while k<m and a[-1-k]==b[-1-k]:k+=1
 return k
def mv(v):return [sum(w*v[j] for j,w in row) for row in Q]
# q count signatures
v=[1]*q;qs=[[] for _ in range(q)]
for _ in range(6):
 for i,x in enumerate(v):qs[i].append(x)
 v=mv(v)
sig2q=defaultdict(list)
for i,s in enumerate(qs):sig2q[tuple(s)].append(i)
keys=sorted(set(map(tuple,qs)));kid={k:i for i,k in enumerate(keys)}
def cqrow(i):
 d=defaultdict(int)
 for j,w in Q[i]:d[kid[tuple(qs[j])]]+=w
 return tuple(sorted(d.items()))
cq=[cqrow(i) for i in range(q)]
B=p6.library(4); states,edges,labels,init=fb.build_fast(B,11);SS=sorted(states)
rv={s:1 for s in SS};rs={s:[] for s in SS}
for _ in range(6):
 for s in SS:rs[s].append(rv[s])
 rv={s:sum(w*rv[t] for t,w in edges.get(s,{}).items()) for s in SS}
rawkid={s:kid[tuple(rs[s])] for s in SS}
def cls(s):
 cand=sig2q[tuple(rs[s])]
 if len(cand)==1:return cand[0]
 d=defaultdict(int)
 for t,w in edges.get(s,{}).items():d[rawkid[t]]+=w
 rr=tuple(sorted(d.items())); hit=[i for i in cand if cq[i]==rr]
 assert len(hit)==1;return hit[0]
reps=[None]*q
for s in SS:
 i=cls(s)
 if reps[i] is None:reps[i]=s
legal=[set(labels[s].keys()) for s in reps]
def canon(W):return min(tuple(sorted(tw(w,mp) for w in W)) for _,mp in perms)
g=defaultdict(list)
for i,W in enumerate(legal):g[canon(W)].append(i)
hist=Counter(); count_hist=Counter(); top=[]; total=0
for group in g.values():
 if len(group)<2:continue
 for ai in range(len(group)):
  for bi in range(ai+1,len(group)):
   a,b=group[ai],group[bi]; total+=1; best=-1; bestnames=[]
   for name,mp in perms:
    if {tw(w,mp) for w in legal[a]}==legal[b]:
     z=lcsuf(tw(reps[a],mp),reps[b])
     if z>best:best=z;bestnames=[name]
     elif z==best:bestnames.append(name)
   assert best>=0
   hist[best]+=1
   same=tuple(qs[a])==tuple(qs[b])
   if same: count_hist[best]+=1
   if best>=8 or same: top.append((best,a,b,bestnames,same,reps[a],reps[b]))
top.sort(reverse=True)
out={'date':'2026-08-30','pairs_total':total,'max_common_suffix_histogram':dict(sorted(hist.items())),'count_equivalent_pair_histogram':dict(sorted(count_hist.items())),'pairs_with_max_common_suffix_ge_8':len([x for x in top if x[0]>=8]),'top_pairs':[{'suffix':z,'A':a,'B':b,'perms':names,'count_signature_equal':same,'A_rep':ra,'B_rep':rb} for z,a,b,names,same,ra,rb in top[:100]]}
path=H/'P6_Q2_TWISTED_SUFFIX_HISTOGRAM_v0.1_2026-08-30.json';path.write_text(json.dumps(out,indent=2),encoding='utf-8')
print(path);print('hist',sorted(hist.items()));print('count',sorted(count_hist.items()));print('top')
for x in top[:30]:print(x[:5])
