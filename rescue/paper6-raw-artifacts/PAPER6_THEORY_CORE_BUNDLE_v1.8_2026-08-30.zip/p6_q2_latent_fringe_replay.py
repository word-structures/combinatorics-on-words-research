#!/usr/bin/env python3
"""Replay the Q2 latent-fringe redundancy certificate."""
from pathlib import Path
import json, importlib.util

H=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("fb",H/"p6_affine_fast_builder.py")
fb=importlib.util.module_from_spec(spec); spec.loader.exec_module(fb)
p6=fb.p6
B=p6.library(4)
masks,fm=fb.compile_masks(B,4,11)
allmask=(1<<len(B))-1

pairs=[
("aaabaaacabcbbbabcccab","aaabacccbabbbcbaaacb","cba",13),
("aaabcacccbcabcbbbaaac","aabcacccbbba","bca",11),
]

def pword(w,name):
    mp=dict(zip("abc",name)); return "".join(mp[c] for c in w)

for s,t,perm,ell in pairs:
    assert pword(s[-ell:],perm)==t[-ell:]
    for u in (s,t):
        core=fm[u[-3:]]; fringe=0
        for k,j in fb.geometries(4,11):
            r=fb.requirement(u,k,j)
            if r is None: continue
            m=masks[(k,j)].get(r,0)
            if 2*k-j<=ell: core|=m
            else: fringe|=m
        assert fringe & ~core == 0
        assert (allmask & ~(core|fringe)).bit_count() in (5,18)

print("PASS")
print("Both Q2 pairs have zero unique latent-fringe effect on the current block response.")
