from pathlib import Path
from collections import defaultdict
import importlib.util,json,time
H=Path('/mnt/data')
spec=importlib.util.spec_from_file_location('fb',H/'p6_affine_fast_builder.py');fb=importlib.util.module_from_spec(spec);spec.loader.exec_module(fb);p6=fb.p6
B=p6.library(4);bi={b:i for i,b in enumerate(B)};S,E,L,I=fb.build_fast(B,11)
O=json.load(open(H/'P6_Q2_TWISTED_RESPONSE_ORBITS_FULL_v0.1_2026-08-30.json'));reps=O['representatives']
# response-tree ids through depth2
ids={};kid={};nxt=0
for s in S:
 key=tuple(sorted(bi[b] for b in L.get(s,{})))
 if key not in kid:kid[key]=nxt;nxt+=1
 ids[s]=kid[key]
for d in range(2):
 new={};kid={};nxt=0
 for s in S:
  key=tuple(sorted((bi[b],ids[t]) for b,t in L.get(s,{}).items()))
  if key not in kid:kid[key]=nxt;nxt+=1
  new[s]=kid[key]
 ids=new
G=defaultdict(list)
for i,s in enumerate(reps):G[ids[s]].append(i)
merge={1021:224,2244:1645}
def cc(i):return merge.get(i,i)
# count vectors quotient
D=json.load(open(H/'P6_Q2_EQUITABLE_QUOTIENT_SPARSE_v0.1_2026-08-30.json'));Q=D['rows'];v=[1]*len(Q); counts=[]
for h in range(8):
 counts.append(v);v=[sum(w*v[j] for j,w in row) for row in Q]
def chunks(s):return [s[len(s)-(z+1)*4:len(s)-z*4] for z in range(5)]
out=[]
for g in G.values():
 if len(g)>1 and len({cc(i) for i in g})>1:
  assert len(g)==2
  a,b=g
  first=next(h for h in range(8) if counts[h][a]!=counts[h][b])
  ca,cb=chunks(reps[a]),chunks(reps[b])
  diffs=[z for z,(x,y) in enumerate(zip(ca,cb)) if x!=y]
  out.append({'classes':[a,b],'states':[reps[a],reps[b]],'first_count_divergence_horizon':first,'count_prefix_A':[counts[h][a] for h in range(first+2)],'count_prefix_B':[counts[h][b] for h in range(first+2)],'last5_blocks_A':ca,'last5_blocks_B':cb,'different_block_positions_from_newest':diffs,'different_block_profiles':[(p6.parikh(ca[z]),p6.parikh(cb[z])) for z in diffs]})
path=H/'P6_Q2_DEPTH2_RESPONSE_AMBIGUOUS_PAIRS_v0.1_2026-08-30.json';path.write_text(json.dumps(out,indent=2),encoding='utf-8')
print('pairs',len(out));
from collections import Counter
print('div horizons',Counter(x['first_count_divergence_horizon'] for x in out))
print('diff positions',Counter(tuple(x['different_block_positions_from_newest']) for x in out))
for x in out: print(x['classes'],x['first_count_divergence_horizon'],x['different_block_positions_from_newest'],x['last5_blocks_A'],x['last5_blocks_B'])
