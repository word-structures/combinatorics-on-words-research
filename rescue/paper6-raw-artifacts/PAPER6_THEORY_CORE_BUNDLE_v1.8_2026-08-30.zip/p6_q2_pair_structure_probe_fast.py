from pathlib import Path
from collections import defaultdict, Counter
from itertools import permutations
import importlib.util, json, time
HERE=Path('/mnt/data')
spec=importlib.util.spec_from_file_location('fb',HERE/'p6_affine_fast_builder.py'); fb=importlib.util.module_from_spec(spec); spec.loader.exec_module(fb)
p6=fb.p6

def qmatvec(rows,v): return [sum(w*v[j] for j,w in row) for row in rows]
def permute_word(w,perm):
    mp=dict(zip('abc',perm)); return ''.join(mp[c] for c in w)
def desc(w,L=4):
    return {'len':len(w),'parikh':p6.parikh(w),'last3':w[-3:],'last_block':w[-L:],'last_block_profile':p6.parikh(w[-L:]),
            'block_profiles_from_end':[p6.parikh(w[max(0,len(w)-k*L):len(w)-(k-1)*L]) for k in range(1,min(5,(len(w)+L-1)//L)+1)],
            'suffix_profiles_1_11':[p6.parikh(w[-m:]) for m in range(1,min(11,len(w))+1)]}

def main():
    saved=json.load(open(HERE/'P6_Q2_EQUITABLE_QUOTIENT_SPARSE_v0.1_2026-08-30.json'))
    rows=saved['rows']; q=len(rows)
    # quotient signatures through horizon 5: known to separate all except two count-equivalent pairs
    qv=[1]*q; qsig=[[] for _ in range(q)]
    for h in range(6):
        for i,x in enumerate(qv): qsig[i].append(x)
        qv=qmatvec(rows,qv)
    sig2q=defaultdict(list)
    for i,s in enumerate(qsig): sig2q[tuple(s)].append(i)
    duplicates={s:x for s,x in sig2q.items() if len(x)>1}
    print('quotient duplicate signatures',list(duplicates.values()),flush=True)

    B=p6.library(4); K=11
    t=time.time(); states,edges,labels,init=fb.build_fast(B,K); print('built',len(states),time.time()-t,flush=True)
    states_sorted=sorted(states)
    # raw count signatures through h=5
    rv={s:1 for s in states_sorted}; rsig={s:[] for s in states_sorted}
    for h in range(6):
        for s in states_sorted: rsig[s].append(rv[s])
        rv={s:sum(w*rv[t] for t,w in edges.get(s,{}).items()) for s in states_sorted}
        print('h',h,'done',flush=True)
    # group raw states by quotient/count signature
    sigstates=defaultdict(list)
    for s in states_sorted: sigstates[tuple(rsig[s])].append(s)

    targets={930,933,1507,2032,1198,1385,2147,2243}
    srcs={224:'aaabaaacabcbbbabcccab',1021:'aaabacccbabbbcbaaacb',1645:'aaabcacccbcabcbbbaaac',2244:'aabcacccbbba'}
    reps={}; sizes={}
    for i in targets:
        ss=sigstates[tuple(qsig[i])]
        reps[i]=ss[0]; sizes[i]=len(ss)
    reps.update(srcs)

    # raw successor -> quotient candidate indices using signature
    def q_candidates(raw): return sig2q[tuple(rsig[raw])]
    out={'date':'2026-08-30','method':'identify quotient classes via exact continuation-count signatures h=0..5; unique for all target classes, except known source-pair duplicates',
         'raw_states':len(states),'quotient_classes':q,'known_duplicate_quotient_signature_groups':list(duplicates.values()),'classes':{},'pairs':[]}
    for i,r in sorted(reps.items()):
        out['classes'][str(i)]={'rep':r,'raw_states_with_same_count_signature':len(sigstates[tuple(qsig[i])]),'descriptor':desc(r),'future_count_signature_h0_h5':qsig[i]}
        # profile response counts only, plus successor q candidates
        pd=defaultdict(list)
        for b,t in labels[r].items(): pd[str(p6.parikh(b))].append({'block':b,'succ':t,'q_candidates':q_candidates(t)})
        out['classes'][str(i)]['legal_blocks_by_profile']={p:x for p,x in pd.items()}

    for a,b in [(224,1021),(1645,2244)]:
        # compare one-step profile counts and target signatures
        def profcount(r): return Counter(p6.parikh(x) for x in labels[r])
        pa,pb=profcount(reps[a]),profcount(reps[b])
        out['pairs'].append({'A':a,'B':b,'same_one_step_profile_counts':pa==pb,'A_profile_counts':{str(k):v for k,v in pa.items()},'B_profile_counts':{str(k):v for k,v in pb.items()}})

    path=HERE/'P6_Q2_PAIR_STRUCTURE_PROBE_FAST_v0.1_2026-08-30.json'; path.write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(path)
    for i in sorted(targets): print('TARGET',i,reps[i],desc(reps[i]))
    for x in out['pairs']: print('PAIR',x)

if __name__=='__main__': main()
