# PAPER 6 — Q2 SEMANTICS BREAKTHROUGH v0.1
**Date:** 2026-08-30  
**Status:** exact research checkpoint; not a manuscript

## Executive result

The second complete block-range level,

\[
Q=2
\quad\Longleftrightarrow\quad
K_{\max}=11
\]

for the full L4 aa2fr selected library produces the first Abelian-avoidance
system in this project where exact count semantics is **strictly coarser** than
stable weighted/equitable semantics.

The exact hierarchy is now

\[
\boxed{
218\,298
\to
2\,691
\to
2\,689
\to
1\,179.
}
\]

Interpretation:

- 218,298 raw block-boundary suffix states;
- 2,691 stable weighted/equitable classes;
- 2,689 exact all-horizon continuation-count classes;
- 1,179 exact scalar Hankel dimensions for the total assembly-count sequence.

The scalar recurrence splits as

\[
\boxed{
1\,179=12+1\,167
}
\]

with an exact \(x^{12}\) nilpotent factor and a 1,167-dimensional persistent
scalar future.

---

# 1. Fast exact construction

The proven affine boundary compiler was used to build transitions without
rescanning every character window.

For the full L4 library:

| Kmax | complete block range | raw states | transitions | research-Python build time |
|---:|---:|---:|---:|---:|
| 7 | Q=1 | 10,782 | 56,430 | 0.43 s |
| 8 | — | 19,218 | 89,076 | 0.92 s |
| 9 | — | 53,808 | 225,048 | 2.79 s |
| 10 | — | 86,988 | 348,690 | 5.07 s |
| 11 | Q=2 | **218,298** | **799,044** | **15.07 s** |

These timings are implementation diagnostics, not manuscript performance
claims.

The important point is exactness: at K7 the fast builder reproduces the
previous 10,782-state / 56,430-edge graph exactly.

---

# 2. First real count-equivalent but non-equitable Abelian states

The coarsest stable weighted partition at Q=2 has

\[
2\,691
\]

classes.

Continuation-count signatures separate all but two pairs. Exact integer
iteration through the full Cayley–Hamilton horizon of the 2,691-state quotient
shows that both pairs have identical counts for every horizon.

The two quotient-class pairs are

\[
\boxed{(224,1021)}
\]

and

\[
\boxed{(1645,2244)}.
\]

Representative literal history states include:

### Pair 1

```text
aaabaaacabcbbbabcccab
aaabacccbabbbcbaaacb
```

Their continuation-count sequence begins

\[
1,5,24,108,313,1337,4565,17383,\ldots
\]

for both states.

Yet their outgoing multiplicities into the exact count classes differ.

### Pair 2

```text
aaabcacccbcabcbbbaaac
aabcacccbbba
```

Their common continuation-count sequence begins

\[
1,18,64,219,682,2893,10672,39663,\ldots
\]

and again their outgoing count-class multiplicities differ.

Therefore

\[
\boxed{
\text{exact count equivalence}
\not=
\text{stable equitable equivalence}
}
\]

inside a genuine Abelian-avoidance transfer system.

This is not merely the abstract four-state counterexample used earlier.

It occurs naturally in the Paper-6 avoidance dynamics.

---

# 3. Exact proof of 2,689 count classes

The 2,691 equitable quotient supplies a finite Cayley–Hamilton certificate.

All quotient states except the two candidate pairs are already separated by
short continuation-count signatures.

For each candidate pair, exact integer values of

\[
Q^n\mathbf1
\]

were checked equal for

\[
n=0,\ldots,2690.
\]

Since the quotient has dimension 2,691, Cayley–Hamilton forces equality for
every later horizon.

Merging exactly these two pairs yields

\[
\boxed{2\,689}
\]

all-horizon count classes.

The resulting count partition is not equitable: each merged pair sends
different multiplicities to some count classes.

A compact replay from the saved sparse 2,691-state quotient reproduces this
certificate.

---

# 4. Exact scalar recurrence at Q=2

The exact total assembly-count sequence begins

\[
60,\ 696,\ 4350,\ 22446,\ 91878,\ 329304,\ 1159182,\ 4299060,\ldots
\]

Twelve independent approximately \(10^9\)-sized primes all give
Berlekamp--Massey degree

\[
\boxed{1179}.
\]

CRT reconstruction gives an integer recurrence of order 1,179.

The largest coefficient has 67 decimal digits.

The recurrence was checked exactly on

\[
\boxed{2821}
\]

consecutive recurrence equations from a 4,000-term exact integer sequence.

The recurrence polynomial has exactly twelve trailing zero coefficients:

\[
\boxed{x^{12}\mid m(x),\qquad x^{13}\nmid m(x)}.
\]

Hence the persistent scalar dimension is

\[
\boxed{1167}.
\]

---

# 5. Exact minimality of the scalar dimension

The finite exact integer sequence reduced modulo
\(1\,000\,000\,009\) has Berlekamp--Massey linear complexity 1,179, with more
than \(2\cdot1179\) available terms.

This implies a nonzero finite Hankel minor of order 1,179 over that field, and
therefore a nonzero integer Hankel minor.

Thus

\[
\operatorname{rank}_{\mathbb Q}\ge1179.
\]

The exact CRT-lifted order-1179 recurrence gives the reverse inequality.

Therefore

\[
\boxed{
\text{scalar Hankel rank}=1179.
}
\]

---

# 6. Growth checkpoint

The numerical Perron root of the exact Q2 weighted quotient is

\[
\boxed{
\lambda_{Q=2}\approx3.71609502225.
}
\]

For the 60-block denominator,

\[
\boxed{
\lambda_{Q=2}/60
\approx0.0619349170.
}
\]

The earlier complete Q1 value was approximately

\[
4.98153744/60\approx0.0830256.
\]

Thus the block-range hierarchy continues to tighten substantially.

---

# 7. Theoretical consequence

The old pilot coincidence

\[
\text{count classes}
=
\text{equitable classes}
\]

is now definitively dead as a general Abelian-avoidance conjecture.

The correct hierarchy is genuinely strict:

\[
\boxed{
\text{stable weighted state semantics}
\;\Longrightarrow\;
\text{all-horizon count semantics}
\;\Longrightarrow\;
\text{scalar linear semantics},
}
\]

and both reverse implications can fail in the actual avoidance system.

This strengthens the theory-first Paper-6 framing.

A minimal counting solver should not be forced to preserve an equitable
state quotient if the scientific output is only continuation counts or
survival entropy.

---

# 8. Q1 versus Q2

The complete block-range checkpoints are now:

| Q | Kmax | raw | equitable | exact count | exact scalar | transient | persistent |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 1 | 7 | 10,782 | 252 | 252 | 153 | 7 | 146 |
| 2 | 11 | 218,298 | 2,691 | **2,689** | **1,179** | 12 | **1,167** |

The scalar future dimension grows by about 7.7× from Q1 to Q2 while the raw
state count grows by about 20.2×.

Substantial semantic compression therefore survives the second full
long-range layer.

Two data points are not enough for an asymptotic law.

---

# 9. Next gate — P6-C7e

The next question should not be “run Q3 blindly”.

The Q2 system is large enough to expose real semantics but small enough to
analyze.

The highest-value next task is:

> identify what structural observables distinguish the 1,167 persistent
> directions and why two pairs of equitable states cancel exactly in total
> counting.

In parallel, build a **matrix-free block-range Apply** that consumes
cut-profile families and profile-prefix-sum data, so Q3 does not require
materializing the full literal state graph.

The goal is now:

\[
\boxed{
\text{direct weighted decorated-additive operator}
}
\]

rather than ever-larger suffix automata.
