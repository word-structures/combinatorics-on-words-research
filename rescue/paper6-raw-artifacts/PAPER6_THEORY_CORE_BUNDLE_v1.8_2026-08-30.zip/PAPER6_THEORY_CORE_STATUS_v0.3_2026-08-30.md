# PAPER 6 — THEORY CORE STATUS v0.3
**Date:** 2026-08-30  
**Status:** active research checkpoint

## New completed gate

P6-C7a — long-period structure:

\[
\boxed{
F(s)-2F(s+K)+F(s+2K)
=
D_q+E,
\quad
\|E\|_\infty\le2L-2.
}
\]

For \(K=qL+r\), \(D_q\) is the difference of the adjacent \(q\)-block profile
runs around the midpoint block boundary.

The defect \(E\):

- is zero-sum;
- belongs to a finite alphabet depending on \(L\), not \(K\);
- has a sharp universal infinity-norm bound \(2L-2\);
- has at most 18,487 universal ternary values at L=40.

## Independent validation

The identity, zero-sum property and bound were exhaustively checked on:

- all binary L3 four-block assemblies;
- all ternary L2 four-block assemblies;
- all ternary L3 three-block assemblies;
- all 216,000 three-block assemblies from the full L4 aa2fr library.

The full L4 aa2fr replay covered 1,944,000 square windows with zero failures.

## Important novelty correction

The decomposition is a specialization of the classical Abelian-template
mechanism under a uniform block morphism.

Do not make the decomposition itself the headline novelty.

## New core formulation

For long periods, Paper 6 reduces exact Abelian safety to:

\[
\boxed{
\text{block-profile second differences}
+
\text{finite decorated boundary defects}.
}
\]

The unbounded part is now entirely in the block-profile prefix-sum dynamics.

## Next gate P6-C7b

Build the **defect-template counting layer**:

1. enumerate the exact attainable defect catalogue for a selected library;
2. quotient defects by Paper-4 geometry / profile symmetry where valid;
3. define decorated additive templates for arbitrary q;
4. test whether the weighted future dynamics can be evaluated from these
   templates without literal character suffix states;
5. compare with the existing 97-dimensional full-L4 K6 future space.

The decisive question is:

> can the finite defect catalogue serve as the exact interface between local
> character geometry and long-range additive profile counting?

If yes, this is the missing structural bridge for the theory-first Paper 6.
