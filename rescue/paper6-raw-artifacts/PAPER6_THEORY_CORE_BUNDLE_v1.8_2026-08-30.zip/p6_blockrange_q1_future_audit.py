from pathlib import Path
import importlib.util,json
import numpy as np
import scipy.sparse as sp

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('p6',HERE/'p6_semantics_audit.py')
p6=importlib.util.module_from_spec(spec); spec.loader.exec_module(p6)
PRIMES=[1000003,1000033,1000037]

def BM(s,mod):
    C=[1]; B=[1]; L=0; m=1; b=1
    for n in range(len(s)):
        d=s[n]%mod
        for i in range(1,L+1): d=(d+C[i]*s[n-i])%mod
        if d==0: m+=1; continue
        T=C[:]; coef=d*pow(b,mod-2,mod)%mod
        if len(C)<len(B)+m: C += [0]*(len(B)+m-len(C))
        for j in range(len(B)): C[j+m]=(C[j+m]-coef*B[j])%mod
        if 2*L<=n: L=n+1-L; B=T; b=d; m=1
        else: m+=1
    return L,C[:L+1]

def main():
    B=p6.library(4); K=7; Q=1
    states,edges,labels,init=p6.build(B,K); sts=sorted(states); idx={s:i for i,s in enumerate(sts)}
    eq=p6.equitable(states,edges); rc=p6.right_context(states,labels,B); h,hist=p6.count_horizon_to_target(states,edges,eq)
    rows=[];cols=[];data=[]
    for s,d in edges.items():
        i=idx[s]
        for t,w in d.items(): rows.append(i);cols.append(idx[t]);data.append(w)
    M=sp.csr_matrix((np.array(data,dtype=np.int64),(rows,cols)),shape=(len(sts),len(sts)),dtype=np.int64)
    alpha=np.zeros(len(sts),dtype=np.int64); mem=2*K-1
    for b in B: alpha[idx[b[-mem:]]] += 1
    per=[]
    for p in PRIMES:
        v=np.ones(len(sts),dtype=np.int64); seq=[]
        for _ in range(700):
            seq.append(int(np.dot(alpha,v)%p)); v=(M.dot(v)%p).astype(np.int64)
        L,C=BM(seq,p)
        tz=0
        for x in reversed(C):
            if x%p==0: tz+=1
            else: break
        ok=all((seq[n]+sum(C[i]*seq[n-i] for i in range(1,L+1)))%p==0 for n in range(L,len(seq)))
        per.append({'prime':p,'degree':L,'trailing_zero_root_multiplicity_candidate':tz,'persistent_degree_candidate':L-tz,'verified_700_terms':ok})
    out={
      'library':'ALL_L4_AA2FR','L':4,'block_range_Q':Q,'equivalent_character_Kmax':7,'blocks':len(B),
      'raw_states':len(states),'right_context_classes':len(set(rc.values())),'stable_weighted_count_classes':len(set(eq.values())),
      'count_prefix_horizon':h,'count_prefix_class_history':hist,'distinct_weighted_edges':M.nnz,
      'blackbox_modular':per,
      'all_primes_same_degree':len({x['degree'] for x in per})==1,
      'all_primes_same_zero_multiplicity':len({x['trailing_zero_root_multiplicity_candidate'] for x in per})==1,
      'status':'degree and zero-root multiplicity are strong modular candidates; integer recurrence not yet CRT-certified'
    }
    (HERE/'P6_BLOCKRANGE_Q1_FUTURE_RESULTS_v0.1_2026-08-30.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps(out,indent=2))
if __name__=='__main__': main()
