# PAPER 6 — THEORY CORE STATUS v1.3
**Date:** 2026-08-30  
**Status:** active theory checkpoint

## New cross-paper mechanism

The two Q2 twisted-response pairs are now explained directly in affine
Paper-4 coordinates.

Under their response alphabet permutations:

- pair 224/1021 shares a suffix of length 13;
- pair 1645/2244 shares a suffix of length 11.

Every affine obstruction using no more than the common suffix transforms
exactly.

All geometric differences live in the older latent fringe.

## Key selected-library fact

Those fringe constraints add **zero unique forbidden blocks** beyond the common
core constraints.

Pair 224/1021:

- one fringe side hits 26 blocks;
- all 26 are already core-forbidden;
- unique fringe effect = 0.

Pair 1645/2244:

- one fringe side hits 2 blocks;
- both are already core-forbidden;
- unique fringe effect = 0.

Thus the current response can forget the fringe even though the future cannot
necessarily do so.

## Unified mechanism

\[
\text{latent fringe difference}
\to
\text{current response redundancy}
\to
\text{future transient defect}
\to
\text{nilpotent balancing}
\to
\text{count equivalence}.
\]

This ties together Paper 4 geometry, Paper 5 response families and Paper 6
future semantics.

## Next target

Define a small **fringe-defect update space**.

Do not store raw fringe coordinates.

Store only the future action of the fringe on:

- core response;
- next fringe;
- sterile/nilpotent directions;
- persistent future directions.

This is now the strongest candidate route to a direct structural Paper-6
operator.
