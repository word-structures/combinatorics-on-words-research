from pathlib import Path
from collections import defaultdict,Counter
import importlib.util,json,time
H=Path('/mnt/data')
spec=importlib.util.spec_from_file_location('fb',H/'p6_affine_fast_builder.py'); fb=importlib.util.module_from_spec(spec); spec.loader.exec_module(fb); p6=fb.p6
D=json.load(open(H/'P6_Q2_EQUITABLE_QUOTIENT_SPARSE_v0.1_2026-08-30.json')); R=D['rows']; q=len(R)
def mv(v): return [sum(w*v[j] for j,w in row) for row in R]
# q count sig 0..5
v=[1]*q; sig=[[] for _ in range(q)]
for _ in range(6):
 for i,x in enumerate(v): sig[i].append(x)
 v=mv(v)
sigkey=[tuple(x) for x in sig]
keyid={k:i for i,k in enumerate(sorted(set(sigkey)))}
# quotient row collapsed to successor count-signature IDs
def collapsed_qrow(i):
 d=defaultdict(int)
 for j,w in R[i]: d[keyid[sigkey[j]]]+=w
 return tuple(sorted(d.items()))
qrows={i:collapsed_qrow(i) for i in [224,1021,1645,2244]}
B=p6.library(4); states,edges,labels,init=fb.build_fast(B,11); S=sorted(states)
rv={s:1 for s in S}; rs={s:[] for s in S}
for _ in range(6):
 for s in S: rs[s].append(rv[s])
 rv={s:sum(w*rv[t] for t,w in edges.get(s,{}).items()) for s in S}
# map raw successor signature to keyid
rawkid={s:keyid[tuple(rs[s])] for s in S}
def collapsed_rawrow(s):
 d=defaultdict(int)
 for t,w in edges.get(s,{}).items(): d[rawkid[t]]+=w
 return tuple(sorted(d.items()))
out={}
for a,b in [(224,1021),(1645,2244)]:
 union=[s for s in S if tuple(rs[s])==sigkey[a]]
 split={a:[],b:[], 'other':[]}
 for s in union:
  rr=collapsed_rawrow(s)
  if rr==qrows[a]: split[a].append(s)
  elif rr==qrows[b]: split[b].append(s)
  else: split['other'].append(s)
 print('pair',a,b,'union',len(union),'split',len(split[a]),len(split[b]),len(split['other']))
 for i in [a,b]:
  L=Counter(map(len,split[i])); print(i,'lengths',L,'examples',split[i][:5])
 out[f'{a}_{b}']={str(i):{'count':len(split[i]),'length_distribution':dict(Counter(map(len,split[i]))),'examples':split[i][:12]} for i in [a,b]}
 out[f'{a}_{b}']['other_count']=len(split['other'])
(H/'P6_Q2_PAIR_MEMBERSHIP_PROBE_v0.1_2026-08-30.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(H/'P6_Q2_PAIR_MEMBERSHIP_PROBE_v0.1_2026-08-30.json')
