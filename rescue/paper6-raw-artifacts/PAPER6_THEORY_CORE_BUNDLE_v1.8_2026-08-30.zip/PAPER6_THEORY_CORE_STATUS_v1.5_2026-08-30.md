# PAPER 6 — THEORY CORE STATUS v1.5
**Date:** 2026-08-30  
**Status:** active theory checkpoint

## Major correction

Latent fringe is not generally only transient.

Under identical appended blocks, raw suffix-Parikh differences shift outward
and vanish after finitely many matched steps.

But before vanishing they can change legality and inject live branches into
the persistent transfer dynamics.

## Exact Q2 witness

Two states:

```text
aaabaaacaaabbbcabccca
aaabaaacaaabbbcbaccca
```

have:

- the same exact legal next-block set;
- identical ordered profiles of the last five complete blocks;
- only `bcab` versus `bcba` as the relevant internal-order difference.

Yet:

\[
c_{12}=6\,867\,627
\quad\text{vs.}\quad
8\,737\,466.
\]

The current fringe masks are response redundant.

After one matched block, a shifted affine obstruction becomes active and
creates non-sterile branch asymmetries.

## Persistent local-descriptor kill

At Q2, even:

\[
\text{twisted response}
+
\text{last five block profiles}
\]

gives 2400 categories on 2691 quotient states but still misses at least 236
dimensions of the exact GF(2) persistent cyclic future space.

Therefore no small recent-profile-window interpretation survives.

## Revised semantic object

For a latent history difference \(\delta\), classify its future injection:

\[
J(\delta)
=
\begin{cases}
0,\\
\text{nilpotent},\\
\text{persistent}.
\end{cases}
\]

The earlier Q2 count merges have nilpotent injections.

The new witness has a persistent injection.

## Next gate

Construct the **latent-fringe injection operator** on structural/family data.

The aim is not to store the fringe.

The aim is to compute how a response-redundant fringe can feed:

- future response defects;
- sterile/nilpotent directions;
- persistent decorated-additive dynamics.

That is now the central structural state question.
