# PAPER 6 — Q2 NILPOTENT BALANCING THEOREM SEED v0.1
**Date:** 2026-08-30  
**Status:** exact structural explanation of the Q2 count/equitable split; not a manuscript novelty claim

## Executive result

The first natural Abelian-avoidance examples in this project where

\[
\text{count equivalence}
\supsetneq
\text{stable weighted/equitable equivalence}
\]

have a very simple exact mechanism.

They are not mysterious long-range spectral cancellations.

They arise from **finite-depth nilpotent branch balancing**.

For both Q2 source pairs,

\[
\boxed{
(e_s-e_t)Q^2=0
}
\]

while

\[
(e_s-e_t)Q\ne0.
\]

Their one-step row sums are nevertheless equal.

Therefore their complete weighted state distributions agree after two further
blocks and their total continuation counts agree at every horizon.

---

# 1. General sufficient lemma

Let \(Q\) be a finite weighted transition matrix and let

\[
f_i(n)=e_i^\top Q^n\mathbf1.
\]

Suppose states \(s,t\) satisfy

\[
(e_s-e_t)Q^h=0
\]

for some \(h\ge1\), and

\[
f_s(k)=f_t(k)
\qquad
0\le k<h.
\]

Then

\[
\boxed{
f_s(n)=f_t(n)
\quad\text{for every }n\ge0.
}
\]

## Proof

The assumed prefix equalities handle \(n<h\).

For \(n\ge h\),

\[
(e_s-e_t)Q^n\mathbf1
=
[(e_s-e_t)Q^h]Q^{n-h}\mathbf1
=
0.
\]

Thus the states are all-horizon count equivalent. ∎

This lemma is elementary linear algebra. The research content here is the
natural occurrence and exact structure of the certificate inside the
Abelian-avoidance Q2 system.

---

# 2. Q2 source pair 1

The first exact count-equivalent but non-equitable pair is

\[
(224,1021).
\]

Their one-step weighted rows differ by

\[
\boxed{
e_{930}+e_{933}-e_{1508}-e_{2033}.
}
\]

The four successor classes form two tail-twin pairs:

\[
\boxed{
Q_{930,*}-Q_{2033,*}=e_4,
}
\]

\[
\boxed{
Q_{933,*}-Q_{1508,*}=-e_4.
}
\]

Class \(4\) is the unique zero-outdegree class:

\[
Q_{4,*}=0.
\]

Therefore

\[
(Q_{930,*}-Q_{2033,*})
+
(Q_{933,*}-Q_{1508,*})
=0,
\]

and hence

\[
\boxed{
(e_{224}-e_{1021})Q^2=0.
}
\]

Both source rows have total weight five, so their \(n=1\) continuation counts
also agree.

Thus the whole count-equivalence proof is local:

\[
\boxed{
c_1(224)=c_1(1021)=5,
\qquad
e_{224}^\top Q^2=e_{1021}^\top Q^2.
}
\]

No 2691-step Cayley--Hamilton replay is needed once this certificate is known.

---

# 3. Q2 source pair 2

The second pair is

\[
(1645,2244).
\]

Their one-step row difference is

\[
\boxed{
e_{1199}+e_{2148}-e_{1386}-e_{2245}.
}
\]

Again the successor differences are opposite sterile impulses:

\[
\boxed{
Q_{1199,*}-Q_{1386,*}=e_4,
}
\]

\[
\boxed{
Q_{2148,*}-Q_{2245,*}=-e_4.
}
\]

Therefore

\[
\boxed{
(e_{1645}-e_{2244})Q^2=0.
}
\]

Both source rows have total weight eighteen.

Hence they are count equivalent despite different weighted one-step
distributions.

---

# 4. The first pair is genuinely recurrent

The Q2 equitable quotient contains one recurrent SCC of size

\[
\boxed{1970}.
\]

Both classes

\[
224,\quad1021
\]

belong to this recurrent component.

The tail-twin classes

\[
930,\ 933,\ 1508,\ 2033
\]

also belong to it.

Thus the first count/equitable split is **not merely an initialization-state
artifact**.

A recurrent state can carry a different number of branches into a sterile
transient direction while retaining the same total future count after those
finite impulses balance.

The second source pair mixes one recurrent and one transient class, so both
phenomena occur in the same system.

---

# 5. Tail twins

The exact continuation signatures show the mechanism directly.

For example:

\[
f_{930}(n)=f_{2033}(n)
\qquad(n\ge2),
\]

but

\[
f_{930}(1)-f_{2033}(1)=1.
\]

Likewise

\[
f_{933}(n)=f_{1508}(n)
\qquad(n\ge2),
\]

with the opposite one-step discrepancy.

Their sum therefore cancels.

The same pattern occurs for the second source pair.

These are **one-step transient impulses attached to otherwise identical
two-step distributions**.

---

# 6. How widespread is distributional coalescence?

On the 2691-state Q2 equitable quotient, the number of distinct exact weighted
rows of \(Q^h\) is:

| \(h\) | distinct \(Q^h\) rows | duplicate groups | classes in duplicate groups |
|---:|---:|---:|---:|
| 1 | 2691 | 0 | 0 |
| 2 | 2446 | 217 | 462 |
| 3 | 2335 | 298 | 654 |
| 4 | 2328 | 299 | 662 |
| 5 | 2328 | 299 | 662 |

So exact weighted distributions coalesce much more widely than exact total
counts.

However, when the one-step total count is included with the exact \(Q^2\) row,

\[
\boxed{
\big(c_1(i),\,e_i^\top Q^2\big),
}
\]

there are exactly

\[
\boxed{2689}
\]

classes.

The only non-singletons are precisely

\[
\boxed{
\{224,1021\},
\qquad
\{1645,2244\}.
}
\]

Thus **every exact Q2 count merge is already explained by a two-step
distributional coalescence certificate**.

This is substantially stronger than merely observing equal scalar sequences.

---

# 7. Relation to the nilpotent sector

Let

\[
d=e_s-e_t.
\]

For the two Q2 count-equivalent pairs,

\[
dQ^2=0
\]

but \(dQ\ne0\).

Thus the difference lies in the left generalized zero-eigenspace of the
weighted transition operator with nilpotent depth two.

This is the state-level counterpart of the zero-root factors already observed
in scalar recurrence polynomials.

The scalar Q2 recurrence has

\[
x^{12}
\]

as its transient factor, so the full initialization/counting problem contains
longer nilpotent chains as well.

The two count/equitable counterexamples expose the simplest visible member of
that transient algebra.

---

# 8. Why equitable semantics distinguishes the pair

Stable equitable semantics preserves how much weight is sent to each state
class immediately.

It therefore distinguishes an extra transition into a sterile state even if
another branch elsewhere loses exactly one sterile transition.

Total counting semantics forgets the destination decomposition and retains only

\[
Q^n\mathbf1.
\]

Opposite finite-depth impulses can therefore cancel.

This gives a concrete semantic interpretation of the strict hierarchy

\[
\boxed{
\text{equitable state semantics}
\supsetneq
\text{count semantics}.
}
\]

---

# 9. Consequence for Paper 6

The right state-reduction question is not:

> which histories have identical one-step weighted rows?

Nor even:

> which histories become identical after a fixed number of transition steps?

The exact counting equivalence is

\[
e_s-e_t
\in
V_{\rm cnt}^{\perp},
\]

where

\[
V_{\rm cnt}
=
\operatorname{span}
\{\mathbf1,Q\mathbf1,Q^2\mathbf1,\ldots\}.
\]

The Q2 pairs happen to admit unusually short nilpotent certificates.

That suggests a useful decomposition of future-count redundancy into:

1. **finite-depth nilpotent balancing**;
2. **persistent linear relations** inside the nonzero spectral future space.

The first part is now explicitly visible.

The second is the main remaining explanation problem behind the
1167-dimensional persistent Q2 dynamics.

---

## Current verdict

**Q2 count/equitable split explained exactly.**

The next structural target should strip or quotient the nilpotent finite-depth
branch algebra first, and then analyze the persistent future space separately.

This is a cleaner route than treating all 1179 scalar dimensions as one
undifferentiated object.
