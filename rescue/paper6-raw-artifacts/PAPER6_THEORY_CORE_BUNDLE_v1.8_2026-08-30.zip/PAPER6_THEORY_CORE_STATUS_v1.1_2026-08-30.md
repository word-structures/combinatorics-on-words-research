# PAPER 6 — THEORY CORE STATUS v1.1
**Date:** 2026-08-30  
**Status:** active theory checkpoint

## New result

The Q2 count/equitable split is now explained by finite-depth nilpotent
balancing.

For both natural Q2 count-equivalent pairs:

\[
(e_s-e_t)Q^2=0
\]

with equal one-step totals.

At Q1 there are already 12 two-step distribution-coalescent pairs, but none
balance their first-step count, so no count merge occurs.

At Q2 there are 217 two-step coalescence groups, and exactly two balance.
Those are exactly the two exact count merges.

## Scalar transient removal

The exact Q2 scalar recurrence

\[
1179=12+1167
\]

has a direct time-domain interpretation.

Removing the \(x^{12}\) factor yields the degree-1167 persistent recurrence.
It fails for exactly 12 initial recurrence positions and then holds forever.

Shifting the count sequence by 12 terms reduces the modular minimal degree from
1179 to 1167 and removes the zero-root factor entirely.

## Refined next target

Do not try to explain all 1179 scalar dimensions together.

The next object is:

\[
\boxed{
\text{1167-dimensional persistent Q2 future space}.
}
\]

Finite-depth nilpotent branch effects should be stripped or tracked separately.

Primary next questions:

1. Which structural observables span the persistent future?
2. How much of the persistent space is visible directly from decorated profile
   second-difference templates?
3. Can the persistent operator be applied without materializing the
   218,298-state suffix graph?
4. Can Q3 be reached through that persistent/structural path?
