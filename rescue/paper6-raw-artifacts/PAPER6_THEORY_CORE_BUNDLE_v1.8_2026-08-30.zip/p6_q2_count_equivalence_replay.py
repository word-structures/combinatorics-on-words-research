from pathlib import Path
from collections import defaultdict
import importlib.util, json
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('fb',HERE/'p6_affine_fast_builder.py'); fb=importlib.util.module_from_spec(spec); spec.loader.exec_module(fb)
p6=fb.p6

def main():
    B=p6.library(4); states,edges,labels,init=fb.build_fast(B,11)
    eq=p6.equitable(states,edges); Q,groups,rem=p6.quotient(states,edges,eq); q=len(Q)
    assert len(states)==218298 and q==2691
    qrows=[[(j,w) for j,w in enumerate(row) if w] for row in Q]
    # 20 horizons isolate the only candidate merged pairs.
    v=[1]*q; sig=[[] for _ in range(q)]
    for _ in range(20):
        for i,x in enumerate(v): sig[i].append(x)
        v=[sum(w*v[j] for j,w in row) for row in qrows]
    buckets=defaultdict(list)
    for i,s in enumerate(sig): buckets[tuple(s)].append(i)
    pairs=[tuple(x) for x in buckets.values() if len(x)>1]
    assert pairs==[(224,1021),(1645,2244)]
    # Exact Cayley-Hamilton horizon on the 2691-state quotient.
    v=[1]*q
    for _ in range(q):
        for a,b in pairs: assert v[a]==v[b]
        v=[sum(w*v[j] for j,w in row) for row in qrows]
    cm=list(range(q)); cm[1021]=224; cm[2244]=1645
    canon={}; cid=[]
    for x in cm:
        if x not in canon: canon[x]=len(canon)
        cid.append(canon[x])
    assert len(set(cid))==2689
    def agg(i):
        d=defaultdict(int)
        for j,w in qrows[i]: d[cid[j]]+=w
        return d
    for a,b in pairs: assert agg(a)!=agg(b)
    out={'raw_states':len(states),'equitable_classes':2691,'exact_count_classes':2689,
         'certified_pairs':[list(x) for x in pairs],'exact_equal_horizons_checked':2691,
         'count_partition_is_not_equitable':True}
    p=HERE/'P6_Q2_COUNT_EQUIVALENCE_REPLAY_RESULT_v0.1_2026-08-30.json';p.write_text(json.dumps(out,indent=2));print('PASS',p)
if __name__=='__main__':main()
