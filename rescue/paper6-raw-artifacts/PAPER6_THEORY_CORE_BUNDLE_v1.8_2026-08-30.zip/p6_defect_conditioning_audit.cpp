#include <bits/stdc++.h>
using namespace std;
struct V{int a,b,c;};
static inline V addv(V x,V y){return {x.a+y.a,x.b+y.b,x.c+y.c};}
static inline V subv(V x,V y){return {x.a-y.a,x.b-y.b,x.c-y.c};}
static inline V negv(V x){return {-x.a,-x.b,-x.c};}
static inline bool zero(V x){return x.a==0&&x.b==0&&x.c==0;}
static inline int encE(V x){return (x.a+16)*33*33+(x.b+16)*33+(x.c+16);}
struct Block{array<int,4>x; V p; array<V,5> pref; int pid; string s;};

bool is_forbid4(const string&s){static set<string> F={"abbc","accb","baac","bcca","caab","cbba"}; return F.count(s);}
bool abelianK2(const string&s){ if(s.size()!=4) return false; int x[3]={0},y[3]={0}; for(int i=0;i<2;i++)x[s[i]-'a']++;for(int i=2;i<4;i++)y[s[i]-'a']++;return x[0]==y[0]&&x[1]==y[1]&&x[2]==y[2];}

struct Rec {V D,E; bool actual; int g; int p0,pm,pr,p2;};

int main(){
 vector<Block>B; map<tuple<int,int,int>,int> pids;
 for(int n=0;n<81;n++){
   int z=n; string s(4,'a'); array<int,4>a; for(int i=3;i>=0;i--){a[i]=z%3; s[i]='a'+a[i]; z/=3;}
   if(is_forbid4(s)||abelianK2(s)) continue;
   V p{0,0,0}; array<V,5> pref; pref[0]={0,0,0};
   for(int i=0;i<4;i++){ if(a[i]==0)p.a++; else if(a[i]==1)p.b++; else p.c++; pref[i+1]=p; }
   auto key=make_tuple(p.a,p.b,p.c); if(!pids.count(key))pids[key]=pids.size();
   B.push_back({a,p,pref,pids[key],s});
 }
 cerr<<"blocks="<<B.size()<<" profiles="<<pids.size()<<"\n";
 if(B.size()!=60){cerr<<"bad library\n"; return 1;}
 const int NONE=31;
 // catalogs per filter key -> defect set
 using Cat=unordered_map<unsigned long long, unordered_set<int>>;
 array<Cat,6> cats;
 auto pack=[&](initializer_list<int> vals){ unsigned long long k=0,m=1; for(int v:vals){k+=m*(unsigned long long)(v+1);m*=40;} return k;};
 auto process=[&](auto fn){
   long long total=0,actual=0;
   for(int ia=0;ia<(int)B.size();ia++)for(int ib=0;ib<(int)B.size();ib++)for(int ic=0;ic<(int)B.size();ic++){
     array<int,3> ids={ia,ib,ic};
     for(int K=4;K<=6;K++){
       int q=K/4,r=K%4;
       int maxs=12-2*K;
       for(int s=0;s<=maxs;s++){
         int m0=s/4,i0=s%4; int m1=(s+K)/4,i1=(s+K)%4; int m2=(s+2*K)/4,i2=(s+2*K)%4;
         int c0=(m1-m0)-q, c1=(m2-m1)-q;
         V left{0,0,0},right{0,0,0};
         for(int t=m1-q;t<m1;t++) left=addv(left,B[ids[t]].p);
         for(int t=m1;t<m1+q;t++) right=addv(right,B[ids[t]].p);
         V D=subv(right,left), E{0,0,0};
         if(c1) E=addv(E,B[ids[m1+q]].p);
         if(c0) E=subv(E,B[ids[m0]].p);
         E=addv(E,B[ids[m0]].pref[i0]);
         V pm=B[ids[m1]].pref[i1]; E.a-=2*pm.a;E.b-=2*pm.b;E.c-=2*pm.c;
         if(i2>0) E=addv(E,B[ids[m2]].pref[i2]);
         bool act=zero(addv(D,E));
         int p0=B[ids[m0]].pid, pM=B[ids[m1]].pid, pR=B[ids[m1+q]].pid, p2=(i2>0?B[ids[m2]].pid:NONE);
         int geom=i0*4+r;
         Rec rec{D,E,act,geom,p0,pM,pR,p2}; fn(rec);
         total++; actual+=act;
       }
     }
   }
   return pair<long long,long long>{total,actual};
 };
 auto keyFor=[&](int f,const Rec&r)->unsigned long long{
   switch(f){
     case 0:return pack({r.g});
     case 1:return pack({r.g,r.p0});
     case 2:return pack({r.g,r.pm});
     case 3:return pack({r.g,r.p0,r.pm});
     case 4:return pack({r.g,r.p0,r.pm,r.pr});
     default:return pack({r.g,r.p0,r.pm,r.pr,r.p2});
   }
 };
 auto first=process([&](const Rec&r){int e=encE(r.E);for(int f=0;f<6;f++)cats[f][keyFor(f,r)].insert(e);});
 array<long long,6> cand{};
 auto second=process([&](const Rec&r){int target=encE(negv(r.D));for(int f=0;f<6;f++)if(cats[f][keyFor(f,r)].count(target))cand[f]++;});
 if(first!=second){cerr<<"pass mismatch\n";return 1;}
 vector<string> names={"geometry","geometry+p_start_profile","geometry+p_mid_profile","geometry+p_start+mid_profiles","geometry+three_role_profiles","geometry+all_boundary_profiles"};
 cout<<"{\n  \"library\":\"ALL_L4_AA2FR\",\n  \"records\":"<<first.first<<",\n  \"actual\":"<<first.second<<",\n  \"filters\":{\n";
 for(int f=0;f<6;f++){
   long long keys=cats[f].size(), sum=0,sing=0,mx=0; for(auto &kv:cats[f]){long long n=kv.second.size();sum+=n;mx=max(mx,n);if(n==1)sing++;}
   cout<<"    \""<<names[f]<<"\":{\"keys\":"<<keys<<",\"candidate_count\":"<<cand[f]<<",\"candidate_fraction\":"<<setprecision(15)<<(double)cand[f]/first.first<<",\"actual_over_candidate\":"<<(double)first.second/cand[f]<<",\"max_defects_per_key\":"<<mx<<",\"mean_defects_per_key\":"<<(double)sum/keys<<",\"singleton_key_fraction\":"<<(double)sing/keys<<"}"<<(f<5?",":"")<<"\n";
 }
 cout<<"  }\n}\n";
}
