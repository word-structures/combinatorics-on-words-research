from pathlib import Path
from collections import defaultdict
import json, importlib.util
H=Path('/mnt/data')
spec=importlib.util.spec_from_file_location('fb',H/'p6_affine_fast_builder.py');fb=importlib.util.module_from_spec(spec);spec.loader.exec_module(fb);p6=fb.p6

def rank_bit(vs):
    piv={}
    for x in vs:
        while x:
            p=x.bit_length()-1
            if p in piv:x^=piv[p]
            else:piv[p]=x;break
    return len(piv)

def basis_bit(vs):
    piv={}
    for x in vs:
        while x:
            p=x.bit_length()-1
            if p in piv:x^=piv[p]
            else:piv[p]=x;break
    return list(piv.values())

def make_indicator_vectors(vals):
    d=defaultdict(int)
    for i,v in enumerate(vals):d[v]|=1<<i
    return list(d.values()),len(d)

def q_rows_bit(Q):
    out=[]
    for row in Q:
        x=0
        if isinstance(row,dict): items=row.items()
        elif row and isinstance(row[0],(list,tuple)) and len(row[0])==2: items=row
        else: items=enumerate(row)
        for j,w in items:
            if w&1:x^=1<<j
        out.append(x)
    return out

def matvec_col(QB,v):
    x=0
    for i,row in enumerate(QB):
        if (row & v).bit_count()&1:x|=1<<i
    return x

def persistent_krylov(QB,shift,max_steps=4000):
    n=len(QB); v=(1<<n)-1
    for _ in range(shift):v=matvec_col(QB,v)
    vec=[]; piv={}
    stable=0
    for h in range(max_steps):
        x=v
        while x:
            p=x.bit_length()-1
            if p in piv:x^=piv[p]
            else:piv[p]=x;vec.append(v);stable=0;break
        else:stable+=1
        v=matvec_col(QB,v)
        if stable>n+5:break
        # recurrence means after first dependent vector subsequent stay in span, but use short conservative stop
        if stable>=10:break
    return basis_bit(vec)

def prof(w): return p6.parikh(w)
def subv(a,b):return tuple(x-y for x,y in zip(a,b))
def addv(*aa):return tuple(sum(x) for x in zip(*aa))

def chunks_from_end(s,L,count):
    out=[]
    for k in range(count):
        b=s[len(s)-(k+1)*L:len(s)-k*L]
        out.append(b if len(b)==L else None)
    return out

def audit(Qname,Q,reps,response_groups,shift):
    n=len(Q); QB=q_rows_bit(Q)
    Kbasis=persistent_krylov(QB,shift)
    kr=rank_bit(Kbasis)
    resp_id=[None]*n
    for gid,g in enumerate(response_groups):
        for i in g:resp_id[i]=gid
    vals={}
    blocks=[chunks_from_end(s,4,6) for s in reps]
    pseq=[[prof(b) if b else None for b in bs] for bs in blocks]
    vals['last_profile']=[ps[0] for ps in pseq]
    vals['last2_profile_sequence']=[tuple(ps[:2]) for ps in pseq]
    vals['last4_profile_sequence']=[tuple(ps[:4]) for ps in pseq]
    vals['last_block_literal']=[bs[0] for bs in blocks]
    vals['last2_block_literal']=[tuple(bs[:2]) for bs in blocks]
    def d1(ps):
        return None if ps[0] is None or ps[1] is None else subv(ps[0],ps[1])
    def d2(ps):
        return None if any(x is None for x in ps[:4]) else subv(addv(ps[0],ps[1]),addv(ps[2],ps[3]))
    vals['D1']=[d1(ps) for ps in pseq]
    vals['D2']=[d2(ps) for ps in pseq]
    vals['D1_D2']=[(d1(ps),d2(ps)) for ps in pseq]
    vals['response_orbit']=resp_id
    vals['response_plus_D1']=[(resp_id[i],d1(pseq[i])) for i in range(n)]
    vals['response_plus_D1_D2']=[(resp_id[i],d1(pseq[i]),d2(pseq[i])) for i in range(n)]
    vals['response_plus_last4_profiles']=[(resp_id[i],tuple(pseq[i][:4])) for i in range(n)]
    # direct-sum additive feature family: indicators for each position profile, each D separately, response
    family_sets={}
    for k in range(1,5):
        family_sets[f'profile_positions_1_to_{k}']=[]
        for pos in range(k):
            v,_=make_indicator_vectors([ps[pos] for ps in pseq]);family_sets[f'profile_positions_1_to_{k}']+=v
    d1v,_=make_indicator_vectors(vals['D1']);d2v,_=make_indicator_vectors(vals['D2']);rv,_=make_indicator_vectors(resp_id)
    family_sets['D1_and_D2_separate']=d1v+d2v
    family_sets['response_plus_D1_D2_separate']=rv+d1v+d2v
    out={'name':Qname,'states':n,'persistent_shift':shift,'persistent_krylov_rank_GF2':kr,'categorical':{},'additive_families':{}}
    for name,xvals in vals.items():
        F,m=make_indicator_vectors(xvals); fr=rank_bit(F); cr=rank_bit(F+Kbasis)
        out['categorical'][name]={'categories':m,'feature_rank_GF2':fr,'combined_with_persistent_rank_GF2':cr,'contains_persistent':cr==fr,'missing_dimensions_lower_bound':cr-fr}
    for name,F in family_sets.items():
        fr=rank_bit(F);cr=rank_bit(F+Kbasis)
        out['additive_families'][name]={'feature_rank_GF2':fr,'combined_with_persistent_rank_GF2':cr,'contains_persistent':cr==fr,'missing_dimensions_lower_bound':cr-fr}
    return out

# Q2 saved quotient + response orbits/reps
D2=json.load(open(H/'P6_Q2_EQUITABLE_QUOTIENT_SPARSE_v0.1_2026-08-30.json'))
Q2=D2['rows']; O2=json.load(open(H/'P6_Q2_TWISTED_RESPONSE_ORBITS_FULL_v0.1_2026-08-30.json'))
out2=audit('Q2',Q2,O2['representatives'],O2['groups'],12)
print('Q2 persistent',out2['persistent_krylov_rank_GF2'],flush=True)
for k,v in out2['categorical'].items():print('Q2',k,v,flush=True)
# Q1 rebuild compactly
B=p6.library(4);S,E,L,I=fb.build_fast(B,7);eq=p6.equitable(S,E);Q1,G,rem=p6.quotient(S,E,eq);q=len(Q1); reps=[None]*q
for c,ss in G.items():reps[rem[c]]=min(ss)
# response groups modulo perms
from itertools import permutations
PERMS=[dict(zip('abc',x)) for x in permutations('abc')]
def tw(w,mp):return ''.join(mp[c] for c in w)
def canon(W):return min(tuple(sorted(tw(w,mp) for w in W)) for mp in PERMS)
rg=defaultdict(list)
for i,s in enumerate(reps):rg[canon(L[s].keys())].append(i)
R1=sorted(rg.values(),key=lambda x:x[0])
out1=audit('Q1',Q1,reps,R1,7)
print('Q1 persistent',out1['persistent_krylov_rank_GF2'],flush=True)
for k,v in out1['categorical'].items():print('Q1',k,v,flush=True)
out={'date':'2026-08-30','field':'GF2 exact','Q1':out1,'Q2':out2}
(H/'P6_PERSISTENT_OBSERVABLE_SPAN_AUDIT_v0.1_2026-08-30.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
