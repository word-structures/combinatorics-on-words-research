from pathlib import Path
from collections import defaultdict,Counter
from itertools import permutations,combinations
import json,importlib.util
H=Path('/mnt/data')
O=json.load(open(H/'P6_Q2_TWISTED_RESPONSE_ORBITS_FULL_v0.1_2026-08-30.json')); reps=O['representatives']; groups=O['groups']
spec=importlib.util.spec_from_file_location('fb',H/'p6_affine_fast_builder.py');fb=importlib.util.module_from_spec(spec);spec.loader.exec_module(fb);p6=fb.p6
B=p6.library(4); idx={b:i for i,b in enumerate(B)}; masks,fm=fb.compile_masks(B,4,11);allmask=(1<<len(B))-1;mem=21
PERMS=[''.join(x) for x in permutations('abc')]
perm_idx={};mpdict={}
for name in PERMS:
 mp=dict(zip('abc',name));mpdict[name]=mp;perm_idx[name]=[idx[''.join(mp[c] for c in b)] for b in B]
cache={}
def lm(s):
 if s in cache:return cache[s]
 m=fm[s[-3:]]
 for k,j in fb.geometries(4,11):
  r=fb.requirement(s,k,j)
  if r is not None:m|=masks[(k,j)].get(r,0)
 z=allmask&~m;cache[s]=z;return z
def pmask(m,name):
 out=0;arr=perm_idx[name]
 while m:
  bit=m&-m;i=bit.bit_length()-1;m-=bit;out|=1<<arr[i]
 return out
def match0(s,t,name):return pmask(lm(s),name)==lm(t)
def pass_next(pairs):
 out=[]
 for s,t,name in pairs:
  m=lm(s);ok=True
  while m:
   bit=m&-m;bi=bit.bit_length()-1;m-=bit;bj=perm_idx[name][bi]
   if not match0((s+B[bi])[-mem:],(t+B[bj])[-mem:],name):ok=False;break
  if ok:out.append((s,t,name))
 return out
# initial pair-permutation triples, but keep one record per class pair if any perm survives depth
pair_perms={}
for g in groups:
 if len(g)<2:continue
 for a,b in combinations(g,2):
  pp=[name for name in PERMS if match0(reps[a],reps[b],name)]
  pair_perms[(a,b)]=pp
counts=[{'depth':0,'class_pairs_with_some_perm':len(pair_perms),'pair_perm_triples':sum(len(v) for v in pair_perms.values())}]
current={(a,b,name) for (a,b),ps in pair_perms.items() for name in ps}
for d in range(1,8):
 nxt=set()
 for a,b,name in current:
  s,t=reps[a],reps[b];m=lm(s);ok=True
  for bi in range(len(B)):
   if (m>>bi)&1:
    bj=perm_idx[name][bi]
    if not match0((s+B[bi])[-mem:],(t+B[bj])[-mem:],name):ok=False;break
  if ok:nxt.add((a,b,name))
 current=nxt
 pairs={(a,b) for a,b,name in current}
 counts.append({'depth':d,'class_pairs_with_some_perm':len(pairs),'pair_perm_triples':len(current)})
 print(counts[-1],flush=True)
 # IMPORTANT: for depth>1 need recursively require successors depth d-1, not just match0. Build direct recursive below if d==1.
 if d==1:break
# Recursive/memo exact depth for initial depth1-perfect triples
from functools import lru_cache
@lru_cache(maxsize=None)
def survives(s,t,name,d):
 if not match0(s,t,name):return False
 if d==0:return True
 m=lm(s)
 while m:
  bit=m&-m;bi=bit.bit_length()-1;m-=bit;bj=perm_idx[name][bi]
  if not survives((s+B[bi])[-mem:],(t+B[bj])[-mem:],name,d-1):return False
 return True
initial=[]
for (a,b),ps in pair_perms.items():
 for name in ps:
  if survives(reps[a],reps[b],name,1):initial.append((a,b,name))
res=[{'depth':0,'pairs':len(pair_perms)},{'depth':1,'pairs':len({(a,b) for a,b,n in initial}),'triples':len(initial)}]
cur=initial
for d in range(2,8):
 good=[x for x in cur if survives(reps[x[0]],reps[x[1]],x[2],d)]
 res.append({'depth':d,'pairs':len({(a,b) for a,b,n in good}),'triples':len(good)})
 print('deep',res[-1],flush=True)
 cur=good
 if not cur:break
# exact count merge membership
merges={frozenset((224,1021)),frozenset((1645,2244))}
for r in res:r['contains_exact_count_merge_pair']=any(frozenset((a,b)) in merges for a,b,n in cur) if cur else False
out={'date':'2026-08-30','same_fixed_permutation_synchronous_depth_counts':res,'memo_entries':survives.cache_info().currsize}
(H/'P6_Q2_SYNCHRONOUS_RESPONSE_DEPTH_AUDIT_v0.1_2026-08-30.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out,indent=2))
