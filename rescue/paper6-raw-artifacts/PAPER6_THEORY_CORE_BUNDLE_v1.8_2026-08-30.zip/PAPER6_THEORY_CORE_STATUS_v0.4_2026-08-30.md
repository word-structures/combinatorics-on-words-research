# PAPER 6 — THEORY CORE STATUS v0.4
**Date:** 2026-08-30  
**Status:** active research checkpoint

## P6-C7b result

The long-period character-boundary layer has now been reduced to an exact
finite cut-profile family interface.

For each long-period geometry:

\[
D_q+A-2B+C=0,
\]

where:

- \(D_q\) is the long-range block-profile second difference;
- \(A,B,C\) are local segment Parikh vectors determined at the three cutpoints.

The local interface has only \(L^2\) geometries.

A block at a cut is represented by

\[
(\text{prefix Parikh},\text{suffix Parikh}),
\]

which simultaneously preserves the fragment data and the full block profile.

For a ternary alphabet, the total number of possible cut-profile descriptor
types across all cuts obeys

\[
N_{\rm cut}(L)\le\binom{L+5}{5}.
\]

At L=40:

\[
N_{\rm cut}(40)\le1\,221\,759.
\]

This is polynomial in L and independent of the literal word count.

## Machine evidence

Segmented generating-operator coefficient DP reproduced literal enumeration
exactly:

- BAL3 L4, K4: 414 states × 5 cuts, 0 mismatches;
- INTERIOR L5, K5: 1146 states × 6 cuts, 0 mismatches.

The full-L4 defect-conditioning audit also showed why whole profiles alone are
not sufficient: even with all relevant boundary whole-block profiles, 49.1 %
of windows remain candidates while only 9.2 % are actual squares.

Partial cut profiles are the missing exact local information.

## Architecture now

Short periods \(K<L\):

\[
\text{finite Paper-4/Paper-5 local geometry compiler}.
\]

Long periods \(K\ge L\):

\[
\text{finite cut-profile boundary compiler}
+
\text{unbounded block-profile second-difference dynamics}.
\]

Thus the character-level geometry is no longer the open part.

## Next gate — P6-C7c

Study the **decorated additive profile language**

\[
P_{m+q}-2P_m+P_{m-q}=-E_g,
\]

where \(E_g\) is supplied by the finite cut-profile boundary decoration.

Questions:

1. Can this language be expressed as a finite family of decorated additive
   templates in a form suitable for exact weighted counting?
2. For a finite block-range cutoff \(Q\), can we build its transfer action
   directly on profile/family data and reproduce the character-cutoff counts?
3. Does its minimal scalar future dimension remain small as \(Q\) increases?
4. Which part of the long-range dynamics is classical additive-template theory
   and which part is new selected-library counting structure?

The next research object is now the profile prefix-sum walk, not the character
suffix.
