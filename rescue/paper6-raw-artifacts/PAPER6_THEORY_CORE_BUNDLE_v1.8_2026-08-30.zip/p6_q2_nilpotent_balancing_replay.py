#!/usr/bin/env python3
"""Replay the Q2 nilpotent-balancing certificate from the saved sparse quotient."""
from pathlib import Path
from collections import defaultdict
import json

H=Path(__file__).resolve().parent
D=json.loads((H/"P6_Q2_EQUITABLE_QUOTIENT_SPARSE_v0.1_2026-08-30.json").read_text())
Q=[dict(r) for r in D["rows"]]

def diff(a,b):
    return {j:Q[a].get(j,0)-Q[b].get(j,0)
            for j in sorted(set(Q[a])|set(Q[b]))
            if Q[a].get(j,0)!=Q[b].get(j,0)}

def compose_row(row):
    out={}
    for j,a in row.items():
        for k,b in Q[j].items():
            out[k]=out.get(k,0)+a*b
    return {k:v for k,v in out.items() if v}

def row2(i):
    return compose_row(Q[i])

assert [i for i,r in enumerate(Q) if not r] == [4]

assert diff(930,2033)=={4:1}
assert diff(933,1508)=={4:-1}
assert diff(1199,1386)=={4:1}
assert diff(2148,2245)=={4:-1}

assert diff(224,1021)=={930:1,933:1,1508:-1,2033:-1}
assert diff(1645,2244)=={1199:1,1386:-1,2148:1,2245:-1}

for a,b in [(224,1021),(1645,2244)]:
    assert sum(Q[a].values())==sum(Q[b].values())
    assert row2(a)==row2(b)
    assert Q[a]!=Q[b]

# Exact count partition from c1 + Q^2 row.
groups=defaultdict(list)
for i in range(len(Q)):
    groups[(sum(Q[i].values()),tuple(sorted(row2(i).items())))].append(i)
multi=[g for g in groups.values() if len(g)>1]
assert len(groups)==2689
assert multi==[[224,1021],[1645,2244]]

print("PASS")
print("Q2 exact count merges:",multi)
print("Each merge has equal c1 and identical exact Q^2 distribution.")
