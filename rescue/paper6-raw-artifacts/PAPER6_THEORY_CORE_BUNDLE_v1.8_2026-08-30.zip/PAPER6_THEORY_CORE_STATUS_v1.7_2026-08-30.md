# PAPER 6 — THEORY CORE STATUS v1.7
**Date:** 2026-08-30  
**Status:** major theory checkpoint

## Exact Q2 future dimension

A new exact integer vector certificate proves

\[
\boxed{
\dim_{\mathbb Q}
\operatorname{span}
\{\mathbf1,Q\mathbf1,Q^2\mathbf1,\ldots\}
=
1179.
}
\]

The degree-1179 recurrence polynomial annihilates the full
2691-coordinate vector sequence, not only the initial scalar assembly count.

Thus:

\[
\boxed{
2689\text{ exact count classes}
\quad\text{vs.}\quad
1179\text{ exact linear future dimensions}.
}
\]

## Static structural partition no-go

The richest current projected-obstruction + complete recent-profile descriptor
has 2589 types.

It is still count-unsound.

It also separates both true Q2 count-equivalent pairs.

Therefore refinement-only algorithms starting from this descriptor cannot
recover the minimal count quotient.

One weighted successor refinement gives the full 2691 equitable classes.

Count-moment augmentation gives

\[
2589\to2642\to2688\to2691.
\]

## Revised architecture

P4/P5 descriptors are:

\[
\boxed{
\text{features / compiler outputs / candidate relations}
}
\]

not a final state partition.

P6 must construct:

\[
\boxed{
\text{signed linear future semantics}.
}
\]

## Current exact Q2 hierarchy

\[
218298
\to
2691
\to
2689
\to
1179
=
12+1167.
\]

Interpretation:

- literal cutoff histories;
- stable weighted/equitable states;
- distinct all-horizon count behaviors;
- minimal exact statewise linear future dimension;
- transient + persistent split.

## Next gate

Search for a **direct structural basis for the 1179-dimensional vector Krylov
space**.

Do not require basis vectors to be indicator functions of history classes.

Allow signed observables generated from:

- decorated additive profile constraints;
- cut-profile family operators;
- response cocycles;
- latent-fringe injection operators.

The object to construct is now explicitly a linear invariant space.
