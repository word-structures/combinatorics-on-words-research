from pathlib import Path
import json,random,statistics,time,math
H=Path('/mnt/data')
D=json.load(open(H/'P6_Q2_EQUITABLE_QUOTIENT_SPARSE_v0.1_2026-08-30.json'))
O=json.load(open(H/'P6_Q2_TWISTED_RESPONSE_ORBITS_FULL_v0.1_2026-08-30.json'))
rows=D['rows']; n=len(rows); sizes=[len(g) for g in O['groups']]
QB=[]
for row in rows:
    x=0
    for j,w in row:
        if w&1: x ^= 1<<j
    QB.append(x)

def rank(vs):
    piv={}
    for x in vs:
        while x:
            p=x.bit_length()-1
            if p in piv: x ^= piv[p]
            else: piv[p]=x; break
    return len(piv)

def mulQ_row(x):
    o=0
    while x:
        l=x&-x; i=l.bit_length()-1; x-=l; o ^= QB[i]
    return o

selected_h=(0,1,2,4,8,11,12)
# Precompute rows of Q^h over GF2.
powers={0:[1<<i for i in range(n)]}
cur=powers[0]
for h in range(1,13):
    cur=[mulQ_row(x) for x in cur]
    if h in selected_h: powers[h]=cur[:]

def rank_groups(groups,h):
    ph=powers[h]
    vec=[]
    for g in groups:
        r=g[0]; rr=ph[r]
        for i in g[1:]: vec.append(ph[i]^rr)
    return rank(vec)

def eval_groups(groups):
    return {h:rank_groups(groups,h) for h in selected_h}

actual=eval_groups(O['groups'])
print('actual',actual,flush=True)
trials=[]
NTR=70
for seed in range(NTR):
    rng=random.Random(1234567+seed)
    v=list(range(n)); rng.shuffle(v)
    groups=[]; off=0
    for z in sizes:
        groups.append(v[off:off+z]); off+=z
    x=eval_groups(groups); trials.append(x)
    if (seed+1)%10==0: print('done',seed+1,flush=True)
summary={}
for h in selected_h:
    vals=[x[h] for x in trials]
    mu=statistics.mean(vals); sd=statistics.pstdev(vals)
    less=sum(v<=actual[h] for v in vals)
    summary[str(h)]={
        'actual':actual[h], 'random_mean':mu,'random_pstdev':sd,
        'random_min':min(vals),'random_max':max(vals),
        'actual_minus_mean':actual[h]-mu,
        'z_vs_random': (actual[h]-mu)/sd if sd else None,
        'empirical_fraction_random_le_actual':less/NTR,
        'random_values':vals
    }
out={'date':'2026-08-30','field':'GF2 exact','trials':NTR,'selected_h':list(selected_h),'actual':actual,'summary':summary}
(H/'P6_Q2_RESPONSE_VS_RANDOM_GF2_FAST_v0.9_2026-08-30.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps({h:{k:v for k,v in summary[str(h)].items() if k!='random_values'} for h in selected_h},indent=2))
