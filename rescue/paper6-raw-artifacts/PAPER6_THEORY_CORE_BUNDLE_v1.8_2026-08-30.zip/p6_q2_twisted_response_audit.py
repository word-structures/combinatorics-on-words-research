from pathlib import Path
from collections import defaultdict
from itertools import permutations
import importlib.util,json,time
H=Path('/mnt/data')
spec=importlib.util.spec_from_file_location('fb',H/'p6_affine_fast_builder.py'); fb=importlib.util.module_from_spec(spec); spec.loader.exec_module(fb); p6=fb.p6
SAVED=json.load(open(H/'P6_Q2_EQUITABLE_QUOTIENT_SPARSE_v0.1_2026-08-30.json')); Q=SAVED['rows']; q=len(Q)
PERMS=[dict(zip('abc',x)) for x in permutations('abc')]
PERM_NAMES=[''.join(x) for x in permutations('abc')]
def trans_word(w,mp): return ''.join(mp[c] for c in w)
def mv(v): return [sum(w*v[j] for j,w in row) for row in Q]
# quotient count sigs 0..5
v=[1]*q; qsig=[[] for _ in range(q)]
for _ in range(6):
 for i,x in enumerate(v): qsig[i].append(x)
 v=mv(v)
sig2q=defaultdict(list)
for i,s in enumerate(qsig): sig2q[tuple(s)].append(i)
# collapsed q row by successor count-signature id for duplicate disambiguation
keys=sorted(set(tuple(s) for s in qsig)); kid={k:i for i,k in enumerate(keys)}
def cqrow(i):
 d=defaultdict(int)
 for j,w in Q[i]: d[kid[tuple(qsig[j])]]+=w
 return tuple(sorted(d.items()))
cq={i:cqrow(i) for i in range(q)}

B=p6.library(4); states,edges,labels,init=fb.build_fast(B,11); SS=sorted(states)
rv={s:1 for s in SS}; rsig={s:[] for s in SS}
for _ in range(6):
 for s in SS: rsig[s].append(rv[s])
 rv={s:sum(w*rv[t] for t,w in edges.get(s,{}).items()) for s in SS}
rawkid={s:kid[tuple(rsig[s])] for s in SS}
def rawclass(s):
 cand=sig2q[tuple(rsig[s])]
 if len(cand)==1:return cand[0]
 d=defaultdict(int)
 for t,w in edges.get(s,{}).items(): d[rawkid[t]]+=w
 rr=tuple(sorted(d.items()))
 hit=[i for i in cand if cq[i]==rr]
 if len(hit)!=1: raise RuntimeError((s,cand,hit))
 return hit[0]
# choose representative for every q class
reps=[None]*q
for s in SS:
 i=rawclass(s)
 if reps[i] is None: reps[i]=s
assert all(x is not None for x in reps)
print('reps done',flush=True)
# legal sets and canonical perm orbit signature
legal=[set(labels[s].keys()) for s in reps]
def canonical_set(W):
 variants=[]
 for name,mp in zip(PERM_NAMES,PERMS): variants.append((tuple(sorted(trans_word(w,mp) for w in W)),name))
 return min(variants)
groups=defaultdict(list)
canon=[]
for i,W in enumerate(legal):
 c=canonical_set(W)[0]; canon.append(c); groups[c].append(i)
multi=[g for g in groups.values() if len(g)>1]
print('canonical response groups',len(groups),'multi',len(multi),'states in multi',sum(map(len,multi)),'max',max(map(len,multi)),flush=True)
# exact permutations between pairs in multi groups, and whether count-equivalent signatures same
candidate={(224,1021),(1645,2244)}
summary={'date':'2026-08-30','equitable_classes':q,'canonical_legal_response_orbits':len(groups),'multi_response_orbits':len(multi),'classes_in_multi_response_orbits':sum(map(len,multi)),'max_response_orbit_group_size':max(map(len,multi)),'candidate_pairs':[],'same_response_orbit_same_count_signature_pairs':0,'same_response_orbit_pairs_total':0}
for group in multi:
 for ia in range(len(group)):
  for ib in range(ia+1,len(group)):
   a,b=group[ia],group[ib]; summary['same_response_orbit_pairs_total']+=1
   if tuple(qsig[a])==tuple(qsig[b]): summary['same_response_orbit_same_count_signature_pairs']+=1
for a,b in [(224,1021),(1645,2244)]:
 perms=[]
 for name,mp in zip(PERM_NAMES,PERMS):
  if {trans_word(w,mp) for w in legal[a]}==legal[b]: perms.append(name)
 # mapped successor comparison for first such perm
 maps=[]
 for name in perms:
  mp=dict(zip('abc',name)); items=[]
  for w in sorted(legal[a]):
   z=trans_word(w,mp); sa=rawclass(labels[reps[a]][w]); sb=rawclass(labels[reps[b]][z])
   items.append({'A_block':w,'A_succ':sa,'B_block':z,'B_succ':sb,'same_succ_class':sa==sb})
  maps.append({'perm_image_abc':name,'mapped_branches':items,'same_successor_branches':sum(x['same_succ_class'] for x in items),'total_branches':len(items)})
 summary['candidate_pairs'].append({'A':a,'B':b,'A_rep':reps[a],'B_rep':reps[b],'permutations_mapping_legal_sets':perms,'maps':maps})
path=H/'P6_Q2_TWISTED_RESPONSE_AUDIT_v0.1_2026-08-30.json'; path.write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(path)
print(json.dumps({k:v for k,v in summary.items() if k!='candidate_pairs'},indent=2))
for x in summary['candidate_pairs']:
 print('PAIR',x['A'],x['B'],'perms',x['permutations_mapping_legal_sets'])
 for m in x['maps']: print(m['perm_image_abc'],m['same_successor_branches'],'/',m['total_branches'])
