#include <bits/stdc++.h>
using namespace std;
struct V{int a,b,c;}; static inline V addv(V x,V y){return{x.a+y.a,x.b+y.b,x.c+y.c};} static inline V subv(V x,V y){return{x.a-y.a,x.b-y.b,x.c-y.c};} static inline V negv(V x){return{-x.a,-x.b,-x.c};} static inline V mul(int k,V x){return{k*x.a,k*x.b,k*x.c};} static inline bool eq(V x,V y){return x.a==y.a&&x.b==y.b&&x.c==y.c;} static inline bool zero(V x){return x.a==0&&x.b==0&&x.c==0;}
struct VH{size_t operator()(V const&x)const noexcept{return (x.a+20)*2000+(x.b+20)*40+(x.c+20);}}; static inline int enc(V x){return (x.a+20)*41*41+(x.b+20)*41+(x.c+20);} 
struct Block{array<int,4>x;V p;array<V,5>pref;string s;};
bool forbid(const string&s){static set<string>F={"abbc","accb","baac","bcca","caab","cbba"};return F.count(s);} bool ab2(const string&s){int x[3]={},y[3]={};for(int i=0;i<2;i++)x[s[i]-'a']++;for(int i=2;i<4;i++)y[s[i]-'a']++;return x[0]==y[0]&&x[1]==y[1]&&x[2]==y[2];}
static inline unsigned long long mixkey(int geom,V A,V B,V C){unsigned long long h=geom+1; auto f=[&](V x){h=h*1315423911u+(unsigned)(enc(x)+1);};f(A);f(B);f(C);return h;}
int main(){vector<Block>B;for(int n=0;n<81;n++){int z=n;string s(4,'a');array<int,4>a;for(int i=3;i>=0;i--){a[i]=z%3;s[i]='a'+a[i];z/=3;}if(forbid(s)||ab2(s))continue;V p{0,0,0};array<V,5>pr;pr[0]={0,0,0};for(int i=0;i<4;i++){if(a[i]==0)p.a++;else if(a[i]==1)p.b++;else p.c++;pr[i+1]=p;}B.push_back({a,p,pr,s});} if(B.size()!=60)return 1;
 array<unordered_set<unsigned long long>,16> tuples; array<unordered_set<int>,16> defects; array<long long,16> recs{}; long long total=0,actual=0,exactfail=0;
 for(int ia=0;ia<60;ia++)for(int ib=0;ib<60;ib++)for(int ic=0;ic<60;ic++){array<int,3>id={ia,ib,ic};for(int K=4;K<=6;K++){int q=K/4,r=K%4;for(int s=0;s<=12-2*K;s++){int m0=s/4,i0=s%4,m1=(s+K)/4,i1=(s+K)%4,m2=(s+2*K)/4,i2=(s+2*K)%4;int c0=m1-m0-q,c1=m2-m1-q;V left{0,0,0},right{0,0,0};for(int t=m1-q;t<m1;t++)left=addv(left,B[id[t]].p);for(int t=m1;t<m1+q;t++)right=addv(right,B[id[t]].p);V D=subv(right,left);
 V A=B[id[m0]].pref[i0]; if(c0)A=subv(A,B[id[m0]].p);
 V Mid=B[id[m1]].pref[i1];
 V C{0,0,0}; if(c1)C=addv(C,B[id[m1+q]].p); if(i2)C=addv(C,B[id[m2]].pref[i2]);
 V E=addv(addv(A,mul(-2,Mid)),C); bool act=zero(addv(D,E));
 int g=i0*4+r; tuples[g].insert(mixkey(g,A,Mid,C)); defects[g].insert(enc(E)); recs[g]++; total++; actual+=act;
 // exact interface check is simply D == -E
 if(act != eq(D,negv(E)))exactfail++;
 }}}
 cout<<"{\n  \"library\":\"ALL_L4_AA2FR\",\n  \"total_records\":"<<total<<",\n  \"actual_squares\":"<<actual<<",\n  \"exact_fragment_interface_failures\":"<<exactfail<<",\n  \"geometries\":{\n";
 bool first=true; long long alltu=0; for(int g=0;g<16;g++)if(recs[g]){if(!first)cout<<",\n";first=false;cout<<"    \""<<g/4<<","<<g%4<<"\":{\"records\":"<<recs[g]<<",\"fragment_tuple_types\":"<<tuples[g].size()<<",\"defect_values\":"<<defects[g].size()<<"}";alltu+=tuples[g].size();}
 cout<<"\n  },\n  \"sum_fragment_tuple_types_over_geometries\":"<<alltu<<"\n}\n";
}
