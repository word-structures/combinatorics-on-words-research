from pathlib import Path
from collections import defaultdict,Counter
from itertools import permutations,combinations
import json,importlib.util,statistics
H=Path('/mnt/data')
O=json.load(open(H/'P6_Q2_TWISTED_RESPONSE_ORBITS_FULL_v0.1_2026-08-30.json')); reps=O['representatives']; groups=O['groups']; n=len(reps)
spec=importlib.util.spec_from_file_location('fb',H/'p6_affine_fast_builder.py');fb=importlib.util.module_from_spec(spec);spec.loader.exec_module(fb);p6=fb.p6
B=p6.library(4); idx={b:i for i,b in enumerate(B)}; masks,fm=fb.compile_masks(B,4,11);allmask=(1<<len(B))-1;mem=21
PERMS=[''.join(x) for x in permutations('abc')]
perm_idx={}
for name in PERMS:
 mp=dict(zip('abc',name)); perm_idx[name]=[idx[''.join(mp[c] for c in b)] for b in B]
def pmask(m,name):
 out=0; mp=perm_idx[name]
 while m:
  bit=m&-m;i=bit.bit_length()-1;m-=bit;out|=1<<mp[i]
 return out
def pword(w,name):
 mp=dict(zip('abc',name));return ''.join(mp[c] for c in w)
cache={}
def lm(s):
 if s in cache:return cache[s]
 m=fm[s[-3:]]
 for k,j in fb.geometries(4,11):
  r=fb.requirement(s,k,j)
  if r is not None:m|=masks[(k,j)].get(r,0)
 z=allmask & ~m;cache[s]=z;return z
L0=[lm(s) for s in reps]
# exact count merge ids
count_merges={frozenset((224,1021)),frozenset((1645,2244))}
records=[]; scorehist=Counter(); perfect=[]
for g in groups:
 if len(g)<2:continue
 for a,b in combinations(g,2):
  matches=[name for name in PERMS if pmask(L0[a],name)==L0[b]]
  if not matches:raise RuntimeError(('orbit mismatch',a,b))
  best=None
  for name in matches:
   total=L0[a].bit_count(); preserve=0; leaks=[]
   m=L0[a]
   while m:
    bit=m&-m;bi=bit.bit_length()-1;m-=bit; bj=perm_idx[name][bi]
    sa=(reps[a]+B[bi])[-mem:]; tb=(reps[b]+B[bj])[-mem:]
    if pmask(lm(sa),name)==lm(tb):preserve+=1
    else:leaks.append((B[bi],B[bj],lm(sa).bit_count(),lm(tb).bit_count()))
   cand=(preserve,-len(leaks),name,total,leaks)
   if best is None or cand>best:best=cand
  preserve,_,name,total,leaks=best
  score=(preserve,total)
  scorehist[score]+=1
  rec={'classes':[a,b],'perm':name,'preserved_branches':preserve,'total_branches':total,'leak_branches':total-preserve,'preservation_fraction':preserve/total if total else 1.0,'is_exact_count_merge':frozenset((a,b)) in count_merges}
  if rec['is_exact_count_merge'] or total-preserve<=1:rec['leaks']=leaks
  records.append(rec)
  if preserve==total:perfect.append(rec)
# persistent witness raw pair directly
PW=('aaabaaacaaabbbcabccca','aaabaaacaaabbbcbaccca')
def direct_pair(s,t):
 A=lm(s);T=lm(t); matches=[name for name in PERMS if pmask(A,name)==T];out=[]
 for name in matches:
  total=A.bit_count();pres=0;leaks=[];m=A
  while m:
   bit=m&-m;bi=bit.bit_length()-1;m-=bit;bj=perm_idx[name][bi]
   sa=(s+B[bi])[-mem:];tb=(t+B[bj])[-mem:]
   if pmask(lm(sa),name)==lm(tb):pres+=1
   else:leaks.append((B[bi],B[bj],lm(sa).bit_count(),lm(tb).bit_count()))
  out.append({'perm':name,'preserved':pres,'total':total,'leaks':leaks})
 return out
merge_recs=[r for r in records if r['is_exact_count_merge']]
fracs=[r['preservation_fraction'] for r in records]
res={'date':'2026-08-30','candidate_pairs':len(records),'perfect_same_perm_response_bisimulation_pairs':len(perfect),'preservation_fraction_summary':{'mean':statistics.mean(fracs),'median':statistics.median(fracs),'min':min(fracs),'max':max(fracs)},'exact_count_merge_pairs':merge_recs,'persistent_injection_witness':{'states':PW,'scores':direct_pair(*PW)},'score_histogram':[{'preserved':a,'total':b,'pairs':c} for (a,b),c in sorted(scorehist.items())]}
path=H/'P6_Q2_SYNCHRONOUS_RESPONSE_PAIR_AUDIT_v0.1_2026-08-30.json';path.write_text(json.dumps(res,indent=2),encoding='utf-8')
print('pairs',len(records),'perfect',len(perfect),'mean',res['preservation_fraction_summary']['mean'],'median',res['preservation_fraction_summary']['median'])
print('count merges',json.dumps(merge_recs,indent=2))
print('persistent witness',json.dumps(res['persistent_injection_witness'],indent=2))
# top score counts
for key,c in scorehist.most_common(20): print(key,c)
