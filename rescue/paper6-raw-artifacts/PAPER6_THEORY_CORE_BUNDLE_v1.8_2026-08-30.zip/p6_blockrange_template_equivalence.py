from itertools import product
import json
from pathlib import Path

def parikh(w,alph): return tuple(w.count(c) for c in alph)
def add(a,b): return tuple(x+y for x,y in zip(a,b))
def sub(a,b): return tuple(x-y for x,y in zip(a,b))
def scale(k,a): return tuple(k*x for x in a)

def direct_safe(w,Kmax,alph,forbid4=None):
    if forbid4 and any(f in w for f in forbid4): return False
    for K in range(2,min(Kmax,len(w)//2)+1):
        for s in range(len(w)-2*K+1):
            if parikh(w[s:s+K],alph)==parikh(w[s+K:s+2*K],alph): return False
    return True

def bd_parts(blocks,L,s,K,alph):
    q,r=divmod(K,L)
    m0,i0=divmod(s,L); m1,i1=divmod(s+K,L); m2,i2=divmod(s+2*K,L)
    c0=m1-m0-q; c1=m2-m1-q
    P=[parikh(b,alph) for b in blocks]
    z=(0,)*len(alph)
    left=z
    for t in range(m1-q,m1): left=add(left,P[t])
    right=z
    for t in range(m1,m1+q): right=add(right,P[t])
    D=sub(right,left)
    E=z
    if c1: E=add(E,P[m1+q])
    if c0: E=sub(E,P[m0])
    E=add(E,parikh(blocks[m0][:i0],alph))
    E=add(E,scale(-2,parikh(blocks[m1][:i1],alph)))
    if i2: E=add(E,parikh(blocks[m2][:i2],alph))
    return D,E

def template_safe(blocks,L,Q,alph,forbid4=None):
    w=''.join(blocks); Kmax=(Q+1)*L-1
    if forbid4 and any(f in w for f in forbid4): return False
    # short periods
    for K in range(2,min(L-1,len(w)//2)+1):
        for s in range(len(w)-2*K+1):
            if parikh(w[s:s+K],alph)==parikh(w[s+K:s+2*K],alph): return False
    # long periods via D+E
    for q in range(1,Q+1):
        for r in range(L):
            K=q*L+r
            if K>len(w)//2: continue
            for s in range(len(w)-2*K+1):
                D,E=bd_parts(blocks,L,s,K,alph)
                if all(x+y==0 for x,y in zip(D,E)): return False
    return True

def exhaustive(alph,L,nblocks,Q):
    B=[''.join(x) for x in product(alph,repeat=L)]
    mism=0; n=0; safe=0
    Kmax=(Q+1)*L-1
    for blocks in product(B,repeat=nblocks):
        w=''.join(blocks)
        a=direct_safe(w,Kmax,alph)
        b=template_safe(blocks,L,Q,alph)
        n+=1; safe+=a
        if a!=b:
            mism+=1
            if mism<3: print('MISMATCH',blocks,a,b)
    return {'alphabet':alph,'L':L,'nblocks':nblocks,'Q':Q,'Kmax':Kmax,'block_alphabet_size':len(B),'assemblies':n,'safe':safe,'mismatches':mism}

def main():
    out=[
      exhaustive('ab',2,6,2),      # 4^6=4096, Kmax=5
      exhaustive('abc',2,5,2),     # 9^5=59049, Kmax=5
      exhaustive('ab',3,6,2),      # 8^6=262144, Kmax=8
      exhaustive('abc',3,4,1),     # 27^4=531441, Kmax=5
    ]
    p=Path('/mnt/data/P6_BLOCKRANGE_TEMPLATE_EQUIVALENCE_RESULTS_v0.1_2026-08-30.json')
    p.write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps(out,indent=2))
if __name__=='__main__': main()
