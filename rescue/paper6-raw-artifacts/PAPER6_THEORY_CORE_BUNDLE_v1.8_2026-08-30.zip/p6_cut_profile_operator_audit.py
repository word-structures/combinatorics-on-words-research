from pathlib import Path
from itertools import product
from collections import defaultdict
import importlib.util, json, math

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('p6',HERE/'p6_semantics_audit.py')
p6=importlib.util.module_from_spec(spec); spec.loader.exec_module(p6)

unit={'a':(1,0,0),'b':(0,1,0),'c':(0,0,1)}
def plus(p,e): return (p[0]+e[0],p[1]+e[1],p[2]+e[2])

def full_states_trans(K):
    mem=max(2*K-1,3)
    states=[''.join(x) for x in product(p6.ALPH,repeat=mem) if p6.safe_cutoff(''.join(x),K)]
    idx={s:i for i,s in enumerate(states)}
    trans={c:[-1]*len(states) for c in p6.ALPH}
    for i,s in enumerate(states):
        for c in p6.ALPH:
            z=s+c
            if p6.safe_cutoff(z,K): trans[c][i]=idx[z[-mem:]]
    return states,trans

def segmented_dp_from_index(start,L,cut,trans):
    cur={(start,(0,0,0),(0,0,0)):1}
    for pos in range(L):
        nxt=defaultdict(int)
        for (t,u,v),n in cur.items():
            for ch in p6.ALPH:
                z=trans[ch][t]
                if z<0: continue
                if pos<cut: key=(z,plus(u,unit[ch]),v)
                else: key=(z,u,plus(v,unit[ch]))
                nxt[key]+=n
        cur=dict(nxt)
    return cur

def enumerate_all_cuts(start,L,trans):
    outs=[defaultdict(int) for _ in range(L+1)]
    words=[]
    for tup in product(p6.ALPH,repeat=L):
        t=start; ok=True
        for ch in tup:
            t=trans[ch][t]
            if t<0: ok=False; break
        if not ok: continue
        w=''.join(tup); words.append((w,t))
        prefs=[p6.parikh(w[:i]) for i in range(L+1)]
        total=prefs[-1]
        for cut,u in enumerate(prefs):
            v=(total[0]-u[0],total[1]-u[1],total[2]-u[2])
            outs[cut][(t,u,v)]+=1
    return [dict(x) for x in outs],words

def selected_from_coeff(coeff,target_profiles):
    out=defaultdict(int)
    for (t,u,v),n in coeff.items():
        p=(u[0]+v[0],u[1]+v[1],u[2]+v[2])
        if p in target_profiles: out[t]+=n
    return dict(out)

def selected_from_words(words,target_profiles):
    out=defaultdict(int)
    for w,t in words:
        if p6.parikh(w) in target_profiles: out[t]+=1
    return dict(out)

def audit(L,K,target_profiles):
    states,trans=full_states_trans(K)
    safeB=p6.library(L); selB=[w for w in safeB if p6.parikh(w) in target_profiles]
    mism=selm=0; maxcells=0; totalcells=0
    for si in range(len(states)):
        enums,words=enumerate_all_cuts(si,L,trans)
        selected_literal=selected_from_words(words,target_profiles)
        for cut in range(L+1):
            dp=segmented_dp_from_index(si,L,cut,trans)
            if dp!=enums[cut]: mism+=1
            if selected_from_coeff(dp,target_profiles)!=selected_literal: selm+=1
            maxcells=max(maxcells,len(dp)); totalcells+=len(dp)
    return {'L':L,'Kmax':K,'full_memory_states':len(states),'cuts':L+1,'safe_blocks':len(safeB),'selected_blocks':len(selB),
            'segmented_coefficient_dp_mismatch_state_cuts':mism,'selected_operator_mismatch_state_cuts':selm,
            'max_reached_segmented_cells_per_state_cut':maxcells,
            'mean_reached_segmented_cells_per_state_cut':totalcells/((L+1)*len(states)),
            'universal_cut_profile_descriptor_bound_all_cuts':math.comb(L+5,5)}

if __name__=='__main__':
    bal={(2,1,1),(1,2,1),(1,1,2)}
    interior={p6.parikh(w) for w in p6.library(5) if min(p6.parikh(w))>=1}
    out=[audit(4,4,bal),audit(5,5,interior),
         {'L40_universal_ternary_cut_profile_descriptor_bound':math.comb(45,5),
          'formula':'sum_i C(i+2,2) C(L-i+2,2) = C(L+5,5)'}]
    (HERE/'P6_CUT_PROFILE_OPERATOR_RESULTS_v0.1_2026-08-30.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps(out,indent=2))
